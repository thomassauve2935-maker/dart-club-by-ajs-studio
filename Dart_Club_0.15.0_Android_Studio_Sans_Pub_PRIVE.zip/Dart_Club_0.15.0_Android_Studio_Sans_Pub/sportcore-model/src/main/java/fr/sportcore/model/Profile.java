package fr.sportcore.model;
public final class Profile {
 public final String id, name;
 public Profile(String id, String name){
  if(id==null||id.trim().isEmpty()||name==null||name.trim().isEmpty())
   throw new IllegalArgumentException("Profil invalide");
  this.id=id; this.name=name.trim();
 }
}
