package fr.sportcore.model;
public final class ModeSpec {
 public final String id, name, description, rules;
 public ModeSpec(String id, String name, String description, String rules) {
  if (id == null || id.trim().isEmpty()) throw new IllegalArgumentException("id requis");
  this.id=id; this.name=name; this.description=description; this.rules=rules;
 }
}
