package fr.sportcore.model;
import java.util.*;
/** Configuration générique d'une partie : de 1 à 8 joueurs, profils facultatifs. */
public final class SessionDraft {
 public static final int MAX_PLAYERS=8;
 public final String modeId;
 public int legsToWin=1;
 private int playerCount=2;
 private final String[] names=new String[MAX_PLAYERS];
 private final String[] profileIds=new String[MAX_PLAYERS];
 public SessionDraft(String modeId){
  if(modeId==null||modeId.trim().isEmpty())throw new IllegalArgumentException("Mode requis");
  this.modeId=modeId;
  for(int i=0;i<MAX_PLAYERS;i++){names[i]="Invité "+(i+1);profileIds[i]="";}
 }
 public int playerCount(){return playerCount;}
 public void setPlayerCount(int n){
  if(n<1||n>MAX_PLAYERS)throw new IllegalArgumentException("De 1 à 8 joueurs");
  playerCount=n;
 }
 public void setPlayer(int index,String name,String profileId){
  if(index<0||index>=MAX_PLAYERS)throw new IndexOutOfBoundsException("Joueur "+index);
  names[index]=name==null?"":name.trim();profileIds[index]=profileId==null?"":profileId;
 }
 public String playerName(int index){check(index);return names[index];}
 public String profileId(int index){check(index);return profileIds[index];}
 private void check(int index){if(index<0||index>=playerCount)throw new IndexOutOfBoundsException("Joueur "+index);}
 public String[] names(){return Arrays.copyOf(names,playerCount);}
 public String[] profileIds(){return Arrays.copyOf(profileIds,playerCount);}
 public void setLegsToWin(int n){
  if(n<1||n>15)throw new IllegalArgumentException("Entre 1 et 15 legs gagnants");
  legsToWin=n;
 }
 public boolean hasValidPlayers(){
  Set<String> used=new HashSet<>();
  for(int i=0;i<playerCount;i++){
   if(names[i]==null||names[i].trim().isEmpty())return false;
   if(!profileIds[i].isEmpty()&&!used.add(profileIds[i]))return false;
  }
  return true;
 }
}
