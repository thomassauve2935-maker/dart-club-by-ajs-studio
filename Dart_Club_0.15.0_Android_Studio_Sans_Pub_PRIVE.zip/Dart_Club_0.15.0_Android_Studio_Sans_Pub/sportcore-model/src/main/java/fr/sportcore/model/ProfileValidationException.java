package fr.sportcore.model;
/** Stable reason code for presentation; no UI dependency in the repository. */
public final class ProfileValidationException extends IllegalArgumentException {
 public enum Reason { INVALID_NAME,DUPLICATE_NAME,NOT_FOUND }
 public final Reason reason;
 public ProfileValidationException(Reason reason,String message){super(message);this.reason=reason;}
}
