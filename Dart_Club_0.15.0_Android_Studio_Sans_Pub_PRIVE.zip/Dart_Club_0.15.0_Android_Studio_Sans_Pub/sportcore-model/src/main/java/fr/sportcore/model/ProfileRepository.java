package fr.sportcore.model;
import java.util.List;
/** Contrat de gestion des profils; aucune dépendance à Android ni à une discipline. */
public interface ProfileRepository {
 List<Profile> all();
 void add(String name);
 void rename(String id,String name);
 void remove(String id);
}
