package fr.sportcore.model;
import java.util.List;
public interface SportSpec {
 String appName();
 default String appSignature(){return "";}
 String headline();
 String welcomeText();
 List<ModeSpec> games();
 default boolean solo(String modeId){return false;}
}
