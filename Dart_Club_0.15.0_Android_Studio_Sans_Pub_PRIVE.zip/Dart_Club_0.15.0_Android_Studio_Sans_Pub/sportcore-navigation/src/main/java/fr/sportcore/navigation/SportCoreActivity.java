package fr.sportcore.navigation;
import fr.sportcore.ui.*;
import fr.sportcore.data.*;
import fr.sportcore.model.*;
import android.app.*;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
/** Shared shell: only Games / Profiles; sport-specific contents via protected extension points. */
public abstract class SportCoreActivity extends Activity implements ScreenHost {
 protected abstract SportSpec defineSport();
 /** Identité visuelle fournie par l'application, sans dépendance du socle au sport. */
 protected int appBrandDrawable(){return 0;}
 protected int appTheme(boolean dark){return 0;}
 protected void beforeSettingsReady(){}
 protected void prepareBaseContext(android.content.Context base){}
 @Override protected void attachBaseContext(android.content.Context base){
  prepareBaseContext(base);super.attachBaseContext(ClubLanguage.wrap(base,new LocalSettingsRepository(base).language()));
 }

 protected String setupSummary(){
  if(draft==null)return "";String mode=draft.modeId;for(ModeSpec m:spec.games())if(m.id.equals(mode))mode=m.name;
  return mode+" · "+ClubLanguage.quantity(this,fr.sportcore.ui.R.plurals.club_players,draft.playerCount());
 }
 protected final void useDraft(SessionDraft preset){draft=preset;}
 protected final String currentPage(){return page;}

 protected void onSportReady(Bundle state){}
 protected void onStartSportMatch(SessionDraft draft){}
 protected boolean renderSportPage(String page,LinearLayout container){return false;}
 protected boolean handleSportBack(String page){return false;}
 /** Emplacement publicitaire persistant, fourni par l’application (facultatif). */
 protected View createPersistentFooter(){return null;}
 /** Extension facultative des réglages (ex : options de confidentialité). */
 protected void renderAdditionalSettings(LinearLayout target){}
 private SportSpec spec;
 private ProfileRepository store;
 private LocalSettingsRepository settings;
 private LinearLayout root,nav;
 private LinearLayout mainArea;
 private FrameLayout content;
 private ScrollView currentScroll;
 private String page=ScreenRoutes.PLAY,previous=ScreenRoutes.PLAY;
 private SessionDraft draft;
 private boolean wide,large;
 private TextView setupLabel;
 private SportFeedback feedback;
 private int d(int a){return SportUI.dp(this,a);}
 @Override public void onCreate(Bundle state){
  beforeSettingsReady();settings=new LocalSettingsRepository(this);applyPalette();
  super.onCreate(state);updateBars();
  spec=defineSport();store=new LocalProfileRepository(this);large=settings.largeControls();feedback=new SportFeedback(this,this);
  if(state!=null){
   page=ScreenRoutes.safe(state.getString("page",ScreenRoutes.PLAY));
   previous=ScreenRoutes.safe(state.getString("previous",ScreenRoutes.PLAY));
   String m=state.getString("mode");if(m!=null){
    draft=new SessionDraft(m);draft.setPlayerCount(state.getInt("players",2));
    for(int i=0;i<draft.playerCount();i++)draft.setPlayer(i,state.getString("name"+i,"Invité "+(i+1)),state.getString("pid"+i,""));
    draft.setLegsToWin(state.getInt("legs",1));}
  }
  wide=getResources().getConfiguration().screenWidthDp>=600;
  onSportReady(state);createShell();navigate(page);
 }
 @Override protected void onSaveInstanceState(Bundle b){
  b.putString("page",page);b.putString("previous",previous);
  if(draft!=null){b.putString("mode",draft.modeId);b.putInt("players",draft.playerCount());
   for(int i=0;i<draft.playerCount();i++){b.putString("name"+i,draft.playerName(i));b.putString("pid"+i,draft.profileId(i));}
   b.putInt("legs",draft.legsToWin);}
  super.onSaveInstanceState(b);
 }
 @Override public Activity context(){return this;}
 @Override public SportSpec sport(){return spec;}
 @Override public ProfileRepository profiles(){return store;}
 @Override public boolean largeControls(){return large;}
 @Override public SessionDraft draft(){return draft;}
 private void createShell(){
  root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
  root.setBackground(SportUI.pageBackground(this));setContentView(root);
  root.setOnApplyWindowInsetsListener((v,insets)->{
   root.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;
  });root.requestApplyInsets();
  mainArea=new LinearLayout(this);mainArea.setOrientation(wide?LinearLayout.HORIZONTAL:LinearLayout.VERTICAL);
  root.addView(mainArea,new LinearLayout.LayoutParams(-1,0,1));
  nav=new LinearLayout(this);nav.setOrientation(wide?LinearLayout.VERTICAL:LinearLayout.HORIZONTAL);
  nav.setBackgroundColor(getColor(fr.sportcore.ui.R.color.sport_background));nav.setPadding(d(16),d(12),d(16),d(12));
  content=new FrameLayout(this);
  if(wide){mainArea.addView(nav,new LinearLayout.LayoutParams(d(174),-1));mainArea.addView(content,new LinearLayout.LayoutParams(0,-1,1));}
  else{mainArea.addView(content,new LinearLayout.LayoutParams(-1,0,1));mainArea.addView(nav,new LinearLayout.LayoutParams(-1,large?d(84):d(72)));}
  View footer=createPersistentFooter();
  if(footer!=null)root.addView(footer,new LinearLayout.LayoutParams(-1,-2));
 }
 private void refreshNav(){
  boolean hide=page.equals(ScreenRoutes.MATCH)||page.equals(ScreenRoutes.RESULT);
  nav.setVisibility(hide?View.GONE:View.VISIBLE);nav.removeAllViews();
  String[] pages={ScreenRoutes.PLAY,ScreenRoutes.PROFILES};String[] labels={getString(fr.sportcore.ui.R.string.club_games),getString(fr.sportcore.ui.R.string.club_profiles)};
  for(int i=0;i<2;i++){
   final String target=pages[i];boolean selected=(page.equals(target)||(page.equals(ScreenRoutes.SETTINGS)&&previous.equals(target)));
   TextView item=SportUI.text(this,labels[i],wide?17:15,getColor(selected?fr.sportcore.ui.R.color.sport_on_accent:fr.sportcore.ui.R.color.sport_muted),selected);
   item.setGravity(Gravity.CENTER);item.setMinHeight(d(48));item.setContentDescription(labels[i]);
   item.setBackground(SportUI.navigationBackground(this,selected));
   item.setClickable(true);item.setFocusable(true);item.setOnClickListener(v->navigate(target));
   LinearLayout.LayoutParams p=wide?new LinearLayout.LayoutParams(-1,d(64)):new LinearLayout.LayoutParams(0,-1,1);
   if(wide)p.bottomMargin=d(8);else if(i>0)p.leftMargin=d(12);nav.addView(item,p);
  }
 }
 private LinearLayout screen(){
  setupLabel=null;
  LinearLayout column=new LinearLayout(this);column.setOrientation(LinearLayout.VERTICAL);
  boolean full=page.equals(ScreenRoutes.MATCH)||page.equals(ScreenRoutes.RESULT);
  if(!full){
   LinearLayout top=SportUI.horizontal(this);top.setBackgroundColor(getColor(fr.sportcore.ui.R.color.sport_header));top.setPadding(d(24),d(8),d(24),d(8));
   int brand=appBrandDrawable();
   if(brand!=0){
    ImageView logo=new ImageView(this);logo.setImageResource(brand);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
    logo.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(d(38),d(38));lp.rightMargin=d(10);top.addView(logo,lp);
   }
   LinearLayout wordmark=SportUI.vertical(this,0);
   TextView brandName=SportUI.scoreText(this,spec.appName(),21);brandName.setTextColor(getColor(fr.sportcore.ui.R.color.sport_hero_text));wordmark.addView(brandName);
   if(!spec.appSignature().isEmpty())SportUI.below(wordmark,SportUI.text(this,spec.appSignature(),10,getColor(fr.sportcore.ui.R.color.sport_hero_muted),false),2);
   top.addView(wordmark,new LinearLayout.LayoutParams(0,-2,1));
   TextView gear=SportUI.iconButton(this,page.equals(ScreenRoutes.SETTINGS)?fr.sportcore.ui.R.drawable.ic_club_back:fr.sportcore.ui.R.drawable.ic_club_settings,
       page.equals(ScreenRoutes.SETTINGS)?getString(fr.sportcore.ui.R.string.club_back):getString(fr.sportcore.ui.R.string.club_settings));
   gear.setBackground(SportUI.flatChip(this,getColor(fr.sportcore.ui.R.color.sport_header),24));
   gear.setCompoundDrawablesRelative(SportUI.icon(this,page.equals(ScreenRoutes.SETTINGS)?fr.sportcore.ui.R.drawable.ic_club_back:fr.sportcore.ui.R.drawable.ic_club_settings,getColor(fr.sportcore.ui.R.color.sport_hero_muted),24),null,null,null);
   gear.setContentDescription(page.equals(ScreenRoutes.SETTINGS)?getString(fr.sportcore.ui.R.string.club_back):getString(fr.sportcore.ui.R.string.club_settings));
   gear.setOnClickListener(v->navigate(page.equals(ScreenRoutes.SETTINGS)?previous:ScreenRoutes.SETTINGS));
   top.addView(gear,new LinearLayout.LayoutParams(d(48),d(48)));column.addView(top);
  }
  ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);
  LinearLayout inner=new LinearLayout(this);inner.setOrientation(LinearLayout.VERTICAL);
  inner.setPadding(d(wide?28:24),d(full?20:24),d(wide?28:24),d(24));
  scroll.addView(inner);column.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
  if(page.equals(ScreenRoutes.MATCH_SETUP)){
   LinearLayout actions=SportUI.vertical(this,0);actions.setPadding(d(wide?28:24),d(12),d(wide?28:24),d(12));
   setupLabel=SportUI.text(this,setupSummary(),12,getColor(fr.sportcore.ui.R.color.sport_muted),true);
   setupLabel.setGravity(Gravity.CENTER);setupLabel.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
   actions.addView(setupLabel);setupLabel.setPadding(0,0,0,d(8));
   TextView start=SportUI.withIcon(this,SportUI.button(this,getString(fr.sportcore.ui.R.string.club_start),true,large),fr.sportcore.ui.R.drawable.ic_club_play);
   start.setOnClickListener(v->startMatch());actions.addView(start,new LinearLayout.LayoutParams(-1,-2));column.addView(actions,new LinearLayout.LayoutParams(-1,-2));
  }
  currentScroll=scroll;
  content.removeAllViews();content.addView(column);return inner;
 }
 @Override public void navigate(String destination){
  String next=ScreenRoutes.safe(destination);
  if(next.equals(ScreenRoutes.SETTINGS)&&!page.equals(ScreenRoutes.SETTINGS))previous=page;
  final boolean sameMatch=next.equals(ScreenRoutes.MATCH)&&page.equals(ScreenRoutes.MATCH);
  final int scrollY=sameMatch&&currentScroll!=null?currentScroll.getScrollY():0;
  boolean changed=!page.equals(next);page=next;refreshNav();LinearLayout target=screen();
  if(sameMatch&&currentScroll!=null){ScrollView sc=currentScroll;sc.post(()->sc.scrollTo(0,scrollY));}
  if(!renderSportPage(page,target))DefaultScreenRouter.resolve(page).render(target,this);
  if(page.equals(ScreenRoutes.SETTINGS))renderAdditionalSettings(target);
  if(changed)SportMotion.enter(target);
 }
 @Override public void openMode(String id){
  for(ModeSpec m:spec.games())if(m.id.equals(id)){draft=new SessionDraft(id);if(spec.solo(id))draft.setPlayerCount(1);navigate(ScreenRoutes.MATCH_SETUP);return;}
  Toast.makeText(this,getString(fr.sportcore.ui.R.string.club_unavailable_mode),Toast.LENGTH_SHORT).show();
 }
 @Override public void startMatch(){
  if(draft==null)return;
  if(!draft.hasValidPlayers()){
   new AlertDialog.Builder(this).setTitle(getString(fr.sportcore.ui.R.string.club_check_players)).setMessage(getString(fr.sportcore.ui.R.string.club_different_profiles)).setPositiveButton(getString(fr.sportcore.ui.R.string.club_ok),null).show();return;
  }
  onStartSportMatch(draft);
 }
 private void applyPalette(){
  String id=SportPalette.safe(settings.theme());int base=appTheme(SportPalette.dark(id));
  if(base!=0){setTheme(base);android.content.res.Resources.Theme fresh=getResources().newTheme();fresh.applyStyle(base,true);fresh.applyStyle(SportPalette.style(id),true);getTheme().setTo(fresh);}
  else getTheme().applyStyle(SportPalette.style(id),true);
 }
 private void updateBars(){
  boolean dark=SportPalette.dark(themeId());getWindow().setStatusBarColor(getColor(fr.sportcore.ui.R.color.sport_background));
  int flags=dark?0:View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
  if(android.os.Build.VERSION.SDK_INT>=27){if(!dark)flags|=View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;getWindow().setNavigationBarColor(getColor(fr.sportcore.ui.R.color.sport_background));}
  else getWindow().setNavigationBarColor(getColor(fr.sportcore.ui.R.color.sport_header));
  getWindow().getDecorView().setSystemUiVisibility(flags);
 }
 private void rebuildSettings(){
  int position=currentScroll==null?0:currentScroll.getScrollY();createShell();navigate(ScreenRoutes.SETTINGS);
  ScrollView sc=currentScroll;if(sc!=null)sc.post(()->sc.scrollTo(0,position));
 }
 protected final void reloadPresentation(){
  java.util.Locale expected=ClubLanguage.resolve(settings.language(),getApplicationContext().getResources().getConfiguration().getLocales());
  if(!ClubLanguage.locale(this).equals(expected)){recreate();return;}large=settings.largeControls();applyPalette();updateBars();rebuildSettings();
 }
 @Override public String languageId(){return ClubLanguage.safe(settings.language());}
 @Override public void setLanguageId(String id){
  String next=ClubLanguage.safe(id);if(next.equals(languageId()))return;
  try{settings.setLanguage(next);recreate();}catch(IllegalStateException ex){Toast.makeText(this,fr.sportcore.ui.R.string.club_language_failed,Toast.LENGTH_LONG).show();}
 }

 @Override public void setLargeControls(boolean enabled){large=enabled;settings.setLargeControls(enabled);rebuildSettings();}
 @Override public String themeId(){return settings==null?"club":SportPalette.safe(settings.theme());}
 @Override public void setThemeId(String id){if(themeId().equals(SportPalette.safe(id)))return;settings.setTheme(SportPalette.safe(id));applyPalette();updateBars();rebuildSettings();}
 @Override public boolean sounds(){return settings.sounds();}
 @Override public void setSounds(boolean v){settings.setSounds(v);if(!v&&feedback!=null)feedback.stop();}
 @Override public boolean haptics(){return settings.haptics();}
 @Override public void setHaptics(boolean v){settings.setHaptics(v);}
 @Override public int soundVolume(){return settings.volume();}
 @Override public void setSoundVolume(int v){settings.setVolume(v);if(v==0&&feedback!=null)feedback.stop();}
 @Override public boolean reducedMotion(){return settings.reducedMotion();}
 @Override public void setReducedMotion(boolean v){settings.setReducedMotion(v);}
 @Override public void feedback(SportFeedback.Signal signal){if(feedback!=null)feedback.emit(signal);}
 @Override public void refreshSetupSummary(){if(setupLabel!=null)setupLabel.setText(setupSummary());}
 @Override protected void onResume(){super.onResume();if(feedback!=null)feedback.resume();}
 @Override protected void onPause(){if(feedback!=null)feedback.pause();super.onPause();}
 @Override protected void onDestroy(){if(feedback!=null)feedback.close();super.onDestroy();}

 @Override public void onBackPressed(){
  if(handleSportBack(page))return;
  if(page.equals(ScreenRoutes.MATCH_SETUP)){navigate(ScreenRoutes.PLAY);return;}
  if(page.equals(ScreenRoutes.SETTINGS)){navigate(previous);return;}
  if(!page.equals(ScreenRoutes.PLAY)){navigate(ScreenRoutes.PLAY);return;}
  super.onBackPressed();
 }
}
