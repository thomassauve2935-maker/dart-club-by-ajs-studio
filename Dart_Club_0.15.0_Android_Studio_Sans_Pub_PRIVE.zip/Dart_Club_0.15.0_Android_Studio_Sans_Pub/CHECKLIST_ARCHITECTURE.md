# Darts Club SportCore V0.5 — décisions et statut

## Priorité 1 : plateforme commune
- [x] 6 modules séparés, aucun import sport-darts depuis les modules communs
- [x] thème central et navigation Jeux/Profils, réglages en en-tête
- [x] catalogue unique de 15 modes, sans accueil ni séparation training/maison
- [x] composants et pavé de score partagés entre tous les modes
- [x] comportement Annuler via historique d'événements
- [x] sauvegarde active localement avec identifiants de profils
- [x] stats simples, heatmap par secteur incl. bull
- [x] tests moteurs Java purs
- [ ] compilation SDK Android, installation et validation multi-écrans

## Priorité 2 : tous les modes et règles
- [x] 15 variantes alpha et machine d'état de base
- [x] 301/501/701 double-out, bull, bust
- [ ] audit exhaustif des variantes selon règlements officiels ; sets, équipes, arbitrage avancé
- [ ] tests de règles détaillés sur cas limites de chaque mode

## Priorité 3 : ressources libres
- [x] source candidate OpenClipart/FreeSVG CC0 documentée
- [ ] télécharger et intégrer le SVG exact, vérifier et préserver sa licence
- [ ] intégrer Teko/Montserrat/Inter avec licence OFL
- [ ] sélectionner sons et icônes tiers depuis fichiers vérifiés

## Charte V0.4
- [x] noir #0A0A0C, surfaces #16161A, accent #FF2A4B, succès #00E676, texte secondaire #8F92A1
- [x] boutons 12dp, scores condensés via fallback système, états non fondés uniquement sur la couleur
- [x] première icône adaptative sans texte, géométrique
- [ ] polices demandées exactes, relief/animation néon, vérification sur Android réel

## V0.5 — Publicités, contrôles
- [x] `sportcore-ads` indépendant des sports et de la navigation
- [x] Bannières adaptatives avec emplacement persistant et sûr
- [x] UMP : demande d'information et formulaire lors du lancement
- [x] Interstitiel au maximum tous les deux legs + délai minimal de cinq minutes
- [x] Revalidation du même leg après Annuler sans incrément supplémentaire
- [x] Build debug avec annonces Google de test ; build release sans demande de pub
- [x] Tests Java du cap de fréquence
- [ ] Compilation et tests d'interface Android (téléphone/tablette)
- [ ] Identifiants AdMob réels, CMP en production, politique de confidentialité, Play Console

## V0.6 — Nombre de joueurs / détail des lancers
- [x] Choix 1 à 8 joueurs pour chaque mode ; invités ou profils facultatifs
- [x] Moteur à tableaux dynamiques (scores, manches, vies, Cricket, progression)
- [x] Trois fléchettes du tour + dernière volée visible après permutation
- [x] Annuler accessible depuis le haut et le bas du score
- [x] Sauvegarde et statistiques multi-joueurs ; ancien format V0.5 pris en charge
- [x] Tests Java et stress : 15 modes, 1 à 8 joueurs
- [ ] Compiler APK V0.6 dans Android Studio ; essais tactiles téléphone/tablette
