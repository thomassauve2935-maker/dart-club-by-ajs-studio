# Installe le Wrapper Gradle officiel 8.9, avec vérification SHA-256.
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest = Join-Path $root "gradle\wrapper\gradle-wrapper.jar"
$base = "https://raw.githubusercontent.com/gradle/gradle/v8.9.0"
Invoke-WebRequest -Uri "$base/gradle/wrapper/gradle-wrapper.jar" -OutFile $dest
$hash = (Get-FileHash $dest -Algorithm SHA256).Hash.ToLowerInvariant()
if ($hash -ne "498495120a03b9a6ab5d155f5de3c8f0d986a449153702fb80fc80e134484f17") {
 Remove-Item $dest -Force
 throw "La signature SHA-256 du Gradle Wrapper ne correspond pas à la version officielle 8.9."
}
Invoke-WebRequest -Uri "$base/gradlew" -OutFile (Join-Path $root "gradlew")
Invoke-WebRequest -Uri "$base/gradlew.bat" -OutFile (Join-Path $root "gradlew.bat")
Write-Host "Gradle Wrapper 8.9 téléchargé et JAR vérifié. Vous pouvez ouvrir Android Studio." -ForegroundColor Green
