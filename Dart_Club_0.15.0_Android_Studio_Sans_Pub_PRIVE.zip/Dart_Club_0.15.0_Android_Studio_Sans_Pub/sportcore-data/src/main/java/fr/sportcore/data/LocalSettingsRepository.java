package fr.sportcore.data;
import android.content.Context;
import android.content.SharedPreferences;
/** Préférences locales communes, indépendantes des écrans et des règles de jeu. */
public final class LocalSettingsRepository {
 private final SharedPreferences prefs;
 public LocalSettingsRepository(Context c){prefs=c.getApplicationContext().getSharedPreferences("sportcore_settings_v1",Context.MODE_PRIVATE);}
 public String language(){return prefs.getString("language","auto");}
 public void setLanguage(String value){if(!prefs.edit().putString("language",value).commit())throw new IllegalStateException("Language preference could not be saved");}
 public boolean largeControls(){return prefs.getBoolean("large_controls",false);}
 public void setLargeControls(boolean v){prefs.edit().putBoolean("large_controls",v).apply();}
 public String theme(){return prefs.getString("theme","club");}
 public void setTheme(String v){prefs.edit().putString("theme",v).apply();}
 public boolean sounds(){return prefs.getBoolean("sounds",true);}
 public void setSounds(boolean v){prefs.edit().putBoolean("sounds",v).apply();}
 public boolean haptics(){return prefs.getBoolean("haptics",false);}
 public void setHaptics(boolean v){prefs.edit().putBoolean("haptics",v).apply();}
 public int volume(){return Math.max(0,Math.min(100,prefs.getInt("volume",35)));}
 public void setVolume(int v){prefs.edit().putInt("volume",Math.max(0,Math.min(100,v))).apply();}
 public boolean reducedMotion(){return prefs.getBoolean("reduced_motion",false);}
 public void setReducedMotion(boolean v){prefs.edit().putBoolean("reduced_motion",v).apply();}
}
