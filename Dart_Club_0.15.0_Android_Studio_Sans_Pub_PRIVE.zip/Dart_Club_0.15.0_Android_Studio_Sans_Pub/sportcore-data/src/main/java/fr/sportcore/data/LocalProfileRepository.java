package fr.sportcore.data;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import fr.sportcore.model.Profile;
import fr.sportcore.model.ProfileValidationException;
import fr.sportcore.model.ProfileRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
/** Référentiel local démonstratif. Pas de compte distant ni synchronisation. */
public final class LocalProfileRepository implements ProfileRepository {
 private final SharedPreferences prefs;
 public LocalProfileRepository(Context ctx){prefs=ctx.getApplicationContext().getSharedPreferences("sportcore_profiles_v1",Context.MODE_PRIVATE);}
 @Override public List<Profile> all(){
  List<Profile> out=new ArrayList<>();
  try {
   JSONArray arr=new JSONArray(prefs.getString("profiles","[]"));
   for(int i=0;i<arr.length();i++){
    JSONObject obj=arr.getJSONObject(i);
    out.add(new Profile(obj.getString("id"),obj.getString("name")));
   }
  } catch (Exception ex) { throw new IllegalStateException("Profils locaux illisibles : sauvegarde préservée",ex); }
  return out;
 }
 @Override public void add(String name){
  List<Profile> profiles=all();
  String trimmed=validatedName(profiles,name,null);
  profiles.add(new Profile(UUID.randomUUID().toString(),trimmed));
  save(profiles);
 }
 @Override public void rename(String id,String name){
  List<Profile> profiles=all();String trimmed=validatedName(profiles,name,id);
  for(int i=0;i<profiles.size();i++)if(profiles.get(i).id.equals(id)){
   profiles.set(i,new Profile(id,trimmed));save(profiles);return;
  }
  throw new ProfileValidationException(ProfileValidationException.Reason.NOT_FOUND,"Ce profil n'existe plus");
 }
 private String validatedName(List<Profile> profiles,String name,String exceptId){
  String trimmed=name==null?"":name.trim();
  if(trimmed.isEmpty()||trimmed.length()>50)throw new ProfileValidationException(ProfileValidationException.Reason.INVALID_NAME,"Choisis un nom de 1 à 50 caractères");
  for(Profile p:profiles)if(!p.id.equals(exceptId)&&p.name.equalsIgnoreCase(trimmed))
   throw new ProfileValidationException(ProfileValidationException.Reason.DUPLICATE_NAME,"Ce nom existe déjà. Choisis-en un autre.");
  return trimmed;
 }
 @Override public void remove(String id){
  List<Profile> profiles=all();
  profiles.removeIf(p->p.id.equals(id));
  save(profiles);
 }
 private void save(List<Profile> profiles){
  JSONArray arr=new JSONArray();
  try {
   for(Profile p:profiles){JSONObject obj=new JSONObject();obj.put("id",p.id);obj.put("name",p.name);arr.put(obj);}
  }catch(Exception e){throw new IllegalStateException("Erreur de sérialisation",e);}
  if(!prefs.edit().putString("profiles",arr.toString()).commit())
   throw new IllegalStateException("Impossible de sauvegarder le profil");
 }
}
