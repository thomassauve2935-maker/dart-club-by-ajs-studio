# Sécurité des données — édition 0.15.0 sans publicité

L’application ne collecte aucune donnée vers un serveur et ne comporte aucun SDK publicitaire, de consentement, d’analyse d’usage ou de rapports de plantage. Noms, scores, statistiques, préférences et journaux restent sur l’appareil. Aucun compte en ligne n’est demandé. Le binaire doit être vérifié sans permission INTERNET ou ACCESS_NETWORK_STATE, sans AD_ID ou ACCESS_ADSERVICES_* et sans classes Google Mobile Ads, UMP ou Firebase.

Les sauvegardes JSON et images de résultats sont remises uniquement à la destination que le joueur choisit dans Android. La politique Google distingue ces transferts demandés par le joueur de la collecte et du partage automatiques par l’éditeur. Les sauvegardes système Android sont gérées par les réglages du téléphone, distinctement d’un serveur AJS Studio.

Pour cette version, répondre « Non » à la collecte/au partage de données par l’application au sens du formulaire Google Play, après lecture des définitions affichées et contrôle du binaire. Ne pas cocher des finalités publicitaires ou des identifiants que le binaire n’utilise pas. Cette déclaration devra être réévaluée si AdMob ou un autre service distant est ajouté.

L’audience tous âges, enfants compris, reste celle demandée. La suppression intégrale locale utilise Android → Informations sur l’application → Stockage → Effacer les données. Exporter auparavant ce qui doit être conservé. Les fichiers déjà exportés et les sauvegardes système sont à gérer séparément. Support et confidentialité : contact@ajsstudio.fr.
