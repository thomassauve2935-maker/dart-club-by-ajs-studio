# Première publication Google Play — sans publicité

## Création de la fiche

Nom : Dart Club By AJS Studio. Langue : français France. Type : Application. Prix : Gratuite. Catégorie : Sports. Support : contact@ajsstudio.fr. Site : https://ajsstudio.fr. Confidentialité : https://thomassauve2935-maker.github.io/blackball-confidentialite/dart-club/privacy-fr.html.

L’utilisateur est sur la page « Créer une application » de sa propre Console. Cette session ne dispose ni d’un navigateur Google authentifié pilotable, ni d’un compte de service Google Play. Le transfert du bundle et les validations Console doivent être effectués dans ce navigateur tant que cet accès manque. Une connexion GitHub ne donne pas un accès Play Console.

## Déclarations correspondant à cette édition

- Contient des annonces : **Non**. Aucun SDK publicitaire ou UMP dans le bundle ; l’application AdMob a été créée par le propriétaire mais son activation est reportée.
- Application payante, achats intégrés, abonnements : **Non**.
- Accès à l’application : toutes les fonctions sont accessibles sans compte ni authentification ; pas de compte de test à fournir.
- Données : noms, scores, statistiques et réglages restent locaux. L’application ne collecte ni ne transmet ces données à un serveur et ne demande pas de permission réseau. Pas d’analyse d’usage ni de rapports de plantage envoyés. Les exports et partages sont déclenchés par le joueur vers une destination Android choisie ; les copies système dépendent du téléphone. Les définitions Google Play excluent les traitements uniquement sur appareil et prévoient des exceptions pour les transferts demandés par le joueur. La déclaration doit correspondre à cette version, puis être mise à jour avant toute activation publicitaire.
- Audience : tous les âges, enfants compris, selon le choix explicite du propriétaire. Renseigner les tranches d’âge applicables dans la Console. Ne pas réduire l’audience pour contourner ses exigences.
- Classification : remplir le questionnaire IARC selon le jeu de comptage et les éléments présents. Aucun âge PEGI/IARC définitif ne peut être inventé avant le résultat du questionnaire.
- Pas de création de compte cloud : les profils sont locaux. La suppression se fait par Android → Informations sur l’application → Stockage → Effacer les données. Supprimer séparément les exports et les sauvegardes système souhaités.

## Envoi du binaire

Vérifier le fichier final signé, son hash, le package fr.dartsclub.app, versionName 0.15.0 et versionCode 16. Le précédent fichier 0.15.0-review est un ancien contrôle et ne constitue pas le livrable final de cette édition.

Activer Play App Signing selon les écrans Google et importer le nouveau bundle release signé par la clé d’envoi préparée. La clé d’envoi n’est pas nécessairement le certificat de signature finale distribué par Google. Ne pas sélectionner une nouvelle clé de débogage.

Un premier envoi en test interne permet les contrôles et le rapport de prélancement. Pour une disponibilité publique, compléter la fiche FR/EN/ES, les images, la confidentialité et les déclarations requises, puis choisir le canal autorisé par la Console. L’identité du compte validée ne garantit pas l’accès à la production : respecter les tests ou demandes réellement affichés pour ce compte et cette application. Ne pas déduire l’éligibilité Dart Club des anciens audits Blackball.

La notice de confidentialité de cette édition sans SDK publicitaire est publiée et vérifiée en HTTP 200 en français, anglais et espagnol sur l’hébergement de confidentialité AJS Studio. Le dossier privacy/ en conserve les textes. Les brouillons AdMob restent dans l’autre projet.

Aucune date d’approbation Google n’est garantie. Le statut « publié » ne sera annoncé qu’après confirmation dans la Console.
