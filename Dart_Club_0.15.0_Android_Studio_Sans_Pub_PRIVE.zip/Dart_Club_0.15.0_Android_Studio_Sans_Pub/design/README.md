# Identité V0.12 — cible et fléchette

Le nouveau symbole montre une cible traditionnelle et une fléchette dans son centre. La cible alterne les secteurs bleu marine et ivoire ; ses anneaux rouges et verts évoquent les doubles et triples. Le nom reste **Dart Club By AJS Studio**.

Le symbole a été généré dans Figma avec des crédits IA, puis composé avec du texte Roboto Condensed et Roboto. Les vecteurs et les textes restent éditables dans le fichier Figma ; `figma.json` contient les références et conserve les anciennes versions.

## Fichiers

- `dart-club-symbol.png` et `.svg` : symbole couleur, fond transparent, 512 × 512.
- `dart-club-symbol-monochrome.png` et `.svg` : variante avec secteurs en réserve pour l’icône thématique Android.
- `dart-club-logo.png` et `.svg` : logo complet clair, 1280 × 420.
- `dart-club-logo-dark.png` et `.svg` : logo complet sur fond bleu, mêmes dimensions.

Les SVG des logos complets sont exportés avec la typographie convertie en tracés pour un affichage indépendant des polices installées. Les PNG et SVG sont exportés directement depuis les calques Figma, sans reconstruction des tracés.

## Application Android

`club_logo.png` est la copie exacte de `dart-club-symbol.png`. La variante monochrome a une ressource distincte. Les calques de l’icône adaptative utilisent une marge de 20 % sur un fond #183C60 ; le rayon maximal de l’illustration est inférieur à 33 dp dans le repère Android 108 dp, pour garder la fléchette dans la zone sûre.

La palette claire V0.11, les règles, les statistiques et la désactivation des annonces sont conservées. Les doubles et triples de la cible statistique restent des données de partie ; les anneaux du logo ne représentent pas des fréquences.

Les images de `rendus-android/` sont des vues Android rendues avec Robolectric. Les captures nommées « figma » sont des maquettes. Aucun essai sur téléphone physique n’est déclaré pour cette version.
