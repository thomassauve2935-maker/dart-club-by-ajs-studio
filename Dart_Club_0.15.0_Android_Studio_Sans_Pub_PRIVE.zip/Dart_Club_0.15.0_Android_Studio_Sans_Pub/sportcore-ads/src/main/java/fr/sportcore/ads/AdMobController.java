package fr.sportcore.ads;

import android.app.Activity;
import android.view.View;

/** Édition sans publicité : aucun SDK, aucune requête, aucun emplacement réservé. */
public final class AdMobController {
 public AdMobController(Activity activity,AdSettings settings){
  if(settings.enabled)throw new IllegalArgumentException("Advertising is unavailable in the ad-free release");
 }
 public boolean enabled(){return false;}
 public View createFooter(){return null;}
 public void start(){}
 public void resume(){}
 public void pause(){}
 public void onMatchCompleted(String matchId){}
 public void setPrivacyOptionsListener(Runnable listener){}
 public boolean privacyOptionsRequired(){return false;}
 public void showPrivacyOptions(){}
 public void destroy(){}
}
