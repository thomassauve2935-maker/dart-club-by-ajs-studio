package fr.sportcore.ads;
/** Configuration réelle explicite, réservée à la distribution Play. Aucun ID de démonstration. */
public final class AdSettings {
 public final boolean enabled;
 public final String appId,bannerUnitId,interstitialUnitId;
 private AdSettings(boolean enabled,String app,String banner,String interstitial){this.enabled=enabled;appId=app;bannerUnitId=banner;interstitialUnitId=interstitial;}
 public static AdSettings disabled(){return new AdSettings(false,"","","");}
 public static AdSettings production(String app,String banner,String interstitial){
  if(app==null||!app.matches("ca-app-pub-[0-9]{16}~[0-9]{10}")||banner==null||!banner.matches("ca-app-pub-[0-9]{16}/[0-9]{10}")||interstitial==null||!interstitial.matches("ca-app-pub-[0-9]{16}/[0-9]{10}"))throw new IllegalArgumentException("Real AdMob application and unit IDs are required");
  String publisher=app.substring(0,app.indexOf('~'));
  if(publisher.equals("ca-app-pub-3940256099942544")||publisher.endsWith("0000000000000000")||!banner.startsWith(publisher+"/")||!interstitial.startsWith(publisher+"/")||banner.equals(interstitial))throw new IllegalArgumentException("Demo, mismatched or duplicate AdMob IDs are forbidden");
  return new AdSettings(true,app,banner,interstitial);
 }
}
