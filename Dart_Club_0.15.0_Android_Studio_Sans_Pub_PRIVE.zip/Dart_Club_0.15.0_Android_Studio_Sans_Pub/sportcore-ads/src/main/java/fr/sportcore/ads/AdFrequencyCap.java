package fr.sportcore.ads;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
/** Une occasion par match terminé ; aucune règle basée sur les legs ou une minuterie. */
public final class AdFrequencyCap {
 private final Set<String> completed;
 public AdFrequencyCap(Set<String> completedMatches){
  completed=new HashSet<>(completedMatches==null?Collections.emptySet():completedMatches);
 }
 /** Consomme l’événement même si aucune annonce n’est prête : jamais de rattrapage en jeu. */
 public boolean recordMatch(String matchId){
  if(matchId==null||matchId.trim().isEmpty())return false;
  return completed.add(matchId);
 }
 public Set<String> completedMatches(){return Collections.unmodifiableSet(new HashSet<>(completed));}
}
