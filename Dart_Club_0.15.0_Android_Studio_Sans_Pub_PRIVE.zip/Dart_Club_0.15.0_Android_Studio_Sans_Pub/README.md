# Dart Club By AJS Studio — 0.15.0 sans publicité

Première publication Google Play demandée par le propriétaire. Application Android native : 15 jeux, 1 à 8 joueurs, profils locaux et statistiques séparant simples, doubles, triples, 25 et bull. Quatre thèmes, sons, vibrations, reprise de partie, sauvegarde JSON et partage de résultat. Interface complète en français, anglais et espagnol (282 entrées).

Cette édition n’embarque aucun SDK AdMob/UMP, Firebase ou de mesure. Le contrôleur SportCore est une implémentation sans publicité ; aucun bandeau vide ni dialogue de consentement. Aucun identifiant AdMob n’est nécessaire. Le projet de préparation AdMob est conservé séparément pour une future mise à jour expressément demandée.

## Compilation

SDK 36, Build Tools 35.0.0, Gradle 8.13, AGP 8.13.2. Exécuter Gradle et Robolectric Android 16 avec Java 21 ; Java 17 doit être installé pour les modules Java. Renseigner org.gradle.java.installations.paths dans les propriétés Gradle du poste si la chaîne 17 n’est pas détectée.

Définir DART_PLAY_SIGNING_PROPERTIES vers un fichier privé rempli selon play/signing.properties.example. Ne jamais inclure la clé ou ses mots de passe dans le dépôt public.

```bash
./gradlew :app:testReleaseUnitTest :app:bundleRelease :app:lintRelease
python3 scripts/check_architecture.py
python3 scripts/check_ui_v07.py
python3 scripts/check_translations.py
```

La tâche validatePlayProduction exige une clé d’envoi distincte du certificat Android Debug. Sortie : app/build/outputs/bundle/release/app-release.aab. Identifiant prévu fr.dartsclub.app, versionCode 16, versionName 0.15.0, minSdk 26 et targetSdk 36. Ces valeurs et la signature sont à relire dans le bundle final.

## Dossier de publication

play/metadata/ contient les trois fiches de magasin ; les tests natifs exportent les images dans app/build/reports/play-assets/. play/PUBLICATION_GOOGLE_PLAY.md décrit les déclarations et les étapes Console. La clé d’envoi reste séparée du dossier. Aucun envoi Google Play n’est revendiqué sans reçu de la Console.

Les APK de test GitHub utilisent une autre signature. Conserver une sauvegarde JSON avant tout remplacement de l’installation de test ; la future version Play peut nécessiter sa restauration.
