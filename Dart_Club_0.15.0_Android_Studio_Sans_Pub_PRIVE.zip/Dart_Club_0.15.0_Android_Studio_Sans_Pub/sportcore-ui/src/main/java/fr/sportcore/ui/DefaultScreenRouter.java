package fr.sportcore.ui;
import fr.sportcore.ui.screens.*;
/** UI generic screens only, sport-specific screens are rendered by the application. */
public final class DefaultScreenRouter {
 private DefaultScreenRouter(){}
 public static ScreenRenderer resolve(String route){
  switch(ScreenRoutes.safe(route)){
   case ScreenRoutes.MATCH_SETUP:return new MatchSetupScreen();
   case ScreenRoutes.PROFILES:return new ProfilesScreen();
   case ScreenRoutes.SETTINGS:return new SettingsScreen();
   default:return new ModesScreen(true);
  }
 }
}
