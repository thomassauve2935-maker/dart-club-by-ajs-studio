package fr.sportcore.ui.screens;
import android.app.Activity;
import android.app.AlertDialog;
import android.widget.*;
import fr.sportcore.model.Profile;
import fr.sportcore.ui.*;
import java.util.List;
public final class ProfilesScreen implements ScreenRenderer {
 @Override public void render(LinearLayout box,ScreenHost h){
  Activity c=h.context();
  ScreenElements.heading(box,h,h.sport().appName(),c.getString(fr.sportcore.ui.R.string.club_profiles),c.getString(fr.sportcore.ui.R.string.club_profiles_note));
  TextView add=SportUI.button(c,c.getString(fr.sportcore.ui.R.string.club_add_player),true,h.largeControls());
  add.setOnClickListener(v->promptProfile(h));SportUI.below(box,add,22);
  List<Profile> list=h.profiles().all();
  if(list.isEmpty())SportUI.below(box,SportUI.text(c,c.getString(fr.sportcore.ui.R.string.club_empty_players),15,c.getColor(fr.sportcore.ui.R.color.sport_muted),false),26);
  for(Profile p:list){
   LinearLayout card=SportUI.card(c);
   SportUI.below(card,SportUI.text(c,p.name,20,c.getColor(fr.sportcore.ui.R.color.sport_text),true),0);
   TextView remove=SportUI.button(c,c.getString(fr.sportcore.ui.R.string.club_delete_profile),false,h.largeControls());
   remove.setOnClickListener(v->new AlertDialog.Builder(c).setTitle(c.getString(fr.sportcore.ui.R.string.club_delete_profile_title))
     .setMessage(c.getString(R.string.club_delete_profile_message,p.name))
     .setNegativeButton(c.getString(fr.sportcore.ui.R.string.club_cancel),null)
     .setPositiveButton(c.getString(fr.sportcore.ui.R.string.club_delete),(dialog,which)->{h.profiles().remove(p.id);h.navigate(ScreenRoutes.PROFILES);}).show());
   SportUI.below(card,remove,12);SportUI.below(box,card,12);
  }
 }
 private void promptProfile(ScreenHost h){
  Activity c=h.context();EditText input=new EditText(c);input.setSingleLine(true);input.setHint(c.getString(fr.sportcore.ui.R.string.club_player_name));
  LinearLayout holder=SportUI.vertical(c,SportUI.dp(c,16));holder.addView(input);
  new AlertDialog.Builder(c).setTitle(c.getString(fr.sportcore.ui.R.string.club_new_player)).setView(holder)
   .setNegativeButton(c.getString(fr.sportcore.ui.R.string.club_cancel),null)
   .setPositiveButton(c.getString(fr.sportcore.ui.R.string.club_create),(dialog,which)->{
    try{h.profiles().add(input.getText().toString());h.navigate(ScreenRoutes.PROFILES);}
    catch(IllegalArgumentException ex){Toast.makeText(c,ClubLanguage.profileError(c,ex),Toast.LENGTH_LONG).show();}
   }).show();
 }
}
