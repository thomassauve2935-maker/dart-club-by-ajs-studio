package fr.sportcore.ui;
/** Flat game catalogue + profiles, with setup and match as secondary screens. */
public final class ScreenRoutes {
 private ScreenRoutes(){}
 public static final String PLAY="play",PROFILES="profiles",SETTINGS="settings",MATCH_SETUP="match_setup",MATCH="match",RESULT="result";
 public static String safe(String route){
  if(PLAY.equals(route)||PROFILES.equals(route)||SETTINGS.equals(route)||MATCH_SETUP.equals(route)||MATCH.equals(route)||RESULT.equals(route))return route;
  return PLAY;
 }
}
