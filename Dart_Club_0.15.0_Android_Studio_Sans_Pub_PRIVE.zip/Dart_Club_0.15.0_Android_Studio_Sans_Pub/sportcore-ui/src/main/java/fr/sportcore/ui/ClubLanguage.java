package fr.sportcore.ui;
import android.content.Context;
import android.content.res.Configuration;
import android.os.LocaleList;
import fr.sportcore.model.*;
import java.util.Locale;
/** App-scoped locale; wrapping never changes the phone or persisted player names. */
public final class ClubLanguage {
 private ClubLanguage(){}
 public static final String[] IDS={"auto","fr","en","es"};
 public static String safe(String id){for(String key:IDS)if(key.equals(id))return key;return "auto";}
 public static Locale resolve(String choice,LocaleList phone){
  String key=safe(choice);if(!key.equals("auto"))return Locale.forLanguageTag(key);
  for(int i=0;i<phone.size();i++){Locale l=phone.get(i);if(l.getLanguage().equals("fr")||l.getLanguage().equals("en")||l.getLanguage().equals("es"))return l;}
  return Locale.FRENCH;
 }
 public static Context wrap(Context base,String choice){
  Configuration config=new Configuration(base.getResources().getConfiguration());Locale locale=resolve(choice,config.getLocales());config.setLocales(new LocaleList(locale));config.setLayoutDirection(locale);return base.createConfigurationContext(config);
 }
 public static Locale locale(Context c){return c.getResources().getConfiguration().getLocales().get(0);}
 public static String quantity(Context c,int resource,int number){return c.getResources().getQuantityString(resource,number,number);}
 public static String guest(Context c,int slot){return c.getString(R.string.club_guest,slot+1);}
 public static String name(Context c,SessionDraft d,int slot){
  String value=d.playerName(slot);
  if(d.profileId(slot).isEmpty()&&value.equals("Invité "+(slot+1)))return guest(c,slot);
  return value;
 }
 public static String[] names(Context c,SessionDraft d){String[] names=new String[d.playerCount()];for(int i=0;i<names.length;i++)names[i]=name(c,d,i);return names;}
 public static String profileError(Context c,IllegalArgumentException error){
  if(error instanceof ProfileValidationException){switch(((ProfileValidationException)error).reason){
   case DUPLICATE_NAME:return c.getString(R.string.club_duplicate_name);case NOT_FOUND:return c.getString(R.string.club_missing_profile);default:break;
  }}return c.getString(R.string.club_invalid_name);
 }
}
