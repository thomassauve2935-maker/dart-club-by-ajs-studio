package fr.sportcore.ui;
import android.widget.LinearLayout;
/** Un écran = un composant autonome. */
public interface ScreenRenderer {void render(LinearLayout container,ScreenHost host);}
