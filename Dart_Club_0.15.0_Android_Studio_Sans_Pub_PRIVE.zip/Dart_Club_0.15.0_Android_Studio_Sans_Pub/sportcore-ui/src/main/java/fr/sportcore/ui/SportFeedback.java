package fr.sportcore.ui;
import android.app.Activity;
import android.media.*;
import android.view.*;
import java.util.concurrent.*;
/** Sons courts générés localement. Le mode silencieux, les préférences et le cycle de vie priment. */
public final class SportFeedback {
 public enum Signal { TAP,DART,TURN,ERROR,MAXIMUM,WIN }
 private final Activity activity;private final ScreenHost host;
 private final ExecutorService worker=Executors.newSingleThreadExecutor();
 private volatile int generation;private volatile boolean paused;private AudioTrack playing;
 public SportFeedback(Activity c,ScreenHost h){activity=c;host=h;}
 public boolean canPlay(){
  AudioManager a=(AudioManager)activity.getSystemService(Activity.AUDIO_SERVICE);
  return !paused&&host.sounds()&&host.soundVolume()>0&&a!=null&&a.getRingerMode()==AudioManager.RINGER_MODE_NORMAL&&a.getStreamVolume(AudioManager.STREAM_SYSTEM)>0;
 }
 public void emit(Signal signal){
  if(paused)return;
  if(host.haptics())activity.getWindow().getDecorView().performHapticFeedback(signal==Signal.ERROR?HapticFeedbackConstants.LONG_PRESS:HapticFeedbackConstants.CLOCK_TICK);
  if(!canPlay())return;
  final int ticket=++generation;final int volume=host.soundVolume();
  try{worker.execute(()->play(signal,ticket,volume));}catch(RejectedExecutionException ignored){}
 }
 private void play(Signal signal,int ticket,int volume){
  if(ticket!=generation||!canPlay())return;
  AudioTrack track=null;
  try{
   final int rate=22050;
   double[] notes=signal==Signal.WIN?new double[]{523.25,659.25,783.99}:signal==Signal.MAXIMUM?new double[]{659.25,880}:new double[]{signal==Signal.ERROR?180:signal==Signal.TURN?660:signal==Signal.DART?340:480};
   double seconds=signal==Signal.WIN?.12:signal==Signal.MAXIMUM?.1:signal==Signal.TAP?.025:signal==Signal.ERROR?.1:.055;
   int per=(int)(rate*seconds);short[] pcm=new short[per*notes.length];
   for(int n=0;n<notes.length;n++)for(int i=0;i<per;i++){
    double t=(double)i/rate,env=Math.min(1,i/(rate*.004))*Math.pow(1-(double)i/per,2);
    pcm[n*per+i]=(short)(Math.sin(2*Math.PI*notes[n]*t)*env*9000*volume/100.0);
   }
   track=new AudioTrack.Builder().setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
    .setAudioFormat(new AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()).setTransferMode(AudioTrack.MODE_STATIC).setBufferSizeInBytes(pcm.length*2).build();
   synchronized(this){if(ticket!=generation||!canPlay())return;playing=track;track.write(pcm,0,pcm.length);track.play();}
   // Worker only; never block UI. A new signal invalidates old queued sounds.
   for(int elapsed=0;elapsed<seconds*notes.length*1000&&ticket==generation&&canPlay();elapsed+=15)Thread.sleep(15);
  }catch(Exception ignored){/* Un son indisponible ne bloque jamais un lancer. */}
  finally{if(track!=null){synchronized(this){if(playing==track)playing=null;try{track.release();}catch(RuntimeException ignored){}}}}
 }
 public synchronized void stop(){generation++;if(playing!=null)try{playing.stop();}catch(RuntimeException ignored){}}
 public void pause(){paused=true;stop();}
 public void resume(){paused=false;}
 public void close(){pause();worker.shutdownNow();}
}
