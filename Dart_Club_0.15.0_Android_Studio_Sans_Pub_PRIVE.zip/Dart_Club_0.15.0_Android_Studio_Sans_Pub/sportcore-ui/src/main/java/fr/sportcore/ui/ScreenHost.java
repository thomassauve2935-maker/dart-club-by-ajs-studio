package fr.sportcore.ui;
import android.app.Activity;
import fr.sportcore.model.SportSpec;
import fr.sportcore.model.ProfileRepository;
import fr.sportcore.model.SessionDraft;
/** Contrat unique de navigation et de présentation, sans implémentation métier. */
public interface ScreenHost {
 Activity context();
 SportSpec sport();
 ProfileRepository profiles();
 boolean largeControls();
 void navigate(String route);
 void setLargeControls(boolean enabled);
 void openMode(String modeId);
 SessionDraft draft();
 void startMatch();
 default String languageId(){return "auto";}
 default void setLanguageId(String id){}
 default String themeId(){return "club";}
 default void setThemeId(String id){}
 default boolean sounds(){return false;}
 default void setSounds(boolean enabled){}
 default boolean haptics(){return false;}
 default void setHaptics(boolean enabled){}
 default int soundVolume(){return 35;}
 default void setSoundVolume(int value){}
 default boolean reducedMotion(){return false;}
 default void setReducedMotion(boolean enabled){}
 default void feedback(SportFeedback.Signal signal){}
 default void refreshSetupSummary(){}
 /** Décor facultatif fourni par le sport, purement visuel. */
 default android.view.View featuredModeArt(){return null;}
 default String featuredModeCaption(){return context().getString(fr.sportcore.ui.R.string.club_feature_caption);}
}
