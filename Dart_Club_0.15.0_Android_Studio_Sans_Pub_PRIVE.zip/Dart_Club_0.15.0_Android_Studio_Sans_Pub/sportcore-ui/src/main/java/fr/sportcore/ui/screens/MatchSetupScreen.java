package fr.sportcore.ui.screens;
import android.app.*;
import android.view.*;
import android.widget.*;
import fr.sportcore.ui.*;
import fr.sportcore.model.*;
import java.util.*;
/** Préparation partagée : de 1 à 8 joueurs, invités ou profils, sans inscription. */
public final class MatchSetupScreen implements ScreenRenderer {
 @Override public void render(LinearLayout box,ScreenHost h){
  Activity c=h.context();SessionDraft draft=h.draft();
  if(draft==null){h.navigate(ScreenRoutes.PLAY);return;}
  ModeSpec mode=null;for(ModeSpec item:h.sport().games())if(item.id.equals(draft.modeId))mode=item;
  if(mode==null){h.navigate(ScreenRoutes.PLAY);return;}
  final ModeSpec selected=mode;
  ScreenElements.heading(box,h,c.getString(fr.sportcore.ui.R.string.club_prepare),mode.name,c.getString(fr.sportcore.ui.R.string.club_players_optional));
  TextView back=SportUI.withIcon(c,SportUI.button(c,c.getString(fr.sportcore.ui.R.string.club_all_games),false,h.largeControls()),R.drawable.ic_club_back);
  back.setOnClickListener(v->h.navigate(ScreenRoutes.PLAY));SportUI.below(box,back,12);
  TextView rule=SportUI.withIcon(c,SportUI.button(c,c.getString(fr.sportcore.ui.R.string.club_read_rules),false,h.largeControls()),R.drawable.ic_club_info);
  rule.setOnClickListener(v->new AlertDialog.Builder(c).setTitle(selected.name).setMessage(selected.rules).setPositiveButton(c.getString(fr.sportcore.ui.R.string.club_understood),null).show());
  SportUI.below(box,rule,16);
  LinearLayout playerCard=SportUI.card(c);
  SportUI.below(playerCard,SportUI.sectionTitle(c,c.getString(fr.sportcore.ui.R.string.club_player_count)),0);
  Spinner playerCount=new Spinner(c);playerCount.setMinimumHeight(SportUI.dp(c,58));
  playerCount.setBackground(SportUI.selectionBackground(c));
  playerCount.setPadding(SportUI.dp(c,12),0,SportUI.dp(c,40),0);playerCount.setContentDescription(c.getString(fr.sportcore.ui.R.string.club_player_count));
  List<String> counts=new ArrayList<>();for(int i=1;i<=8;i++)counts.add(ClubLanguage.quantity(c,R.plurals.club_players,i));
  ArrayAdapter<String> countAdapter=new ArrayAdapter<>(c,android.R.layout.simple_spinner_dropdown_item,counts);
  playerCount.setAdapter(countAdapter);playerCount.setSelection(draft.playerCount()-1);
  SportUI.below(playerCard,playerCount,10);
  LinearLayout entries=new LinearLayout(c);entries.setOrientation(LinearLayout.VERTICAL);
  SportUI.below(playerCard,entries,14);
  List<Profile> saved=h.profiles().all();
  Runnable rebuild=()->{
   entries.removeAllViews();
   for(int i=0;i<draft.playerCount();i++){
    final int slot=i;
    SportUI.below(entries,SportUI.text(c,c.getString(R.string.club_player,i+1),14,c.getColor(R.color.sport_muted),false),i==0?0:12);
    List<String> choices=new ArrayList<>();choices.add(ClubLanguage.guest(c,i));
    int selectedProfile=0;
    for(int k=0;k<saved.size();k++){
     Profile p=saved.get(k);choices.add(c.getString(R.string.club_profile_choice,p.name));
     if(p.id.equals(draft.profileId(i)))selectedProfile=k+1;
    }
    Spinner spinner=new Spinner(c);spinner.setMinimumHeight(SportUI.dp(c,54));
    spinner.setBackground(SportUI.selectionBackground(c));
    spinner.setPadding(SportUI.dp(c,12),0,SportUI.dp(c,40),0);spinner.setContentDescription(c.getString(R.string.club_player_selection,slot+1));
    ArrayAdapter<String> adapter=new ArrayAdapter<>(c,android.R.layout.simple_spinner_dropdown_item,choices);
    spinner.setAdapter(adapter);spinner.setSelection(selectedProfile);
    spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
     @Override public void onItemSelected(android.widget.AdapterView<?> a,View view,int pos,long id){
      if(pos==0)draft.setPlayer(slot,"Invité "+(slot+1),"");
      else {Profile profile=saved.get(pos-1);draft.setPlayer(slot,profile.name,profile.id);}
      h.refreshSetupSummary();
     }
     @Override public void onNothingSelected(android.widget.AdapterView<?> a){}
    });
    SportUI.below(entries,spinner,4);
   }
  };
  playerCount.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
   @Override public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){
    int selectedCount=pos+1;
    if(draft.playerCount()!=selectedCount){draft.setPlayerCount(selectedCount);rebuild.run();h.refreshSetupSummary();}
   }
   @Override public void onNothingSelected(android.widget.AdapterView<?> a){}
  });
  rebuild.run();SportUI.below(box,playerCard,16);
  LinearLayout fmt=SportUI.card(c);
  SportUI.below(fmt,SportUI.sectionTitle(c,c.getString(fr.sportcore.ui.R.string.club_winning_legs)),0);
  LinearLayout step=SportUI.horizontal(c);
  TextView minus=SportUI.button(c,"−",false,h.largeControls());
  TextView legs=SportUI.scoreText(c,""+draft.legsToWin,28);legs.setGravity(Gravity.CENTER);
  TextView plus=SportUI.button(c,"+",false,h.largeControls());
  minus.setOnClickListener(v->{draft.setLegsToWin(Math.max(1,draft.legsToWin-1));legs.setText(""+draft.legsToWin);h.refreshSetupSummary();});
  plus.setOnClickListener(v->{draft.setLegsToWin(Math.min(15,draft.legsToWin+1));legs.setText(""+draft.legsToWin);h.refreshSetupSummary();});
  step.addView(minus,new LinearLayout.LayoutParams(SportUI.dp(c,64),SportUI.dp(c,58)));
  step.addView(legs,new LinearLayout.LayoutParams(0,SportUI.dp(c,58),1));
  step.addView(plus,new LinearLayout.LayoutParams(SportUI.dp(c,64),SportUI.dp(c,58)));
  SportUI.below(fmt,step,12);
  if(selected.id.startsWith("x01_")||selected.id.equals("checkout"))SportUI.below(box,fmt,12);
  // L'action Commencer reste visible dans le pied d'écran du shell.
 }
}
