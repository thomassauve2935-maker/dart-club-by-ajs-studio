package fr.sportcore.ui.screens;
import android.app.Activity;
import android.view.*;
import android.widget.*;
import fr.sportcore.ui.*;
public final class SettingsScreen implements ScreenRenderer {
 @Override public void render(LinearLayout box,ScreenHost h){
  Activity c=h.context();
  ScreenElements.heading(box,h,c.getString(fr.sportcore.ui.R.string.club_style_eyebrow),c.getString(fr.sportcore.ui.R.string.club_your_way),c.getString(fr.sportcore.ui.R.string.club_settings_intro));
  LinearLayout languages=SportUI.card(c);languages.addView(SportUI.sectionTitle(c,c.getString(R.string.club_language)));
  SportUI.below(languages,SportUI.text(c,c.getString(R.string.club_language_note),14,c.getColor(R.color.sport_muted),false),8);
  Spinner language=new Spinner(c);language.setMinimumHeight(SportUI.dp(c,56));language.setBackground(SportUI.selectionBackground(c));language.setPadding(SportUI.dp(c,12),0,SportUI.dp(c,40),0);language.setContentDescription(c.getString(R.string.club_language));
  language.setAdapter(new ArrayAdapter<>(c,android.R.layout.simple_spinner_dropdown_item,new String[]{c.getString(R.string.club_system_language),c.getString(R.string.club_language_french),c.getString(R.string.club_language_english),c.getString(R.string.club_language_spanish)}));
  int selectedLanguage=0;for(int i=0;i<ClubLanguage.IDS.length;i++)if(ClubLanguage.IDS[i].equals(h.languageId()))selectedLanguage=i;language.setSelection(selectedLanguage);
  language.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> a,View v,int position,long id){String choice=ClubLanguage.IDS[position];if(!choice.equals(h.languageId()))h.setLanguageId(choice);}public void onNothingSelected(AdapterView<?> a){}});
  SportUI.below(languages,language,12);SportUI.below(box,languages,24);
  LinearLayout themes=SportUI.card(c);themes.addView(SportUI.sectionTitle(c,c.getString(fr.sportcore.ui.R.string.club_ambience)));
  SportUI.below(themes,SportUI.text(c,c.getString(fr.sportcore.ui.R.string.club_palette_intro),14,c.getColor(R.color.sport_muted),false),8);
  for(int i=0;i<SportPalette.IDS.length;i++){
   final String id=SportPalette.IDS[i];boolean selected=id.equals(h.themeId());
   LinearLayout option=SportUI.vertical(c,SportUI.dp(c,12));option.setBackground(SportUI.highlightedCard(c,selected));
   option.setContentDescription(c.getString(selected?R.string.club_theme_selected_a11y:R.string.club_theme_a11y,SportPalette.label(c,i)));option.setSelected(selected);
   LinearLayout line=SportUI.horizontal(c);
   line.addView(SportUI.text(c,(selected?"✓  ":"")+SportPalette.label(c,i),16,c.getColor(R.color.sport_text),true),new LinearLayout.LayoutParams(0,-2,1));
   for(int ink:SportPalette.SWATCHES[i]){
    View swatch=new View(c);swatch.setBackground(SportUI.background(ink,c.getColor(R.color.sport_stroke),10,c));
    LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(SportUI.dp(c,18),SportUI.dp(c,18));sp.leftMargin=SportUI.dp(c,4);line.addView(swatch,sp);
   }
   option.addView(line);SportUI.below(option,SportUI.text(c,SportPalette.detail(c,i),12,c.getColor(R.color.sport_muted),false),6);
   option.setMinimumHeight(SportUI.dp(c,72));option.setClickable(true);option.setFocusable(true);
   SportUI.pressableSurface(option);option.setOnClickListener(v->{h.feedback(SportFeedback.Signal.TAP);h.setThemeId(id);});SportUI.below(themes,option,10);
  }
  SportUI.below(box,themes,24);
  LinearLayout feel=SportUI.card(c);feel.addView(SportUI.sectionTitle(c,c.getString(fr.sportcore.ui.R.string.club_feel)));
  SportUI.below(feel,SportUI.text(c,c.getString(fr.sportcore.ui.R.string.club_sound_intro),14,c.getColor(R.color.sport_muted),false),8);
  toggle(feel,c,c.getString(fr.sportcore.ui.R.string.club_sounds),h.sounds(),v->{h.setSounds(v);if(v)h.feedback(SportFeedback.Signal.DART);});
  TextView volume=SportUI.text(c,c.getString(R.string.club_volume_value,h.soundVolume()),14,c.getColor(R.color.sport_muted),false);SportUI.below(feel,volume,8);
  SeekBar slider=new SeekBar(c);slider.setMax(100);slider.setProgress(h.soundVolume());slider.setContentDescription(c.getString(fr.sportcore.ui.R.string.club_effects_volume));slider.setMinimumHeight(SportUI.dp(c,48));
  slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
   public void onProgressChanged(SeekBar s,int value,boolean user){volume.setText(c.getString(R.string.club_volume_value,value));if(user)h.setSoundVolume(value);}
   public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){h.feedback(SportFeedback.Signal.DART);}
  });SportUI.below(feel,slider,0);
  toggle(feel,c,c.getString(fr.sportcore.ui.R.string.club_haptics),h.haptics(),v->{h.setHaptics(v);if(v)h.feedback(SportFeedback.Signal.TAP);});
  SportUI.below(box,feel,16);
  LinearLayout comfort=SportUI.card(c);comfort.addView(SportUI.sectionTitle(c,c.getString(fr.sportcore.ui.R.string.club_comfort)));
  toggle(comfort,c,c.getString(fr.sportcore.ui.R.string.club_large_controls),h.largeControls(),h::setLargeControls);
  toggle(comfort,c,c.getString(fr.sportcore.ui.R.string.club_reduced_motion),h.reducedMotion(),h::setReducedMotion);
  SportUI.below(comfort,SportUI.text(c,c.getString(fr.sportcore.ui.R.string.club_accessibility_note),12,c.getColor(R.color.sport_muted),false),8);
  SportUI.below(box,comfort,16);
  LinearLayout local=SportUI.card(c);local.addView(SportUI.sectionTitle(c,c.getString(fr.sportcore.ui.R.string.club_offline_ready)));
  SportUI.below(local,SportUI.text(c,c.getString(fr.sportcore.ui.R.string.club_offline_note),14,c.getColor(R.color.sport_muted),false),10);SportUI.below(box,local,16);
 }
 private interface Changed {void set(boolean value);}
 private static void toggle(LinearLayout box,Activity c,String title,boolean value,Changed change){
  Switch toggle=new Switch(c);toggle.setText(title);toggle.setContentDescription(title);toggle.setChecked(value);toggle.setTextSize(16);
  toggle.setTextColor(c.getColor(R.color.sport_text));toggle.setMinHeight(SportUI.dp(c,56));toggle.setPadding(0,0,SportUI.dp(c,2),0);
  toggle.setOnCheckedChangeListener((v,checked)->change.set(checked));SportUI.below(box,toggle,8);
 }
}
