package fr.sportcore.ui;
/** Palettes de présentation ; aucune donnée de partie n'en dépend. */
public final class SportPalette {
 private SportPalette(){}
 public static final String[] IDS={"club","sisal","green","night"};
 public static String label(android.content.Context c,int index){int[] labels={R.string.club_theme_0,R.string.club_theme_1,R.string.club_theme_2,R.string.club_theme_3};return c.getString(labels[index]);}
 public static String detail(android.content.Context c,int index){int[] labels={R.string.club_theme_detail_0,R.string.club_theme_detail_1,R.string.club_theme_detail_2,R.string.club_theme_detail_3};return c.getString(labels[index]);}
 public static String safe(String id){for(String s:IDS)if(s.equals(id))return s;return "club";}
 public static int style(String id){switch(safe(id)){case "sisal":return R.style.ClubPalette_Sisal;case "green":return R.style.ClubPalette_Green;case "night":return R.style.ClubPalette_Night;default:return R.style.ClubPalette_Club;}}
 public static boolean dark(String id){return "night".equals(id);}
 public static final int[][] SWATCHES={{0xFF183C60,0xFFC91D42,0xFF0D7962,0xFFEDF3FA},{0xFF293F35,0xFFAB233B,0xFF176B50,0xFFF5F0E6},{0xFF123F31,0xFF116B50,0xFFA92743,0xFFECF5F0},{0xFF111F2D,0xFFFF819A,0xFF73D9BB,0xFF9FC8FF}};
}
