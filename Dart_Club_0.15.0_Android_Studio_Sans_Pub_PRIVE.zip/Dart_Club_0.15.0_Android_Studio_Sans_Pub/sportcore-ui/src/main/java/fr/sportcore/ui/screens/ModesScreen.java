package fr.sportcore.ui.screens;
import android.app.Activity;
import android.view.*;
import android.widget.*;
import fr.sportcore.model.*;
import fr.sportcore.ui.*;
import java.util.List;
/** Catalogue unique ; le premier mode est mis en vedette, les suivants restent directement accessibles. */
public final class ModesScreen implements ScreenRenderer {
 public ModesScreen(boolean ignored){}
 @Override public void render(LinearLayout box,ScreenHost h){
  Activity c=h.context();List<ModeSpec> modes=h.sport().games();
  ScreenElements.heading(box,h,c.getString(R.string.club_catalogue_count,modes.size()),c.getString(fr.sportcore.ui.R.string.club_your_turn),c.getString(fr.sportcore.ui.R.string.club_catalogue_intro));
  if(modes.isEmpty())return;
  SportUI.below(box,featured(h,modes.get(0)),24);
  if(modes.size()==1)return;
  LinearLayout title=SportUI.horizontal(c);title.addView(SportUI.sectionTitle(c,c.getString(fr.sportcore.ui.R.string.club_choose_game)),new LinearLayout.LayoutParams(0,-2,1));
  title.addView(SportUI.text(c,ClubLanguage.quantity(c,R.plurals.club_other_games,modes.size()-1),12,c.getColor(R.color.sport_muted),false));SportUI.below(box,title,24);
  LinearLayout grid=null;
  for(int i=1;i<modes.size();i++){
   if((i-1)%2==0){grid=SportUI.horizontal(c);grid.setGravity(Gravity.TOP);SportUI.below(box,grid,12);}
   ModeSpec mode=modes.get(i);
   LinearLayout card=SportUI.card(c);card.setMinimumHeight(SportUI.dp(c,h.largeControls()?146:126));
   card.setBackground(SportUI.modeBackground(c,i-1));
   TextView name=SportUI.scoreText(c,mode.name,mode.name.matches("[0-9]+")?38:22);
   name.setTextColor(SportUI.modeTitleColor(c,i-1));
   name.setMinHeight(SportUI.dp(c,55));card.addView(name,new LinearLayout.LayoutParams(-1,-2));
   TextView subtitle=SportUI.text(c,mode.description,12,c.getColor(R.color.sport_muted),false);
   SportUI.below(card,subtitle,6);
   card.setClickable(true);card.setFocusable(true);card.setContentDescription(c.getString(R.string.club_play_game,mode.name));
   SportUI.pressableSurface(card);card.setOnClickListener(v->{h.feedback(SportFeedback.Signal.TAP);h.openMode(mode.id);});
   LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-2,1);
   if((i-1)%2==1)cp.leftMargin=SportUI.dp(c,12);grid.addView(card,cp);
  }
 }
 private View featured(ScreenHost h,ModeSpec mode){
  Activity c=h.context();FrameLayout hero=new FrameLayout(c);hero.setBackground(SportUI.heroBackground(c));hero.setClipToOutline(true);
  hero.setMinimumHeight(SportUI.dp(c,232));
  View art=h.featuredModeArt();if(art!=null){FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(SportUI.dp(c,220),SportUI.dp(c,220),Gravity.END|Gravity.TOP);ap.rightMargin=-SportUI.dp(c,70);ap.topMargin=SportUI.dp(c,6);hero.addView(art,ap);}
  LinearLayout copy=SportUI.vertical(c,SportUI.dp(c,20));
  TextView label=SportUI.eyebrow(c,mode.description);label.setTextColor(c.getColor(R.color.sport_hero_muted));copy.addView(label);
  TextView name=SportUI.scoreText(c,mode.name,mode.name.matches("[0-9]+")?78:38);name.setGravity(Gravity.CENTER_VERTICAL);name.setTextColor(c.getColor(R.color.sport_hero_text));
  name.setMinHeight(SportUI.dp(c,92));copy.addView(name,new LinearLayout.LayoutParams(SportUI.dp(c,190),-2));
  TextView desc=SportUI.text(c,h.featuredModeCaption(),14,c.getColor(R.color.sport_hero_muted),false);
  desc.setMinHeight(SportUI.dp(c,22));copy.addView(desc,new LinearLayout.LayoutParams(-1,-2));
  TextView action=SportUI.text(c,c.getString(fr.sportcore.ui.R.string.club_prepare_action),14,c.getColor(R.color.sport_on_accent),true);action.setGravity(Gravity.CENTER);
  action.setPadding(SportUI.dp(c,12),SportUI.dp(c,10),SportUI.dp(c,12),SportUI.dp(c,10));
  action.setBackground(SportUI.flatChip(c,c.getColor(R.color.sport_action_top),12));
  LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(SportUI.dp(c,198),-2);bp.topMargin=SportUI.dp(c,20);copy.addView(action,bp);
  // Un seul élément accessible et cliquable pour toute la carte.
  copy.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
  hero.addView(copy,new FrameLayout.LayoutParams(-1,-2));hero.setClickable(true);hero.setFocusable(true);
  hero.setContentDescription(c.getString(R.string.club_feature_a11y,mode.name,mode.description));SportUI.pressableSurface(hero);hero.setOnClickListener(v->{h.feedback(SportFeedback.Signal.TAP);h.openMode(mode.id);});return hero;
 }
}
