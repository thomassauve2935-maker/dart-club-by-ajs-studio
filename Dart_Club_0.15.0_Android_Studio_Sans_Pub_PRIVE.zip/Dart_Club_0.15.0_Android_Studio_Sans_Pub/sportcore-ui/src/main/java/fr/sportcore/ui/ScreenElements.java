package fr.sportcore.ui;
import android.app.Activity;
import android.widget.LinearLayout;
import android.widget.TextView;
/** Patrons d'écrans : titre, introduction, carte action commune. */
public final class ScreenElements {
 private ScreenElements(){}
 public static void heading(LinearLayout box,ScreenHost h,String eyebrow,String title,String subtitle){
  Activity c=h.context();
  SportUI.below(box,SportUI.eyebrow(c,eyebrow),0);
  SportUI.below(box,SportUI.scoreText(c,title,c.getResources().getConfiguration().screenWidthDp>=600?36:32),8);
  if(subtitle!=null&&!subtitle.isEmpty())SportUI.below(box,SportUI.text(c,subtitle,14,c.getColor(R.color.sport_muted),false),8);
 }
 public static void cardAction(LinearLayout box,ScreenHost h,String title,String detail,String actionLabel,Runnable tap){
  Activity c=h.context();LinearLayout card=SportUI.card(c);
  SportUI.below(card,SportUI.text(c,title,h.largeControls()?22:20,c.getColor(R.color.sport_text),true),0);
  SportUI.below(card,SportUI.text(c,detail,15,c.getColor(R.color.sport_muted),false),8);
  TextView action=SportUI.button(c,actionLabel,true,h.largeControls());
  action.setOnClickListener(v->tap.run());SportUI.below(card,action,16);SportUI.below(box,card,18);
 }
}
