package fr.sportcore.ui;
import android.animation.ValueAnimator;
import android.content.Context;
import android.provider.Settings;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
/** Effets de présentation : aucun score ni callback métier n'attend une animation. */
public final class SportMotion {
 private SportMotion(){}
 public static boolean enabled(Context c){
  if(c instanceof ScreenHost&&((ScreenHost)c).reducedMotion())return false;
  AccessibilityManager a=(AccessibilityManager)c.getSystemService(Context.ACCESSIBILITY_SERVICE);
  return ValueAnimator.areAnimatorsEnabled()&&Settings.Global.getFloat(c.getContentResolver(),Settings.Global.ANIMATOR_DURATION_SCALE,1f)>0&&!(a!=null&&a.isTouchExplorationEnabled());
 }
 public static void press(View v,boolean down){
  v.animate().cancel();if(!enabled(v.getContext())){v.setScaleX(1);v.setScaleY(1);return;}
  v.animate().scaleX(down?.97f:1f).scaleY(down?.97f:1f).setDuration(down?65:120).start();
 }
 public static void enter(View v){if(!enabled(v.getContext()))return;v.setAlpha(0);v.setTranslationY(SportUI.dp(v.getContext(),8));v.animate().alpha(1).translationY(0).setDuration(180).start();}
 public static void pulse(View v,boolean celebration){
  if(v==null||!enabled(v.getContext()))return;
  v.setScaleX(celebration?.94f:1.035f);v.setScaleY(celebration?.94f:1.035f);
  v.animate().scaleX(1).scaleY(1).setDuration(celebration?350:170).start();
 }
}
