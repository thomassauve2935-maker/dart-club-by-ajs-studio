package fr.sportcore.ui;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * SportCore Design System : finition premium commune, sans dépendance à un sport.
 * Inspirations de finition : bordures fines, relief léger, actions lisibles,
 * composants réutilisables. Palette claire, bleus et accents du club.
 */
public final class SportUI {
 private SportUI(){}
 private static final class ActionText extends TextView {
  boolean tapFeedback=true;
  ActionText(Context c){super(c);setSoundEffectsEnabled(false);}
  @Override public CharSequence getAccessibilityClassName(){return isClickable()?android.widget.Button.class.getName():super.getAccessibilityClassName();}
  @Override public boolean performClick(){if(isEnabled()&&isClickable()&&tapFeedback&&getContext() instanceof ScreenHost)((ScreenHost)getContext()).feedback(SportFeedback.Signal.TAP);return super.performClick();}
  @Override public boolean onTouchEvent(android.view.MotionEvent e){
   if(isClickable()&&isEnabled()){
    if(e.getActionMasked()==android.view.MotionEvent.ACTION_DOWN)SportMotion.press(this,true);
    else if(e.getActionMasked()==android.view.MotionEvent.ACTION_UP||e.getActionMasked()==android.view.MotionEvent.ACTION_CANCEL)SportMotion.press(this,false);
   }
   return super.onTouchEvent(e);
  }
 }
 public static void pressableSurface(View v){
  v.setSoundEffectsEnabled(false);v.setOnTouchListener((view,event)->{
   if(event.getActionMasked()==android.view.MotionEvent.ACTION_DOWN)SportMotion.press(view,true);
   else if(event.getActionMasked()==android.view.MotionEvent.ACTION_UP||event.getActionMasked()==android.view.MotionEvent.ACTION_CANCEL)SportMotion.press(view,false);
   return false;
  });
 }
 public static void dedicatedFeedback(TextView v){if(v instanceof ActionText)((ActionText)v).tapFeedback=false;}

 public static final int CARD_RADIUS=20;
 public static final int BUTTON_RADIUS=12;
 public static int dp(Context c,float v){return Math.round(c.getResources().getDisplayMetrics().density*v);}
 public static int color(Context c,int id){return c.getColor(id);}

 private static GradientDrawable gradient(Context c,int start,int end,int stroke,int radius){
  GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{start,end});
  d.setCornerRadius(dp(c,radius));
  if(stroke!=0)d.setStroke(dp(c,1),stroke);
  return d;
 }
 private static Drawable touch(Context c,GradientDrawable shape){
  return new RippleDrawable(ColorStateList.valueOf(0x223A6CA3),shape,null);
 }
 /** Aplat sans dégradé, notamment pour les légendes de données. */
 public static Drawable flatChip(Context c,int fill,int radius){
  GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(c,radius));return d;
 }
 public static GradientDrawable background(int fill,int stroke,float radius,Context c){
  return gradient(c,fill,fill,stroke,Math.round(radius));
 }
 /** Dégradé de fond presque imperceptible : les données restent prioritaires. */
 public static Drawable pageBackground(Context c){
  int base=c.getColor(R.color.sport_background);
  return new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
    new int[]{base,base});
 }
 public static Drawable cardBackground(Context c){
  int base=c.getColor(R.color.sport_card);
  return gradient(c,base,base,c.getColor(R.color.sport_stroke),CARD_RADIUS);
 }
 public static Drawable highlightedCard(Context c,boolean selected){
  int card=c.getColor(R.color.sport_card);
  if(!selected)return cardBackground(c);
  int active=c.getColor(R.color.sport_selected);
  return gradient(c,active,active,c.getColor(R.color.sport_accent),CARD_RADIUS);
 }
 public static Drawable heroBackground(Context c){
  return touch(c,gradient(c,c.getColor(R.color.sport_hero_top),c.getColor(R.color.sport_hero_bottom),0,20));
 }
 public static Drawable modeBackground(Context c,int index){
  int[] tones={R.color.sport_mode_blue,R.color.sport_mode_mint,R.color.sport_mode_amber,R.color.sport_mode_rose};
  int fill=c.getColor(tones[Math.floorMod(index,tones.length)]);return touch(c,gradient(c,fill,fill,0,CARD_RADIUS));
 }
 public static int modeTitleColor(Context c,int index){
  int[] inks={R.color.sport_blue,R.color.sport_teal,R.color.sport_amber,R.color.sport_accent};
  return c.getColor(inks[Math.floorMod(index,inks.length)]);
 }
 public static Drawable navigationBackground(Context c,boolean selected){
  int base=c.getColor(R.color.sport_background);
  if(!selected)return touch(c,gradient(c,base,base,0,BUTTON_RADIUS));
  int accent=c.getColor(R.color.sport_action_top);
  return touch(c,gradient(c,accent,accent,0,20));
 }
 public static TextView text(Context c,String value,int sp,int color,boolean bold){
  TextView t=new ActionText(c);t.setText(value);t.setTextSize(sp);t.setTextColor(color);
  t.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
  t.setIncludeFontPadding(false);t.setLineSpacing(dp(c,2),1f);return t;
 }
 public static TextView scoreText(Context c,String value,int sp){
  TextView t=text(c,value,sp,c.getColor(R.color.sport_text),true);
  t.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD));
  t.setFontFeatureSettings("tnum");return t;
 }
 public static LinearLayout vertical(Context c,int pad){
  LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);l.setClipToPadding(false);
  l.setPadding(pad,pad,pad,pad);return l;
 }
 public static LinearLayout horizontal(Context c){
  LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;
 }
 public static LinearLayout.LayoutParams rowParams(int w,int h){return new LinearLayout.LayoutParams(w,h);}
 public static void below(LinearLayout parent,View child,int topDp){
  LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
  p.topMargin=dp(parent.getContext(),topDp);parent.addView(child,p);
 }
 /** Bouton universel : relief subtil, ombre légère, état pressé Android natif. */
 public static TextView button(Context c,String title,boolean primary,boolean large){
  int fg=primary?c.getColor(R.color.sport_on_accent):c.getColor(R.color.sport_text);
  TextView v=text(c,title,large?18:primary?16:14,fg,true);
  v.setGravity(Gravity.CENTER);v.setMinHeight(dp(c,large?60:primary?52:48));
  v.setPadding(dp(c,14),dp(c,10),dp(c,14),dp(c,10));
  v.setLetterSpacing(0);
  if(primary){
   v.setBackground(touch(c,gradient(c,c.getColor(R.color.sport_action_top),c.getColor(R.color.sport_action_bottom),c.getColor(R.color.sport_action_outline),BUTTON_RADIUS)));
   v.setElevation(0);
  }else{
   v.setBackground(touch(c,gradient(c,c.getColor(R.color.sport_button_top),c.getColor(R.color.sport_button_bottom),
       c.getColor(R.color.sport_stroke),BUTTON_RADIUS)));
   v.setElevation(0);
  }
  v.setClickable(true);v.setFocusable(true);return v;
 }
 /** Pavé de scores : composants partagés, contraste renforcé, surface mate premium. */
 public static TextView scoreKey(Context c,String label){
  TextView v=button(c,label,false,false);dedicatedFeedback(v);
  v.setTextSize(24);
  v.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD));
  v.setBackground(touch(c,gradient(c,c.getColor(R.color.sport_key_top),c.getColor(R.color.sport_key_bottom),c.getColor(R.color.sport_key_outline),BUTTON_RADIUS)));
  v.setMinHeight(dp(c,48));return v;
 }
 /** État actif explicite et accessible : libellé + vert, jamais couleur seule. */
 public static void toggleState(Context c,TextView view,boolean active){
  if(active){
   view.setBackground(touch(c,gradient(c,c.getColor(R.color.sport_toggle_top),c.getColor(R.color.sport_toggle_bottom),
        c.getColor(R.color.sport_success),BUTTON_RADIUS)));
   view.setTextColor(c.getColor(R.color.sport_toggle_text));
  } else {
   view.setBackground(touch(c,gradient(c,c.getColor(R.color.sport_button_top),c.getColor(R.color.sport_button_bottom),
        c.getColor(R.color.sport_stroke),BUTTON_RADIUS)));
   view.setTextColor(c.getColor(R.color.sport_text));
  }
  view.setSelected(active);
 }
 public static LinearLayout card(Context c){
  LinearLayout card=vertical(c,dp(c,16));card.setBackground(cardBackground(c));return card;
 }
 public static TextView sectionTitle(Context c,String value){
  return scoreText(c,value,20);
 }
 public static Drawable icon(Context c,int resource,int tint,int size){
  Drawable icon=c.getDrawable(resource).mutate();icon.setTint(tint);
  icon.setBounds(0,0,dp(c,size),dp(c,size));return icon;
 }
 public static TextView withIcon(Context c,TextView view,int resource){
  view.setCompoundDrawablesRelative(icon(c,resource,view.getCurrentTextColor(),20),null,null,null);
  view.setCompoundDrawablePadding(dp(c,10));return view;
 }
 public static TextView iconButton(Context c,int resource,String description){
  TextView view=button(c,"",false,false);view.setPadding(dp(c,12),dp(c,12),dp(c,12),dp(c,12));
  view.setCompoundDrawablesRelative(icon(c,resource,c.getColor(R.color.sport_muted),24),null,null,null);
  view.setBackground(touch(c,gradient(c,c.getColor(R.color.sport_background),c.getColor(R.color.sport_background),0,24)));
  view.setContentDescription(description);return view;
 }
 public static TextView eyebrow(Context c,String value){
  TextView text=text(c,value.toUpperCase(ClubLanguage.locale(c)),11,c.getColor(R.color.sport_accent),true);
  text.setLetterSpacing(.14f);return text;
 }
 public static Drawable selectionBackground(Context c){
  Drawable base=background(c.getColor(R.color.sport_button_bottom),c.getColor(R.color.sport_stroke),12,c);
  android.graphics.drawable.LayerDrawable layers=new android.graphics.drawable.LayerDrawable(new Drawable[]{base,icon(c,R.drawable.ic_club_chevron_down,c.getColor(R.color.sport_muted),20)});
  layers.setLayerSize(1,dp(c,20),dp(c,20));layers.setLayerGravity(1,Gravity.END|Gravity.CENTER_VERTICAL);
  layers.setLayerInset(1,0,0,dp(c,12),0);return layers;
 }
 public static void divider(LinearLayout parent){
  View line=new View(parent.getContext());line.setBackgroundColor(parent.getContext().getColor(R.color.sport_stroke));
  LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(parent.getContext(),1));
  p.topMargin=dp(parent.getContext(),12);parent.addView(line,p);
 }
}
