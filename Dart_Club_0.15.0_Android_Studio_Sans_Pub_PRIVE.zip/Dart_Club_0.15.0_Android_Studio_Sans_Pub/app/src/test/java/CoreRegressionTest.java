import org.junit.Test;

/** Rend les vérifications Java historiques exécutables avec Gradle et Android Studio. */
public class CoreRegressionTest {
 @Test public void adsFrequency() throws Exception {AdsFrequencyTest.main(new String[0]);}
 @Test public void dartsEngine() throws Exception {DartsEngineTest.main(new String[0]);}
 @Test public void smoke() throws Exception {SmokeTest.main(new String[0]);}
 @Test public void journey() throws Exception {JourneySmokeTest.main(new String[0]);}
 @Test public void multiplayerStress() throws Exception {MultiplayerStressTest.main(new String[0]);}
 @Test public void allModesFinishAndUndo() throws Exception {AllModesCompletionTest.main(new String[0]);}
}
