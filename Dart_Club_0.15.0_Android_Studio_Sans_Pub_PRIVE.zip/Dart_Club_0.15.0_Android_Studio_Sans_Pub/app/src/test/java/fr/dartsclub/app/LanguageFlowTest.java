package fr.dartsclub.app;
import static org.junit.Assert.*;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import fr.sportcore.data.*;
import fr.sportcore.model.*;
import fr.sportcore.ui.*;
import fr.sportdarts.DartsSpec;
import fr.sportdarts.engine.*;
import java.io.*;
import java.util.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.shadows.ShadowDialog;
@RunWith(RobolectricTestRunner.class)
@Config(sdk=35,qualifiers="fr-rFR-w390dp-h844dp-mdpi",shadows={AppFlowTest.AdEvents.class},instrumentedPackages={"fr.sportcore.ads"})
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class LanguageFlowTest {
 private Context c;private ActivityController<MainActivity> controller;private MainActivity activity;
 @Before public void before(){
  // FileProvider caches absolute paths across Robolectric sandboxes, each with a different data directory.
  Map<?,?> providerCache=org.robolectric.util.ReflectionHelpers.getStaticField(androidx.core.content.FileProvider.class,"sCache");synchronized(providerCache){providerCache.clear();}
  c=RuntimeEnvironment.getApplication();for(String key:new String[]{"sportcore_profiles_v1","sportcore_settings_v1","darts_stats_1","darts_in_progress_v1","darts_last_setup_v1","darts_restore_journal_v1","darts_celebrations_v1"})c.getSharedPreferences(key,0).edit().clear().commit();AppFlowTest.AdEvents.completed.clear();
 }
 @After public void after(){if(controller!=null)controller.pause().stop().destroy();}
 private void start(String language){c.getSharedPreferences("sportcore_settings_v1",0).edit().putString("language",language).commit();controller=Robolectric.buildActivity(MainActivity.class).setup().visible();activity=controller.get();idle();}
 private void restart(){controller.recreate();activity=controller.get();idle();}
 private static void idle(){Shadows.shadowOf(Looper.getMainLooper()).idle();}
 private View decor(){return activity.getWindow().getDecorView();}
 private static List<View> all(View v){List<View> out=new ArrayList<>();out.add(v);if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int i=0;i<g.getChildCount();i++)out.addAll(all(g.getChildAt(i)));}return out;}
 private View button(String text){return button(decor(),text);}
 private static View button(View root,String text){for(View v:all(root))if(v instanceof TextView&&v.isClickable()&&((TextView)v).getText().toString().trim().replaceAll("\\s+"," ").equals(text.trim().replaceAll("\\s+"," ")))return v;throw new AssertionError("Missing action: "+text);}
 private boolean text(String value){for(View v:all(decor()))if(v instanceof TextView&&((TextView)v).getText().toString().contains(value))return true;return false;}
 private void click(String text){button(text).performClick();idle();}
 private void click(int key){click(activity.getString(key));}
 private void selectLanguage(String language){
  activity.navigate(ScreenRoutes.SETTINGS);idle();Spinner languagePicker=null;for(View v:all(decor()))if(v instanceof Spinner&&activity.getString(fr.sportcore.ui.R.string.club_language).contentEquals(v.getContentDescription()))languagePicker=(Spinner)v;
  assertNotNull(languagePicker);int index=Arrays.asList(ClubLanguage.IDS).indexOf(language);languagePicker.setSelection(index);idle();assertEquals(language,new LocalSettingsRepository(c).language());restart();
 }
 @Test public void phoneLanguageMatchesRegionalLocalesAndFallsBackToFrench(){
  assertEquals("es",ClubLanguage.resolve("auto",new LocaleList(Locale.forLanguageTag("es-MX"))).getLanguage());
  assertEquals("en",ClubLanguage.resolve("auto",new LocaleList(Locale.forLanguageTag("en-GB"))).getLanguage());
  assertEquals("fr",ClubLanguage.resolve("auto",new LocaleList(Locale.GERMAN)).getLanguage());
  assertEquals("es",ClubLanguage.resolve("auto",new LocaleList(Locale.GERMAN,Locale.forLanguageTag("es-ES"))).getLanguage());
  assertEquals("fr",ClubLanguage.resolve("auto",new LocaleList()).getLanguage());assertEquals("en",ClubLanguage.resolve("en",new LocaleList(Locale.FRENCH)).getLanguage());
 }
 @Test public void manualPickerPersistsAndCanReturnToPhoneLanguage() throws Exception {
  start("fr");assertTrue(text("À toi de jouer."));selectLanguage("en");assertEquals("en",ClubLanguage.locale(activity).getLanguage());assertTrue(text("Make it yours."));assertEquals("en",activity.languageId());capture("20-en-settings");
  selectLanguage("es");assertTrue(text("A tu manera."));assertEquals("es",ClubLanguage.locale(activity).getLanguage());capture("20-es-settings");
  selectLanguage("auto");assertEquals("auto",activity.languageId());assertEquals("fr",ClubLanguage.locale(activity).getLanguage());assertTrue(text("À ta façon."));
 }
 @Test public void switchingLanguageKeepsTheExactJournalAndUserNames() throws Exception {
  start("fr");activity.profiles().add("Invité 1");Profile profile=activity.profiles().all().get(0);
  activity.openMode("x01_501");activity.draft().setPlayer(0,profile.name,profile.id);activity.navigate(ScreenRoutes.MATCH_SETUP);idle();click(fr.sportcore.ui.R.string.club_start);click("T Triple");click("20");
  String journal=c.getSharedPreferences("darts_in_progress_v1",0).getString("current","");selectLanguage("en");activity.navigate(ScreenRoutes.MATCH);idle();
  assertEquals(journal,c.getSharedPreferences("darts_in_progress_v1",0).getString("current",""));assertTrue(text("INVITÉ 1 TO THROW"));assertTrue(text("GUEST 2"));capture("21-en-match");
  selectLanguage("es");activity.navigate(ScreenRoutes.MATCH);idle();assertEquals(journal,c.getSharedPreferences("darts_in_progress_v1",0).getString("current",""));assertTrue(text("TURNO DE INVITÉ 1"));assertTrue(text("INVITADO 2"));capture("21-es-match");
  assertEquals(profile.name,activity.profiles().all().get(0).name);click(R.string.darts_undo);assertEquals(0,new ActiveDartsStore(c).load().session.dartsThrown());
 }
 private void journey(String language) throws Exception {
  start(language);String tag=language;assertEquals(language,ClubLanguage.locale(activity).getLanguage());capture("22-"+tag+"-catalogue");
  List<ModeSpec> modes=activity.sport().games(),source=new DartsSpec().games();assertEquals(15,modes.size());for(int i=0;i<15;i++){assertEquals(source.get(i).id,modes.get(i).id);assertFalse(modes.get(i).rules.isEmpty());}
  activity.profiles().add("José Álvarez");Profile p=activity.profiles().all().get(0);activity.openMode("checkout");activity.draft().setPlayer(0,p.name,p.id);activity.navigate(ScreenRoutes.MATCH_SETUP);idle();capture("23-"+tag+"-setup");
  click(fr.sportcore.ui.R.string.club_read_rules);AlertDialog rules=org.robolectric.shadows.ShadowAlertDialog.getLatestAlertDialog();assertEquals(modes.get(8).rules,org.robolectric.Shadows.shadowOf(rules).getMessage());rules.getButton(DialogInterface.BUTTON_POSITIVE).performClick();idle();
  click(fr.sportcore.ui.R.string.club_start);capture("24-"+tag+"-checkout");click(R.string.darts_double);click("20");assertTrue(text(activity.getString(R.string.darts_match_complete)));assertTrue(text("José Álvarez"));assertEquals(1,new LocalDartsStats(c).forProfile(p.id).zones[20][2]);capture("25-"+tag+"-result");
  assertTrue(text(language.equals("en")?"120.0":"120,0"));ActiveDartsStore.Record saved=new ActiveDartsStore(c).load();Intent share=ResultShare.intent(activity,saved.session,ClubLanguage.names(activity,saved.draft),activity.sport().games().get(8).name);
  assertTrue(share.getStringExtra(Intent.EXTRA_TEXT).startsWith(language.equals("en")?"My result":"Mi resultado"));Bitmap card=ResultShare.card(activity,saved.session,ClubLanguage.names(activity,saved.draft),modes.get(8).name);save(card,"26-"+tag+"-shared-result");card.recycle();
  activity.navigate(ScreenRoutes.PROFILES);capture("27-"+tag+"-profile");for(View v:all(decor()))if(v instanceof fr.dartsclub.app.views.DartboardView){String a11y=v.getContentDescription().toString();assertTrue(a11y.contains(language.equals("en")?"double 20":"doble 20"));}
  click(R.string.darts_add);Dialog editor=ShadowDialog.getLatestDialog();assertTrue(editor.isShowing());for(View v:all(editor.getWindow().getDecorView()))if(v instanceof EditText)((EditText)v).setText("  ");button(editor.getWindow().getDecorView(),activity.getString(fr.sportcore.ui.R.string.club_create)).performClick();idle();
  boolean localizedError=false;for(View v:all(editor.getWindow().getDecorView()))if(v instanceof TextView&&((TextView)v).getText().toString().contains(activity.getString(fr.sportcore.ui.R.string.club_invalid_name)))localizedError=true;assertTrue(localizedError);editor.dismiss();
 }
 @Test public void englishJourneyIncludesRulesErrorsStatsAndSharedCard() throws Exception {journey("en");}
 @Test public void spanishJourneyIncludesRulesErrorsStatsAndSharedCard() throws Exception {journey("es");}
 @Test public void grammarAndDecimalFormattingAreLocaleAware(){
  start("en");assertEquals("1 player",ClubLanguage.quantity(activity,fr.sportcore.ui.R.plurals.club_players,1));assertEquals("2 players",ClubLanguage.quantity(activity,fr.sportcore.ui.R.plurals.club_players,2));assertEquals("0 lives",DartsText.q(activity,R.plurals.darts_lives_count,0));
  selectLanguage("es");assertEquals("1 jugador",ClubLanguage.quantity(activity,fr.sportcore.ui.R.plurals.club_players,1));assertEquals("2 jugadores",ClubLanguage.quantity(activity,fr.sportcore.ui.R.plurals.club_players,2));assertEquals("1 vida",DartsText.q(activity,R.plurals.darts_lives_count,1));assertEquals("1000000 puntos",DartsText.q(activity,R.plurals.darts_points,1000000));
 }
 @Test public void backupIncludesLanguageAndStillAcceptsV013Files() throws Exception {
  start("es");activity.setThemeId("sisal");DartBackupManager b=new DartBackupManager(c);String raw=b.exportJson();assertEquals("es",new JSONObject(raw).getJSONObject("settings").getString("language"));
  new LocalSettingsRepository(c).setLanguage("en");b.restore(raw);assertEquals("es",new LocalSettingsRepository(c).language());
  JSONObject old=new JSONObject(raw);old.getJSONObject("settings").remove("language");DartBackupManager.validate(old.toString());b.restore(old.toString());assertEquals("auto",new LocalSettingsRepository(c).language());
 }
 @Test public void allFifteenGamesHaveLocalizedLiveStatusAndNoticeCodes(){
  start("es");for(ModeSpec mode:activity.sport().games()){
   DartSession g=new DartSession(mode.id,new String[]{"Alex"},1);String status=DartsText.status(activity,g,g.names);assertFalse(status.isEmpty());assertFalse(status.contains("Score restant"));assertFalse(status.contains("Objectif"));
  }
  DartSession g=new DartSession("checkout",new String[]{"Alex"},2);g.throwDart(new DartThrow(20,3));assertEquals(DartSession.Notice.BUST,g.lastNotice());assertEquals("BUST · turno anulado",DartsText.notice(activity,g));g.undo();g.throwDart(new DartThrow(20,2));assertEquals(DartSession.Notice.LEG_WON,g.lastNotice());assertEquals("Leg ganado · nuevo leg",DartsText.notice(activity,g));
 }
 @Test @Config(sdk=26) @GraphicsMode(GraphicsMode.Mode.LEGACY)
 public void languageChoiceWorksOnAndroidEight(){start("es");assertTrue(text("Te toca jugar."));selectLanguage("en");assertTrue(text("Make it yours."));activity.openMode("checkout");click(fr.sportcore.ui.R.string.club_start);click(R.string.darts_double);click("20");assertTrue(text("MATCH COMPLETE"));}
 @Test @Config(qualifiers="fr-rFR-w360dp-h640dp-mdpi")
 public void spanishLargeTextKeepsTheStartButtonVisible() throws Exception {
  start("es");RuntimeEnvironment.setFontScale(1.3f);restart();activity.setLargeControls(true);activity.openMode("x01_501");activity.draft().setPlayerCount(8);activity.draft().setLegsToWin(15);activity.navigate(ScreenRoutes.MATCH_SETUP);capture("28-es-large-setup",360,640);
  View start=button(activity.getString(fr.sportcore.ui.R.string.club_start));Rect rect=new Rect();assertTrue(start.getGlobalVisibleRect(rect));assertEquals(start.getHeight(),rect.height());assertTrue(rect.bottom<=640);assertTrue(text("8 jugadores"));RuntimeEnvironment.setFontScale(1f);
 }
 private void capture(String name) throws Exception {capture(name,390,844);}
 private void capture(String name,int width,int height) throws Exception {View v=decor();v.measure(View.MeasureSpec.makeMeasureSpec(width,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(height,View.MeasureSpec.EXACTLY));v.layout(0,0,width,height);idle();Bitmap b=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);v.draw(new Canvas(b));save(b,name);b.recycle();}
 private void save(Bitmap b,String name) throws Exception {File dir=new File("build/reports/ui-captures");assertTrue(dir.isDirectory()||dir.mkdirs());try(FileOutputStream out=new FileOutputStream(new File(dir,name+".png"))){assertTrue(b.compress(Bitmap.CompressFormat.PNG,100,out));}}
}
