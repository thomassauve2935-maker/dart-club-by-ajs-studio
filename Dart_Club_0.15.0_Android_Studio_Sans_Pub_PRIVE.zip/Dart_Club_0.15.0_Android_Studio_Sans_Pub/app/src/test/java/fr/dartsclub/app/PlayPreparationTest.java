package fr.dartsclub.app;
import static org.junit.Assert.*;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.os.*;
import android.view.*;
import android.widget.*;
import fr.sportcore.ads.*;
import fr.sportcore.model.*;
import fr.sportcore.ui.*;
import fr.sportdarts.engine.*;
import java.io.*;
import java.util.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
import org.robolectric.android.controller.ActivityController;
@RunWith(RobolectricTestRunner.class)
@Config(sdk=36,qualifiers="fr-rFR-w360dp-h640dp-xxhdpi",shadows={AppFlowTest.AdEvents.class},instrumentedPackages={"fr.sportcore.ads"})
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class PlayPreparationTest {
 private Context context;private MainActivity activity;private ActivityController<MainActivity> controller;
 @Before public void setup(){context=RuntimeEnvironment.getApplication();reset();}
 private void reset(){for(String p:new String[]{"sportcore_profiles_v1","sportcore_settings_v1","darts_stats_1","darts_in_progress_v1","darts_last_setup_v1","darts_celebrations_v1","darts_restore_journal_v1"})context.getSharedPreferences(p,0).edit().clear().commit();AppFlowTest.AdEvents.completed.clear();}
 private void start(String language){context.getSharedPreferences("sportcore_settings_v1",0).edit().putString("language",language).putBoolean("sounds",false).commit();controller=Robolectric.buildActivity(MainActivity.class).setup().visible();activity=controller.get();idle();}
 @After public void finish(){if(controller!=null)controller.pause().stop().destroy();}
 private static void idle(){Shadows.shadowOf(Looper.getMainLooper()).idle();}
 private static List<View> children(View v){List<View> out=new ArrayList<>();out.add(v);if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int i=0;i<g.getChildCount();i++)out.addAll(children(g.getChildAt(i)));}return out;}
 private View button(String label){for(View v:children(activity.getWindow().getDecorView()))if(v instanceof TextView&&v.isClickable()&&((TextView)v).getText().toString().trim().replaceAll("\\s+"," ").equals(label.trim().replaceAll("\\s+"," ")))return v;throw new AssertionError(label);}
 private void click(String label){button(label).performClick();idle();}
 private void click(int key){click(activity.getString(key));}
 @Test public void advertisingConsentAndAnalyticsSdkClassesAreAbsent(){
  for(String name:new String[]{"com.google.android.gms.ads.MobileAds","com.google.android.ump.UserMessagingPlatform","com.google.firebase.analytics.FirebaseAnalytics"}){
   try{Class.forName(name);fail("Unexpected SDK: "+name);}catch(ClassNotFoundException expected){}
  }
 }
 @Test public void productionConfigurationRejectsWrongPublisherDemoAndDuplicateUnits(){
  String app="ca-app-pub-8675309753108642~6547893210",banner="ca-app-pub-8675309753108642/6547893211",interstitial="ca-app-pub-8675309753108642/6547893212";
  assertTrue(AdSettings.production(app,banner,interstitial).enabled);
  for(String[] ids:new String[][]{{"",banner,interstitial},{app,banner,banner},{app,"ca-app-pub-1234509753108642/6547893211",interstitial},{"ca-app-pub-3940256099942544~3347511713","ca-app-pub-3940256099942544/6300978111","ca-app-pub-3940256099942544/1033173712"}}){try{AdSettings.production(ids[0],ids[1],ids[2]);fail();}catch(IllegalArgumentException expected){}}
 }
 @Test public void androidSixteenBuildHasNoAdvertisingIdentifiersAndDoesNotEnablePreviewAds() throws Exception {
  start("fr");assertEquals(36,activity.getApplicationInfo().targetSdkVersion);assertFalse(BuildConfig.ADMOB_ENABLED);
  android.content.pm.PackageInfo pkg=context.getPackageManager().getPackageInfo(context.getPackageName(),android.content.pm.PackageManager.GET_PERMISSIONS);
  for(String permission:pkg.requestedPermissions==null?new String[0]:pkg.requestedPermissions)assertFalse(permission,permission.equals("android.permission.INTERNET")||permission.equals("android.permission.ACCESS_NETWORK_STATE")||permission.equals("com.google.android.gms.permission.AD_ID")||permission.startsWith("android.permission.ACCESS_ADSERVICES_"));
  activity.openMode("x01_501");click(fr.sportcore.ui.R.string.club_start);for(int i=0;i<3;i++){click(R.string.darts_treble);click("20");}ActiveDartsStore.Record saved=new ActiveDartsStore(context).load();assertEquals(321,saved.session.score[0]);assertEquals(1,saved.session.active);
  click(R.string.darts_undo);assertEquals(2,new ActiveDartsStore(context).load().session.dartsThrown());
 }
 @Test public void androidSixteenInsetsKeepTheStartActionAboveSystemBars(){
  start("es");activity.openMode("x01_501");View decor=activity.getWindow().getDecorView();WindowInsets insets=new WindowInsets.Builder().setInsets(WindowInsets.Type.systemBars(),Insets.of(0,96,0,72)).build();decor.dispatchApplyWindowInsets(insets);
  decor.measure(View.MeasureSpec.makeMeasureSpec(1080,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(1920,View.MeasureSpec.EXACTLY));decor.layout(0,0,1080,1920);idle();View start=button(activity.getString(fr.sportcore.ui.R.string.club_start));Rect rect=new Rect();assertTrue(start.getGlobalVisibleRect(rect));assertEquals(start.getHeight(),rect.height());assertTrue(rect.bottom<1920);
 }
 @Test public void playStoreAssetsRenderFromTheRealInterfaceInThreeLanguages() throws Exception {
  for(String lang:new String[]{"fr","en","es"}){
   if(controller!=null){controller.pause().stop().destroy();controller=null;}reset();start(lang);
   String folder=lang.equals("fr")?"fr-FR":lang.equals("en")?"en-US":"es-ES";
   capture(folder,"1-accueil");activity.navigate(ScreenRoutes.SETTINGS);capture(folder,"2-reglages");
   activity.profiles().add("Alex");activity.profiles().add("Léa");Profile a=activity.profiles().all().get(0),b=activity.profiles().all().get(1);
   activity.openMode("x01_501");activity.draft().setPlayer(0,a.name,a.id);activity.draft().setPlayer(1,b.name,b.id);activity.navigate(ScreenRoutes.MATCH_SETUP);idle();capture(folder,"3-preparation");click(fr.sportcore.ui.R.string.club_start);for(int i=0;i<3;i++){click(R.string.darts_treble);click("20");}capture(folder,"4-match");
   DartSession stats=new DartSession("x01_301",new String[]{a.name,b.name},1);for(int i=0;i<3;i++)stats.throwDart(new DartThrow(20,3));for(int i=0;i<3;i++)stats.throwDart(new DartThrow(0,1));stats.throwDart(new DartThrow(19,3));stats.throwDart(new DartThrow(20,2));stats.throwDart(new DartThrow(12,2));assertTrue(stats.finished);new LocalDartsStats(context).save("store-example",stats,new String[]{a.id,b.id});activity.navigate(ScreenRoutes.PROFILES);capture(folder,"5-statistiques");
   storeBrandAssets(folder,lang);
  }
 }
 private void capture(String folder,String name) throws Exception {
  View v=activity.getWindow().getDecorView();v.measure(View.MeasureSpec.makeMeasureSpec(1080,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(1920,View.MeasureSpec.EXACTLY));v.layout(0,0,1080,1920);idle();Bitmap b=Bitmap.createBitmap(1080,1920,Bitmap.Config.ARGB_8888);v.draw(new Canvas(b));save(b,folder+"/phoneScreenshots/"+name+".png");b.recycle();
 }
 private void storeBrandAssets(String folder,String language) throws Exception {
  Bitmap icon=Bitmap.createBitmap(512,512,Bitmap.Config.ARGB_8888);Canvas ic=new Canvas(icon);ic.drawColor(0xff183c60);Drawable logo=activity.getDrawable(R.drawable.club_logo);logo.setBounds(24,24,488,488);logo.draw(ic);save(icon,folder+"/icon.png");icon.recycle();
  Bitmap graphic=Bitmap.createBitmap(1024,500,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(graphic);c.drawColor(0xff183c60);Drawable target=activity.getDrawable(R.drawable.club_target_art);target.setAlpha(55);target.setBounds(650,-40,1180,490);target.draw(c);logo=activity.getDrawable(R.drawable.club_logo);logo.setBounds(64,64,240,240);logo.draw(c);
  Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(0xffffffff);p.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD));p.setTextSize(78);c.drawText("DART CLUB",270,150,p);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setTextSize(30);p.setColor(0xffd9e9f8);c.drawText("By AJS Studio",274,204,p);
  p.setColor(0xffffffff);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(32);c.drawText(language.equals("fr")?"15 jeux · 1 à 8 joueurs":language.equals("en")?"15 games · 1–8 players":"15 juegos · 1 a 8 jugadores",72,335,p);p.setColor(0xffe34463);c.drawRect(72,360,600,365,p);p.setTextSize(23);p.setColor(0xffd9e9f8);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));c.drawText(language.equals("fr")?"Le score et la précision au cœur du club.":language.equals("en")?"Scoring and accuracy at the heart of your club.":"Puntuación y precisión para tu club.",72,414,p);save(graphic,folder+"/featureGraphic.png");graphic.recycle();
 }
 private static void save(Bitmap bitmap,String name) throws Exception {File file=new File("build/reports/play-assets",name);assertTrue(file.getParentFile().isDirectory()||file.getParentFile().mkdirs());try(FileOutputStream out=new FileOutputStream(file)){assertTrue(bitmap.compress(Bitmap.CompressFormat.PNG,100,out));}}
}
