package fr.dartsclub.app;
import static org.junit.Assert.*;
import android.content.*;
import android.media.AudioManager;
import fr.sportcore.data.*;
import fr.sportcore.model.*;
import fr.sportcore.ui.*;
import fr.sportdarts.engine.*;
import java.util.*;
import java.io.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.*;
@RunWith(RobolectricTestRunner.class) @Config(sdk=35)
public class ClubExperienceTest {
 private Context c;
 @Before public void before(){c=RuntimeEnvironment.getApplication();for(String p:new String[]{"sportcore_profiles_v1","sportcore_settings_v1","darts_stats_1","darts_in_progress_v1","darts_last_setup_v1","darts_restore_journal_v1","darts_celebrations_v1"})c.getSharedPreferences(p,0).edit().clear().commit();}
 private void seed(){
  LocalProfileRepository profiles=new LocalProfileRepository(c);profiles.add("Alice");Profile p=profiles.all().get(0);
  SessionDraft d=new SessionDraft("checkout");d.setPlayerCount(1);d.setPlayer(0,p.name,p.id);DartSession s=new DartSession(d.modeId,d.names(),1);s.throwDart(new DartThrow(20,2));new LocalDartsStats(c).save("completed",s,d.profileIds());
  SessionDraft active=new SessionDraft("x01_501");active.setPlayer(0,p.name,p.id);DartSession game=new DartSession(active.modeId,active.names(),1);game.throwDart(new DartThrow(19,3));new ActiveDartsStore(c).save("in-progress",active,game);new LastSetupStore(c).save(active);
  LocalSettingsRepository settings=new LocalSettingsRepository(c);settings.setTheme("sisal");settings.setHaptics(true);settings.setSounds(false);settings.setVolume(47);
 }
 @Test public void backupRoundTripRestoresIdentityRingsCurrentGameAndPreferences() throws Exception {
  seed();DartBackupManager b=new DartBackupManager(c);String raw=b.exportJson();String id=new LocalProfileRepository(c).all().get(0).id;
  c.getSharedPreferences("sportcore_profiles_v1",0).edit().clear().commit();c.getSharedPreferences("darts_stats_1",0).edit().clear().commit();new ActiveDartsStore(c).clear();new LocalSettingsRepository(c).setTheme("night");
  b.restore(raw);assertEquals(id,new LocalProfileRepository(c).all().get(0).id);assertEquals(1,new LocalDartsStats(c).forProfile(id).zones[20][2]);assertEquals(444,new ActiveDartsStore(c).load().session.score[0]);
  assertEquals("sisal",new LocalSettingsRepository(c).theme());assertEquals(47,new LocalSettingsRepository(c).volume());assertNotNull(new LastSetupStore(c).load(new LocalProfileRepository(c)));assertFalse(c.getSharedPreferences("darts_restore_journal_v1",0).contains("before"));
 }
 @Test public void corruptAndForeignBackupsCannotWriteAnything() throws Exception {
  seed();DartBackupManager b=new DartBackupManager(c);String before=b.exportJson();
  JSONObject bad=new JSONObject(before);bad.getJSONObject("active").getJSONArray("events").put(new JSONArray(new int[]{25,3}));
  for(String raw:new String[]{"{",new JSONObject(before).put("format","snooker").toString(),bad.toString(),new JSONObject(before).put("version",99).toString()}){
   try{b.restore(raw);fail("Fichier accepté");}catch(JSONException expected){}assertEquals(before,b.exportJson());
  }
 }
 @Test public void partiallyFailedRestoreRollsBackAllStores() throws Exception {
  seed();DartBackupManager b=new DartBackupManager(c);String before=b.exportJson();JSONObject incoming=new JSONObject(before);incoming.put("profiles",new JSONArray());incoming.put("matches",new JSONArray());
  final int[] writes={0};DartBackupManager failing=new DartBackupManager(c,editor->{if(++writes[0]==3)return false;return editor.commit();});
  try{failing.restore(incoming.toString());fail("Échec non signalé");}catch(IllegalStateException expected){}assertEquals(before,b.exportJson());assertFalse(c.getSharedPreferences("darts_restore_journal_v1",0).contains("before"));
 }
 @Test public void interruptedImportRecoversBeforeOpeningProfiles() throws Exception {
  seed();DartBackupManager b=new DartBackupManager(c);String before=b.exportJson();c.getSharedPreferences("darts_restore_journal_v1",0).edit().putString("before",before).commit();
  c.getSharedPreferences("sportcore_profiles_v1",0).edit().putString("profiles","[]").commit();b.recover();assertEquals(before,b.exportJson());
 }
 @Test public void legacyStatisticsArePreservedWithoutMigration() throws Exception {
  seed();JSONArray legacy=new JSONArray().put(new JSONObject().put("id0","old").put("id1","other").put("winner",0).put("x01",true).put("points0",115).put("darts0",3).put("checkout0",32).put("events",new JSONArray().put(new JSONObject().put("player",0).put("segment",16).put("multiplier",2)).put(new JSONObject().put("player",0).put("segment",5))));
  c.getSharedPreferences("darts_stats_1",0).edit().putString("matches",legacy.toString()).commit();DartBackupManager b=new DartBackupManager(c);String backup=b.exportJson();b.restore(backup);
  assertEquals(legacy.toString(),c.getSharedPreferences("darts_stats_1",0).getString("matches",""));assertEquals(1,new LocalDartsStats(c).forProfile("old").zones[16][2]);assertEquals(115,new LocalDartsStats(c).forProfile("old").points);
 }
 @Test public void importSizeIsBoundedBeforeParsing() throws Exception {
  byte[] oversized=new byte[DartBackupManager.MAX_BYTES+1];try{DartBackupManager.read(new ByteArrayInputStream(oversized));fail();}catch(IOException expected){}
 }
 @Test public void eventFeedbackDistinguishesMaximumBustAndFinalWin(){
  DartSession g=new DartSession("x01_501",new String[]{"Alice","Bob"},1);for(int i=0;i<3;i++)g.throwDart(new DartThrow(20,3));assertEquals(SportFeedback.Signal.MAXIMUM,MatchFeedback.signal(g,0,2));
  DartSession checkout=new DartSession("checkout",new String[]{"Alice"},1);checkout.throwDart(new DartThrow(20,3));assertEquals(SportFeedback.Signal.ERROR,MatchFeedback.signal(checkout,0,0));
  checkout.undo();checkout.throwDart(new DartThrow(20,2));assertEquals(SportFeedback.Signal.WIN,MatchFeedback.signal(checkout,0,0));assertTrue(MatchFeedback.claimCelebration(c,"match"));assertFalse(MatchFeedback.claimCelebration(c,"match"));
 }
 @Test public void linearRestoreMatchesIncrementalEngineAndRejectsPostMatchEvents(){
  List<DartThrow> history=new ArrayList<>();DartSession incremental=new DartSession("cricket",new String[]{"A","B","C"},1);Random random=new Random(123);
  for(int i=0;i<250&&!incremental.finished;i++){DartThrow d=new DartThrow(1+random.nextInt(20),1+random.nextInt(3));history.add(d);incremental.throwDart(d);}
  DartSession restored=DartSession.restore("cricket",incremental.names,1,history);assertArrayEquals(incremental.score,restored.score);assertEquals(incremental.active,restored.active);assertEquals(incremental.turnTotal,restored.turnTotal);
  assertEquals(incremental.history().size(),restored.history().size());for(int i=0;i<history.size();i++)assertEquals(incremental.eventPlayer(i),restored.eventPlayer(i));assertTrue(restored.undo());
  try{DartSession.restore("checkout",new String[]{"A"},1,Arrays.asList(new DartThrow(20,2),new DartThrow(1,1)));fail();}catch(IllegalArgumentException expected){}
 }
 @Test public void soundGateHonorsSilentModeMuteAndPausedLifecycle(){
  android.app.Activity a=Robolectric.buildActivity(android.app.Activity.class).setup().get();final boolean[] sound={true};final int[] volume={35};
  ScreenHost host=new ScreenHost(){public android.app.Activity context(){return a;}public SportSpec sport(){return null;}public ProfileRepository profiles(){return null;}public boolean largeControls(){return false;}public void navigate(String r){}public void setLargeControls(boolean e){}public void openMode(String id){}public SessionDraft draft(){return null;}public void startMatch(){}public boolean sounds(){return sound[0];}public int soundVolume(){return volume[0];}};
  SportFeedback f=new SportFeedback(a,host);AudioManager audio=(AudioManager)a.getSystemService(Context.AUDIO_SERVICE);audio.setStreamVolume(AudioManager.STREAM_SYSTEM,3,0);audio.setRingerMode(AudioManager.RINGER_MODE_NORMAL);assertTrue(f.canPlay());
  audio.setRingerMode(AudioManager.RINGER_MODE_SILENT);assertFalse(f.canPlay());audio.setRingerMode(AudioManager.RINGER_MODE_VIBRATE);assertFalse(f.canPlay());audio.setRingerMode(AudioManager.RINGER_MODE_NORMAL);volume[0]=0;assertFalse(f.canPlay());volume[0]=35;sound[0]=false;assertFalse(f.canPlay());sound[0]=true;f.pause();assertFalse(f.canPlay());f.resume();assertTrue(f.canPlay());f.close();assertFalse(f.canPlay());a.finish();
 }
}
