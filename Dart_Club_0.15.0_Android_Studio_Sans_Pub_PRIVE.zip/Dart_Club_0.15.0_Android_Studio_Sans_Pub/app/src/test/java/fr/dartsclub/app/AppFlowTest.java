package fr.dartsclub.app;

import static org.junit.Assert.*;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import fr.sportcore.model.ProfileRepository;
import fr.sportcore.model.Profile;
import fr.sportcore.ui.ScreenRoutes;
import fr.sportdarts.engine.DartSession;
import fr.sportdarts.engine.DartThrow;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.Shadows;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;
import org.robolectric.annotation.GraphicsMode;
import org.robolectric.annotation.Implementation;
import org.robolectric.annotation.Implements;
import org.robolectric.shadows.ShadowDialog;

/** Parcours Android réels avec préférences et rendu natif ; réseau publicitaire isolé. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk=35,qualifiers="fr-rFR-w390dp-h844dp-mdpi",shadows={AppFlowTest.AdEvents.class},
    instrumentedPackages={"fr.sportcore.ads"})
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class AppFlowTest {
 private ActivityController<MainActivity> controller;
 private MainActivity activity;
 private Context context;
 @Implements(value=fr.sportcore.ads.AdMobController.class,isInAndroidSdk=false)
 public static class AdEvents {
  static final List<String> completed=new ArrayList<>();
  @Implementation protected void onMatchCompleted(String id){
   ActiveDartsStore.Record record=new ActiveDartsStore(RuntimeEnvironment.getApplication()).load();
   assertNotNull(record);assertTrue("L’événement publicitaire doit suivre la sauvegarde finale",record.session.finished);
   completed.add(id);
  }
 }
 @Before public void setUp(){
  // FileProvider caches absolute paths; each Robolectric test has a fresh data directory.
  java.util.Map<?,?> providerCache=org.robolectric.util.ReflectionHelpers.getStaticField(androidx.core.content.FileProvider.class,"sCache");synchronized(providerCache){providerCache.clear();}
  AdEvents.completed.clear();context=RuntimeEnvironment.getApplication();
  for(String name:new String[]{"sportcore_profiles_v1","sportcore_settings_v1","darts_stats_1","darts_in_progress_v1","sportcore_ads_frequency_v1","sportcore_ads_matches_v2","darts_last_setup_v1","darts_celebrations_v1","darts_restore_journal_v1"})
   assertTrue(context.getSharedPreferences(name,Context.MODE_PRIVATE).edit().clear().commit());
  context.getSharedPreferences("sportcore_settings_v1",Context.MODE_PRIVATE).edit().putString("language","fr").commit();
  start();
 }
 private void start(){controller=Robolectric.buildActivity(MainActivity.class).setup().visible();activity=controller.get();idle();}
 @After public void tearDown(){if(controller!=null)controller.pause().stop().destroy();}
 private static void idle(){Shadows.shadowOf(Looper.getMainLooper()).idle();}
 private static String normalized(CharSequence s){return s==null?"":s.toString().trim().replaceAll("\\s+"," ");}
 private static List<View> descendants(View root){
  List<View> out=new ArrayList<>();out.add(root);
  if(root instanceof ViewGroup){ViewGroup group=(ViewGroup)root;for(int i=0;i<group.getChildCount();i++)out.addAll(descendants(group.getChildAt(i)));}
  return out;
 }
 private static View button(View root,String label){
  for(View v:descendants(root))if(v instanceof TextView&&normalized(((TextView)v).getText()).equals(normalized(label))&&v.isClickable())return v;
  throw new AssertionError("Action introuvable : "+label);
 }
 private View decor(){return activity.getWindow().getDecorView();}
 private void click(String label){button(decor(),label).performClick();idle();}
 private void openProfileMenu(String name,int item){
  for(View v:descendants(decor()))if(("Options du profil "+name).equals(v.getContentDescription()==null?null:v.getContentDescription().toString())){
   v.performClick();idle();android.widget.PopupMenu popup=org.robolectric.shadows.ShadowPopupMenu.getLatestPopupMenu();
   assertNotNull(popup);popup.getMenu().performIdentifierAction(item,0);idle();return;
  }
  throw new AssertionError("Options du profil absentes : "+name);
 }
 private static boolean hasText(View root,String text){
  for(View v:descendants(root))if(v instanceof TextView&&((TextView)v).getText().toString().contains(text)&&v.getVisibility()==View.VISIBLE)return true;
  return false;
 }
 private EditText editor(Dialog dialog){for(View v:descendants(dialog.getWindow().getDecorView()))if(v instanceof EditText)return (EditText)v;throw new AssertionError("Champ absent");}
 private Profile addProfile(String name){ProfileRepository repo=activity.profiles();repo.add(name);return repo.all().get(repo.all().size()-1);}
 private void selectFirstProfile(){
  for(View v:descendants(decor()))if(v instanceof Spinner&&"Sélection du joueur 1".contentEquals(v.getContentDescription())){
   ((Spinner)v).setSelection(1);idle();return;
  }
  throw new AssertionError("Sélecteur de profil absent");
 }
 private void completeCheckout(Profile profile){
  activity.openMode("checkout");idle();if(profile!=null)selectFirstProfile();click("Commencer");click("D Double");click("20");
  assertTrue(hasText(decor(),"MATCH TERMINÉ"));
 }
 @Test public void adsAreDisabledAndHaveNoAutomaticInitializer() throws Exception {
  fr.sportcore.ads.AdMobController ads=new fr.sportcore.ads.AdMobController(activity,fr.sportcore.ads.AdSettings.disabled());
  assertFalse(ads.enabled());assertNull(ads.createFooter());ads.start();
  activity.navigate(ScreenRoutes.SETTINGS);assertFalse(hasText(decor(),"Confidentialité des publicités"));
  for(View v:descendants(decor()))assertFalse(v.getClass().getName().contains(".ads.AdView"));
  android.content.pm.ApplicationInfo info=context.getPackageManager().getApplicationInfo(context.getPackageName(),android.content.pm.PackageManager.GET_META_DATA);
  assertTrue(info.metaData==null||!info.metaData.containsKey("com.google.android.gms.ads.APPLICATION_ID"));
  try{context.getPackageManager().getProviderInfo(new android.content.ComponentName(context,"com.google.android.gms.ads.MobileAdsInitProvider"),0);fail("L’initialisation automatique AdMob doit être absente");}
  catch(android.content.pm.PackageManager.NameNotFoundException expected){}
 }
 @Test public void advertisingEventOccursAfterTheWholeMatchAndNeverBetweenLegs(){
  activity.openMode("x01_301");activity.draft().setPlayerCount(1);activity.draft().setLegsToWin(2);
  activity.navigate(ScreenRoutes.MATCH_SETUP);click("Commencer");
  for(int leg=0;leg<2;leg++){
   for(int i=0;i<3;i++){click("T Triple");click("20");}
   click("T Triple");click("19");click("D Double");click("20");click("D Double");click("12");
   ActiveDartsStore.Record saved=new ActiveDartsStore(context).load();assertEquals(leg+1,saved.session.legs[0]);
   assertEquals(leg==1,saved.session.finished);assertEquals(leg==0?0:1,AdEvents.completed.size());
  }
  activity.navigate(ScreenRoutes.RESULT);assertEquals(1,AdEvents.completed.size());
 }
 @Test public void featuredCatalogueOpens501AndKeepsAllFifteenGames(){
  List<View> cards=new ArrayList<>();for(View v:descendants(decor()))if(v.isClickable()&&v.getContentDescription()!=null&&v.getContentDescription().toString().startsWith("Jouer à "))cards.add(v);
  assertEquals(15,cards.size());assertTrue(cards.get(0).getContentDescription().toString().startsWith("Jouer à 501."));
  cards.get(0).performClick();idle();assertEquals("x01_501",activity.draft().modeId);assertTrue(hasText(decor(),"Commencer"));
 }
 @Test public void profileMenuDeletionCanBeCancelledThenConfirmed(){
  Profile alice=addProfile("Alice");Profile bob=addProfile("Bob");activity.navigate(ScreenRoutes.PROFILES);
  openProfileMenu("Alice",2);android.app.AlertDialog dialog=org.robolectric.shadows.ShadowAlertDialog.getLatestAlertDialog();
  assertTrue(dialog.isShowing());dialog.getButton(android.content.DialogInterface.BUTTON_NEGATIVE).performClick();idle();assertEquals(2,activity.profiles().all().size());
  openProfileMenu("Alice",2);dialog=org.robolectric.shadows.ShadowAlertDialog.getLatestAlertDialog();dialog.getButton(android.content.DialogInterface.BUTTON_POSITIVE).performClick();idle();
  assertEquals(1,activity.profiles().all().size());assertEquals(bob.id,activity.profiles().all().get(0).id);assertFalse(hasText(decor(),alice.name));
 }
 @Test public void guestsCanPlayThreeDartsUndoAndResume(){
  activity.openMode("x01_501");idle();click("Commencer");
  for(int i=0;i<3;i++){click("T Triple");click("20");}
  ActiveDartsStore.Record saved=new ActiveDartsStore(context).load();
  assertEquals(321,saved.session.score[0]);assertEquals(1,saved.session.active);
  click("Annuler la dernière fléchette");saved=new ActiveDartsStore(context).load();
  assertEquals(381,saved.session.score[0]);assertEquals(0,saved.session.active);assertEquals(2,saved.session.dartsThrown());
  controller.pause().stop().destroy();start();click("Reprendre la partie");
  assertEquals(2,new ActiveDartsStore(context).load().session.dartsThrown());assertTrue(hasText(decor(),"AU TOUR DE INVITÉ 1"));
 }
 @Test public void finishedResultIsSavedImmediatelyAndRetractedOnUndo(){
  Profile alice=addProfile("Alice");completeCheckout(alice);
  LocalDartsStats stats=new LocalDartsStats(context);assertEquals(1,stats.forProfile(alice.id).zones[20][2]);
  assertTrue(hasText(decor(),"Tes statistiques sont enregistrées"));
  click("Annuler la dernière fléchette");assertEquals(0,stats.forProfile(alice.id).hitTotal);
  assertFalse(new ActiveDartsStore(context).load().session.finished);
  click("D Double");click("20");assertEquals(1,stats.forProfile(alice.id).hitTotal);
  click("Revanche");assertEquals(0,new ActiveDartsStore(context).load().session.dartsThrown());assertEquals(alice.id,activity.draft().profileId(0));
 }
 @Test public void finishedResultSurvivesActivityRecreationWithoutDuplicates(){
  Profile alice=addProfile("Alice");completeCheckout(alice);
  controller.recreate();activity=controller.get();idle();
  assertTrue(hasText(decor(),"MATCH TERMINÉ"));assertEquals(1,new LocalDartsStats(context).forProfile(alice.id).hitTotal);
 }
 @Test public void invalidProfileStaysOpenAndCancelChangesNothing(){
  activity.navigate(ScreenRoutes.PROFILES);click("Créer mon premier profil");Dialog dialog=ShadowDialog.getLatestDialog();
  editor(dialog).setText("   ");button(dialog.getWindow().getDecorView(),"Créer").performClick();idle();
  assertTrue(dialog.isShowing());assertTrue(hasText(dialog.getWindow().getDecorView(),"Choisis un nom"));assertTrue(activity.profiles().all().isEmpty());
  button(dialog.getWindow().getDecorView(),"Annuler").performClick();assertFalse(dialog.isShowing());assertTrue(activity.profiles().all().isEmpty());
  click("Créer mon premier profil");dialog=ShadowDialog.getLatestDialog();editor(dialog).setText("Alice");button(dialog.getWindow().getDecorView(),"Créer").performClick();idle();
  assertFalse(dialog.isShowing());assertEquals("Alice",activity.profiles().all().get(0).name);
 }
 @Test public void renameRejectsDuplicatesAndPreservesIdentityAndStats(){
  Profile alice=addProfile("Alice");addProfile("Bob");
  DartSession game=new DartSession("checkout",new String[]{"Alice"},1);game.throwDart(new DartThrow(20,2));new LocalDartsStats(context).save("old",game,new String[]{alice.id});
  activity.navigate(ScreenRoutes.PROFILES);openProfileMenu("Alice",1);Dialog dialog=ShadowDialog.getLatestDialog();editor(dialog).setText(" bob ");
  button(dialog.getWindow().getDecorView(),"Enregistrer").performClick();idle();assertTrue(dialog.isShowing());assertTrue(hasText(dialog.getWindow().getDecorView(),"Ce nom existe déjà"));
  editor(dialog).setText("Ada");button(dialog.getWindow().getDecorView(),"Enregistrer").performClick();idle();
  Profile renamed=activity.profiles().all().get(0);assertEquals(alice.id,renamed.id);assertEquals("Ada",renamed.name);assertEquals(1,new LocalDartsStats(context).forProfile(alice.id).hitTotal);
 }
 @Test public void largeControlsAreRememberedAfterRecreation(){
  activity.navigate(ScreenRoutes.SETTINGS);Switch toggle=null;for(View v:descendants(decor()))if(v instanceof Switch&&"Grandes commandes".contentEquals(v.getContentDescription()))toggle=(Switch)v;
  assertNotNull(toggle);toggle.performClick();idle();assertTrue(activity.largeControls());
  controller.recreate();activity=controller.get();idle();assertTrue(activity.largeControls());
  activity.openMode("x01_501");click("Commencer");View twenty=button(decor(),"20");assertEquals(60,twenty.getLayoutParams().height);
 }
 @Test public void nativeScreensRenderWithRealResources() throws Exception {
  android.widget.ImageView launcher=new android.widget.ImageView(activity);launcher.setImageResource(R.mipmap.ic_launcher);
  captureView(launcher,"12-icone-android",128,128);
  android.graphics.drawable.AdaptiveIconDrawable icon=(android.graphics.drawable.AdaptiveIconDrawable)activity.getDrawable(R.mipmap.ic_launcher);
  assertNotNull(icon.getMonochrome());
  launcher.setImageDrawable(new android.graphics.drawable.AdaptiveIconDrawable(new android.graphics.drawable.ColorDrawable(0xff183c60),icon.getMonochrome()));
  captureView(launcher,"13-icone-thematique",128,128);
  capture("01-catalogue");activity.navigate(ScreenRoutes.PROFILES);capture("02-profils-vides");
  activity.navigate(ScreenRoutes.SETTINGS);capture("03-reglages");
  Profile alice=addProfile("Alice");activity.navigate(ScreenRoutes.PROFILES);capture("04-profil");
  openProfileMenu("Alice",1);Dialog dialog=ShadowDialog.getLatestDialog();captureView(dialog.getWindow().getDecorView(),"05-editeur-profil",342,360);dialog.dismiss();
  activity.openMode("x01_501");capture("06-preparation");click("Commencer");capture("07-match");
  activity.navigate(ScreenRoutes.PLAY);activity.openMode("checkout");idle();
  // Le remplacement d'une partie demande une action explicite dans le dialogue.
  android.app.AlertDialog replace=org.robolectric.shadows.ShadowAlertDialog.getLatestAlertDialog();
  if(replace!=null&&replace.isShowing()){replace.getButton(android.content.DialogInterface.BUTTON_POSITIVE).performClick();idle();}
  selectFirstProfile();click("Commencer");click("D Double");click("20");capture("08-resultat");
  assertEquals(1,new LocalDartsStats(context).forProfile(alice.id).hitTotal);
  DartSession precision=new DartSession("x01_301",new String[]{"Alice"},1);
  for(int i=0;i<3;i++)precision.throwDart(new DartThrow(20,3));
  precision.throwDart(new DartThrow(19,3));precision.throwDart(new DartThrow(20,2));precision.throwDart(new DartThrow(12,2));
  assertTrue(precision.finished);new LocalDartsStats(context).save("precision-example",precision,new String[]{alice.id});
  activity.navigate(ScreenRoutes.PROFILES);capture("11-profil-precision");
 }
 @Test @Config(qualifiers="fr-rFR-w360dp-h640dp-mdpi")
 public void startActionStaysVisibleOnSmallPhone() throws Exception {
  activity.openMode("x01_501");idle();captureView(decor(),"10-preparation-compacte",360,640);
  View start=button(decor(),"Commencer");android.graphics.Rect rect=new android.graphics.Rect();
  assertTrue(start.getGlobalVisibleRect(rect));assertEquals(start.getHeight(),rect.height());assertTrue(rect.bottom<=640);
 }
 @Test @Config(qualifiers="fr-rFR-w800dp-h600dp-mdpi")
 public void tabletShowsScoreAndEveryScoringKeyTogether() throws Exception {
  activity.openMode("x01_501");click("Commencer");captureView(decor(),"09-match-tablette",800,600);
  for(String label:new String[]{"20","1","25","BULL","OUT","Annuler la dernière fléchette"}){
   View key=button(decor(),label);android.graphics.Rect rect=new android.graphics.Rect();
   assertTrue(label,key.getGlobalVisibleRect(rect));assertEquals(label,key.getHeight(),rect.height());assertTrue(label,rect.bottom<=600&&rect.right<=800);
  }
 }
 @Test public void sameProfileCannotOccupyTwoPlayerSlots(){
  addProfile("Alice");activity.openMode("x01_501");idle();
  for(View v:descendants(decor()))if(v instanceof Spinner&&v.getContentDescription()!=null&&v.getContentDescription().toString().startsWith("Sélection du joueur")){((Spinner)v).setSelection(1);}
  idle();click("Commencer");
  android.app.AlertDialog dialog=org.robolectric.shadows.ShadowAlertDialog.getLatestAlertDialog();assertNotNull(dialog);assertTrue(dialog.isShowing());assertNull(new ActiveDartsStore(context).load());
 }
 @Test @Config(sdk=26) @GraphicsMode(GraphicsMode.Mode.LEGACY)
 public void minimumAndroidVersionCanStartAndFinishAMatch(){
  assertNotNull(context.getDrawable(R.mipmap.ic_launcher));assertTrue(hasText(decor(),"À toi de jouer."));completeCheckout(null);assertTrue(new ActiveDartsStore(context).load().session.finished);
 }
 @Test public void unfinishedProfileNameSurvivesActivityRecreation(){
  activity.navigate(ScreenRoutes.PROFILES);click("Créer mon premier profil");Dialog dialog=ShadowDialog.getLatestDialog();editor(dialog).setText("Alice");
  controller.recreate();activity=controller.get();idle();dialog=ShadowDialog.getLatestDialog();assertTrue(dialog.isShowing());assertEquals("Alice",editor(dialog).getText().toString());assertTrue(activity.profiles().all().isEmpty());
  button(dialog.getWindow().getDecorView(),"Créer").performClick();idle();assertEquals("Alice",activity.profiles().all().get(0).name);
 }
 @Test public void themesPersistAcrossRecreationAndDoNotChangeTheSavedDarts() throws Exception {
  activity.openMode("x01_501");click("Commencer");click("20");
  String before=context.getSharedPreferences("darts_in_progress_v1",0).getString("current","");
  activity.navigate(ScreenRoutes.SETTINGS);
  String[] ids={"sisal","green","night","club"};int[] backgrounds={0xFFF5F0E6,0xFFECF5F0,0xFF111F2D,0xFFEDF3FA};
  for(int i=0;i<ids.length;i++){
   activity.setThemeId(ids[i]);idle();assertEquals(backgrounds[i],activity.getColor(fr.sportcore.ui.R.color.sport_background));
   assertEquals(ids[i],activity.themeId());activity.navigate(ScreenRoutes.PLAY);capture("14-theme-"+ids[i]+"-accueil");
   click("Reprendre la partie");capture("15-theme-"+ids[i]+"-match");
   assertEquals(before,context.getSharedPreferences("darts_in_progress_v1",0).getString("current",""));activity.navigate(ScreenRoutes.SETTINGS);
  }
  activity.setThemeId("night");controller.recreate();activity=controller.get();idle();assertEquals("night",activity.themeId());assertEquals(0xFF111F2D,activity.getColor(fr.sportcore.ui.R.color.sport_background));
  capture("16-reglages-themes");
 }
 @Test public void quickLaunchKeepsLastFormatAndHandlesDeletedProfiles(){
  Profile alice=addProfile("Alice");activity.openMode("checkout");selectFirstProfile();click("Commencer");click("D Double");click("20");click("Choisir un autre jeu");
  assertTrue(hasText(decor(),"TES DERNIERS RÉGLAGES"));activity.profiles().remove(alice.id);activity.navigate(ScreenRoutes.PLAY);click("Rejouer avec ces réglages");
  ActiveDartsStore.Record saved=new ActiveDartsStore(context).load();assertEquals("checkout",saved.session.mode);assertEquals("Invité 1",saved.session.names[0]);assertEquals("",saved.draft.profileId(0));assertEquals(0,saved.session.dartsThrown());
 }
 @Test public void setupSummaryTracksPlayerAndLegChoicesWithoutHidingStart(){
  activity.openMode("x01_501");idle();assertTrue(hasText(decor(),"501 · 2 joueurs · Premier à 1 leg"));click("+");assertTrue(hasText(decor(),"501 · 2 joueurs · Premier à 2 legs"));
  for(View v:descendants(decor()))if(v instanceof Spinner&&"Nombre de joueurs".contentEquals(v.getContentDescription()))((Spinner)v).setSelection(3);
  idle();assertTrue(hasText(decor(),"501 · 4 joueurs · Premier à 2 legs"));click("Commencer");assertEquals(4,new ActiveDartsStore(context).load().session.playerCount());
 }
 @Test public void scoringIsImmediateWithAnimationsDisabledAndPreferencesPersist(){
  activity.setReducedMotion(true);activity.setSounds(false);activity.setHaptics(true);activity.setSoundVolume(0);
  activity.openMode("x01_501");click("Commencer");click("T Triple");click("20");assertEquals(441,new ActiveDartsStore(context).load().session.score[0]);
  assertFalse(fr.sportcore.ui.SportMotion.enabled(activity));controller.recreate();activity=controller.get();idle();assertTrue(activity.reducedMotion());assertFalse(activity.sounds());assertTrue(activity.haptics());assertEquals(0,activity.soundVolume());
 }
 @Test public void shareCreatesReadableContentUriWithoutChangingStatistics() throws Exception {
  Profile alice=addProfile("Alice");completeCheckout(alice);
  String before=context.getSharedPreferences("darts_stats_1",0).getString("matches","");ActiveDartsStore.Record record=new ActiveDartsStore(context).load();
  android.content.Intent send=ResultShare.intent(activity,record.session,"Checkout");assertEquals("image/png",send.getType());android.net.Uri uri=send.getParcelableExtra(android.content.Intent.EXTRA_STREAM);
  assertEquals("content",uri.getScheme());assertTrue((send.getFlags()&android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)!=0);
  try(java.io.InputStream in=context.getContentResolver().openInputStream(uri)){Bitmap bitmap=android.graphics.BitmapFactory.decodeStream(in);assertNotNull(bitmap);assertEquals(1080,bitmap.getWidth());bitmap.recycle();}
  assertEquals(before,context.getSharedPreferences("darts_stats_1",0).getString("matches",""));assertFalse(MatchFeedback.claimCelebration(context,record.id));
  click("Annuler la dernière fléchette");click("D Double");click("20");assertFalse(MatchFeedback.claimCelebration(context,record.id));
  assertTrue(hasText(decor(),"Partager le résultat"));
 }
 @Test public void touchScoringCommitsOnlyOnReleaseAndExactlyOnce() throws Exception {
  activity.setSounds(false);activity.openMode("x01_501");click("Commencer");capture("17-saisie-tactile");
  View key=button(decor(),"20");long now=android.os.SystemClock.uptimeMillis();
  android.view.MotionEvent down=android.view.MotionEvent.obtain(now,now,android.view.MotionEvent.ACTION_DOWN,20,20,0);key.dispatchTouchEvent(down);down.recycle();idle();
  assertEquals(0,new ActiveDartsStore(context).load().session.dartsThrown());
  android.view.MotionEvent up=android.view.MotionEvent.obtain(now,now+50,android.view.MotionEvent.ACTION_UP,20,20,0);key.dispatchTouchEvent(up);up.recycle();idle();
  assertEquals(1,new ActiveDartsStore(context).load().session.dartsThrown());assertEquals(481,new ActiveDartsStore(context).load().session.score[0]);
 }
 @Test @Config(qualifiers="fr-rFR-w360dp-h640dp-mdpi")
 public void largeTextKeepsSetupActionVisibleAndThemeSelectable() throws Exception {
  RuntimeEnvironment.setFontScale(1.3f);controller.recreate();activity=controller.get();idle();activity.setLargeControls(true);activity.setThemeId("sisal");activity.openMode("x01_501");activity.draft().setPlayerCount(8);activity.draft().setLegsToWin(15);activity.navigate(ScreenRoutes.MATCH_SETUP);
  captureView(decor(),"18-grands-textes-preparation",360,640);View start=button(decor(),"Commencer");android.graphics.Rect rect=new android.graphics.Rect();assertTrue(start.getGlobalVisibleRect(rect));assertEquals(start.getHeight(),rect.height());assertTrue(rect.bottom<=640);
  assertTrue(hasText(decor(),"501 · 8 joueurs · Premier à 15 legs"));click("Commencer");assertEquals(8,new ActiveDartsStore(context).load().session.playerCount());RuntimeEnvironment.setFontScale(1f);
 }
 @Test public void sharedResultSupportsEightLongPlayerNames() throws Exception {
  String[] names=new String[8];for(int i=0;i<8;i++)names[i]="Joueur "+(i+1)+" au nom très long pour la carte du club";
  DartSession game=new DartSession("checkout",names,1);game.throwDart(new DartThrow(20,2));Bitmap card=ResultShare.card(activity,game,"Training Checkout");
  assertEquals(1080,card.getWidth());assertEquals(1494,card.getHeight());File dir=new File("build/reports/ui-captures");assertTrue(dir.isDirectory()||dir.mkdirs());
  try(FileOutputStream out=new FileOutputStream(new File(dir,"19-partage-huit-joueurs.png"))){assertTrue(card.compress(Bitmap.CompressFormat.PNG,100,out));}card.recycle();assertEquals(1,game.dartsThrown());
 }
 private void capture(String name) throws Exception {idle();captureView(decor(),name,390,844);}
 private void captureView(View view,String name,int width,int height) throws Exception {
  view.measure(View.MeasureSpec.makeMeasureSpec(width,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(height,View.MeasureSpec.EXACTLY));view.layout(0,0,width,height);idle();
  Bitmap bitmap=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);view.draw(new Canvas(bitmap));
  File dir=new File("build/reports/ui-captures");assertTrue(dir.isDirectory()||dir.mkdirs());
  try(FileOutputStream out=new FileOutputStream(new File(dir,name+".png"))){assertTrue(bitmap.compress(Bitmap.CompressFormat.PNG,100,out));}
  assertTrue(bitmap.getWidth()>0);bitmap.recycle();
 }
}
