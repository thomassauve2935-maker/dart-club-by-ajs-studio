package fr.dartsclub.app;
import android.content.Context;
import android.content.SharedPreferences;
import fr.sportcore.ui.SportFeedback;
import fr.sportdarts.engine.*;
import java.util.*;
/** Traduit un lancer déjà enregistré en un seul retour, sans modifier le moteur. */
final class MatchFeedback {
 static boolean maximum(List<DartThrow> volley){
  if(volley.size()!=3)return false;for(DartThrow d:volley)if(d.segment!=20||d.multiplier!=3)return false;return true;
 }
 static SportFeedback.Signal signal(DartSession game,int previousPlayer,int previousTurnDarts){
  if(game.finished)return SportFeedback.Signal.WIN;
  if(bust(game))return SportFeedback.Signal.ERROR;
  if(previousTurnDarts==2&&maximum(game.lastTurn()))return SportFeedback.Signal.MAXIMUM;
  if(game.active!=previousPlayer||game.turnDarts==0)return SportFeedback.Signal.TURN;
  return SportFeedback.Signal.DART;
 }
 static boolean bust(DartSession game){return game.lastNotice()==DartSession.Notice.BUST;}
 static String message(Context c,DartSession game,String[] names,SportFeedback.Signal signal){
  switch(signal){case MAXIMUM:return c.getString(R.string.darts_maximum);case ERROR:return c.getString(R.string.darts_bust);case TURN:return c.getString(R.string.darts_next_player,names[game.active]);default:return DartsText.status(c,game,names);}
 }
 static boolean claimCelebration(Context c,String matchId){
  SharedPreferences p=c.getSharedPreferences("darts_celebrations_v1",Context.MODE_PRIVATE);
  Set<String> done=new HashSet<>(p.getStringSet("matches",Collections.emptySet()));if(!done.add(matchId))return false;
  return p.edit().putStringSet("matches",done).commit();
 }
}
