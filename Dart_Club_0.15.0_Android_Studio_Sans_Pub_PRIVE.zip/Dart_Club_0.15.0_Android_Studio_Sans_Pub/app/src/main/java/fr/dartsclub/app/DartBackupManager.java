package fr.dartsclub.app;
import android.content.*;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
/** Sauvegarde portable, validation complète avant écriture et journal de restauration atomique. */
final class DartBackupManager {
 static final int MAX_BYTES=4*1024*1024;
 private final Context context;
 interface Committer {boolean commit(SharedPreferences.Editor editor);}
 private final Committer committer;
 private boolean commit(SharedPreferences.Editor editor){return committer.commit(editor);}
 private SharedPreferences pref(String name){return context.getSharedPreferences(name,Context.MODE_PRIVATE);}
 DartBackupManager(Context c){this(c,SharedPreferences.Editor::commit);}
 DartBackupManager(Context c,Committer writer){context=c;committer=writer;}
 static String read(InputStream in) throws IOException {
  if(in==null)throw new IOException("Fichier indisponible");ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int count;
  while((count=in.read(buf))!=-1){if(out.size()+count>MAX_BYTES)throw new IOException("Sauvegarde trop volumineuse (4 Mo maximum)");out.write(buf,0,count);}return out.toString(StandardCharsets.UTF_8.name());
 }
 String exportJson() throws JSONException {
  JSONObject data=snapshot();String raw=data.toString(2);validate(raw);return raw;
 }
 private JSONObject snapshot() throws JSONException {
  JSONObject settings=new JSONObject();Map<String,?> all=pref("sportcore_settings_v1").getAll();
  for(String k:new String[]{"language","theme","large_controls","sounds","haptics","volume","reduced_motion"})if(all.containsKey(k))settings.put(k,all.get(k));
  String active=pref("darts_in_progress_v1").getString("current",null),last=pref("darts_last_setup_v1").getString("setup",null);
  return new JSONObject().put("format","dart-club-backup").put("version",1)
   .put("profiles",new JSONArray(pref("sportcore_profiles_v1").getString("profiles","[]")))
   .put("matches",new JSONArray(pref("darts_stats_1").getString("matches","[]")))
   .put("active",active==null?JSONObject.NULL:new JSONObject(active))
   .put("lastSetup",last==null?JSONObject.NULL:new JSONObject(last)).put("settings",settings);
 }
 static JSONObject validate(String raw) throws JSONException {
  if(raw.getBytes(StandardCharsets.UTF_8).length>MAX_BYTES)throw new JSONException("4 Mo maximum");
  JSONObject data=new JSONObject(raw);if(!"dart-club-backup".equals(data.getString("format"))||data.getInt("version")!=1)throw new JSONException("Format de sauvegarde incompatible");
  JSONArray profiles=data.getJSONArray("profiles"),matches=data.getJSONArray("matches");Set<String> ids=new HashSet<>(),names=new HashSet<>();
  for(int i=0;i<profiles.length();i++){
   JSONObject p=profiles.getJSONObject(i);String id=p.getString("id"),name=p.getString("name");
   if(id.isEmpty()||id.length()>100||name.trim().isEmpty()||name.length()>50||!ids.add(id)||!names.add(name.trim().toLowerCase(Locale.ROOT)))throw new JSONException("Profils incorrects ou répétés");
  }
  Set<String> matchIds=new HashSet<>();
  for(int i=0;i<matches.length();i++){
   JSONObject m=matches.getJSONObject(i);JSONArray players=m.optJSONArray("ids");int count=players==null?(m.optBoolean("solo")?1:2):players.length();
   if(count<1||count>8)throw new JSONException("Joueurs incorrects");
   if(players!=null)for(int j=0;j<count;j++)if(!(players.get(j) instanceof String))throw new JSONException("Profil incorrect");
   String id=m.optString("matchId","");if(!id.isEmpty()&&!matchIds.add(id))throw new JSONException("Match répété");
   int winner=m.optInt("winner",-1);if(winner< -1||winner>=count)throw new JSONException("Résultat incorrect");
   // Les anciens formats id0/id1, points0, etc. sont conservés tels quels.
   for(String field:new String[]{"points","darts","checkouts"}){
    JSONArray values=m.optJSONArray(field);if(values!=null){if(values.length()!=count)throw new JSONException("Statistiques incorrectes");for(int j=0;j<count;j++)if(values.getInt(j)<0)throw new JSONException("Statistiques négatives");}
   }
   JSONArray events=m.getJSONArray("events");for(int j=0;j<events.length();j++){
    JSONObject e=events.getJSONObject(j);int player=e.getInt("player");if(player<0||player>=count)throw new JSONException("Lancer sans joueur");
    e.getInt("segment");if(e.has("multiplier"))e.getInt("multiplier"); // Zones historiques inconnues : conservées, exclues par le lecteur existant.
   }
  }
  if(!data.has("active")||!data.has("lastSetup"))throw new JSONException("Sauvegarde incomplète");
  if(!data.isNull("active"))try{ActiveDartsStore.parse(data.getJSONObject("active").toString());}catch(RuntimeException ex){throw new JSONException("Partie en cours incorrecte");}
  if(!data.isNull("lastSetup"))try{LastSetupStore.decode(data.getJSONObject("lastSetup"));}catch(RuntimeException ex){throw new JSONException("Configuration incorrecte");}
  JSONObject s=data.getJSONObject("settings");
  for(String k:new String[]{"large_controls","sounds","haptics","reduced_motion"})if(s.has(k)&&!(s.get(k) instanceof Boolean))throw new JSONException("Réglage incorrect");
  if(s.has("language")&&!Arrays.asList("auto","fr","en","es").contains(s.getString("language")))throw new JSONException("Unknown language");
  if(s.has("theme")&&!Arrays.asList("club","sisal","green","night").contains(s.getString("theme")))throw new JSONException("Thème inconnu");
  if(s.has("volume")&&(!(s.get("volume") instanceof Integer)||s.getInt("volume")<0||s.getInt("volume")>100))throw new JSONException("Volume incorrect");
  return data;
 }
 void restore(String raw) throws JSONException {
  JSONObject incoming=validate(raw);String before=snapshot().toString();
  // Le journal permet le retour à l'état précédent même si le processus est interrompu.
  if(!commit(pref("darts_restore_journal_v1").edit().putString("before",before)))throw new IllegalStateException("Sauvegarde de sécurité impossible");
  try{apply(incoming);if(!commit(pref("darts_restore_journal_v1").edit().clear()))throw new IllegalStateException("Restauration incomplète");}
  catch(RuntimeException ex){try{apply(new JSONObject(before));commit(pref("darts_restore_journal_v1").edit().clear());}catch(Exception rollback){ex.addSuppressed(rollback);}throw ex;}
 }
 void recover() {
  String before=pref("darts_restore_journal_v1").getString("before",null);if(before==null)return;
  try{apply(new JSONObject(before));if(!commit(pref("darts_restore_journal_v1").edit().clear()))throw new IllegalStateException("Journal non effacé");}
  catch(JSONException ex){throw new IllegalStateException("Sauvegarde de sécurité illisible",ex);}
 }
 private void write(String name,String key,String value){SharedPreferences.Editor edit=pref(name).edit();if(value==null)edit.remove(key);else edit.putString(key,value);if(!commit(edit))throw new IllegalStateException("Écriture impossible");}
 private void apply(JSONObject data) {
  try{
   write("sportcore_profiles_v1","profiles",data.getJSONArray("profiles").toString());
   write("darts_stats_1","matches",data.getJSONArray("matches").toString());
   write("darts_in_progress_v1","current",data.isNull("active")?null:data.getJSONObject("active").toString());
   write("darts_last_setup_v1","setup",data.isNull("lastSetup")?null:data.getJSONObject("lastSetup").toString());
   JSONObject s=data.getJSONObject("settings");SharedPreferences.Editor edit=pref("sportcore_settings_v1").edit();
   for(String k:new String[]{"language","theme","large_controls","sounds","haptics","volume","reduced_motion"}){
    edit.remove(k);if(!s.has(k))continue;Object v=s.get(k);if(v instanceof Boolean)edit.putBoolean(k,(Boolean)v);else if(v instanceof Integer)edit.putInt(k,(Integer)v);else if(v instanceof String)edit.putString(k,(String)v);
   }
   if(!commit(edit))throw new IllegalStateException("Réglages non enregistrés");
  }catch(JSONException ex){throw new IllegalStateException("Sauvegarde incorrecte",ex);}
 }
}
