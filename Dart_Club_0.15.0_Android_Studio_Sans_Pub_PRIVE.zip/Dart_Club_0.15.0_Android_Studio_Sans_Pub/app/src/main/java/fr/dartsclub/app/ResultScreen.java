package fr.dartsclub.app;

import android.app.Activity;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import fr.sportcore.ui.*;
import fr.sportdarts.engine.DartSession;
import java.util.Locale;

/** Résultat réel de la partie, avec actions indépendantes de l'enregistrement. */
public final class ResultScreen {
 public interface Listener {void again();void games();void undo();void retry();void share();}
 public void render(LinearLayout box,ScreenHost host,DartSession game,String[] names,String modeName,
     boolean linkedProfiles,boolean recorded,Listener actions){
  Activity c=host.context();boolean won=game.winner>=0;
  ScreenElements.heading(box,host,c.getString(fr.dartsclub.app.R.string.darts_match_complete),won?c.getString(R.string.darts_well_played,names[game.winner]):c.getString(fr.dartsclub.app.R.string.darts_game_complete),modeName);
  LinearLayout hero=SportUI.card(c);hero.setTag("result-hero");hero.setBackground(SportUI.highlightedCard(c,won));
  hero.addView(SportUI.eyebrow(c,won?c.getString(fr.dartsclub.app.R.string.darts_victory):game.playerCount()>1?c.getString(fr.dartsclub.app.R.string.darts_draw_eyebrow):c.getString(fr.dartsclub.app.R.string.darts_challenge_eyebrow)));
  SportUI.below(hero,SportUI.scoreText(c,won?names[game.winner]:game.playerCount()>1?c.getString(fr.dartsclub.app.R.string.darts_draw):c.getString(fr.dartsclub.app.R.string.darts_challenge_complete),38),12);
  String message=!recorded?c.getString(fr.dartsclub.app.R.string.darts_record_failed):
      linkedProfiles?c.getString(fr.dartsclub.app.R.string.darts_stats_saved):c.getString(fr.dartsclub.app.R.string.darts_play_profile_note);
  SportUI.below(hero,SportUI.text(c,message,13,c.getColor(fr.sportcore.ui.R.color.sport_muted),false),12);
  SportUI.below(box,hero,24);
  if(!recorded){TextView retry=SportUI.button(c,c.getString(fr.dartsclub.app.R.string.darts_retry_save),true,host.largeControls());
   retry.setOnClickListener(v->actions.retry());SportUI.below(box,retry,12);}
  LinearLayout numbers=SportUI.horizontal(c);
  if(DartSession.isX01(game.mode)){
   int player=won?game.winner:game.active,darts=0;
   for(int i=0;i<game.history().size();i++)if(game.eventPlayer(i)==player)darts++;
   addMetric(numbers,c,c.getString(fr.dartsclub.app.R.string.darts_average_result),String.format(ClubLanguage.locale(c),"%.1f",darts==0?0:game.validPoints(player)*3.0/darts));
   addMetric(numbers,c,c.getString(fr.dartsclub.app.R.string.darts_best_checkout),Integer.toString(game.bestCheckout(player)));
  }else{
   addMetric(numbers,c,c.getString(fr.dartsclub.app.R.string.darts_darts_played),Integer.toString(game.dartsThrown()));
   addMetric(numbers,c,c.getString(fr.dartsclub.app.R.string.darts_players),Integer.toString(game.playerCount()));
  }
  SportUI.below(box,numbers,16);
  LinearLayout table=SportUI.card(c);table.addView(SportUI.sectionTitle(c,c.getString(fr.dartsclub.app.R.string.darts_match_figures)));
  for(int p=0;p<game.playerCount();p++){
   LinearLayout row=SportUI.horizontal(c);
   TextView name=SportUI.text(c,names[p],16,c.getColor(p==game.winner?fr.sportcore.ui.R.color.sport_text:fr.sportcore.ui.R.color.sport_muted),p==game.winner);
   row.addView(name,new LinearLayout.LayoutParams(0,-2,1));
   TextView value=SportUI.text(c,metric(c,game,p),14,c.getColor(fr.sportcore.ui.R.color.sport_text),true);
   value.setGravity(Gravity.END);value.setPadding(SportUI.dp(c,12),0,0,0);row.addView(value);
   SportUI.below(table,row,14);
  }
  SportUI.below(box,table,16);
  TextView share=SportUI.button(c,c.getString(fr.dartsclub.app.R.string.darts_share_result),false,host.largeControls());share.setOnClickListener(v->actions.share());SportUI.below(box,share,16);
  TextView again=SportUI.button(c,c.getString(fr.dartsclub.app.R.string.darts_rematch),true,host.largeControls());again.setOnClickListener(v->actions.again());SportUI.below(box,again,20);
  TextView games=SportUI.button(c,c.getString(fr.dartsclub.app.R.string.darts_choose_other_game),false,host.largeControls());games.setOnClickListener(v->actions.games());SportUI.below(box,games,12);
  TextView undo=SportUI.withIcon(c,SportUI.button(c,c.getString(fr.dartsclub.app.R.string.darts_undo),false,host.largeControls()),fr.sportcore.ui.R.drawable.ic_club_undo);
  undo.setOnClickListener(v->actions.undo());SportUI.below(box,undo,12);
 }
 static String metric(android.content.Context c,DartSession game,int p){
  if(DartSession.isX01(game.mode))return DartsText.q(c,R.plurals.darts_legs,game.legs[p]);
  if(game.mode.equals("survivor")||(game.mode.equals("killer")&&game.playerCount()>1))return DartsText.q(c,R.plurals.darts_lives_count,game.lives[p]);
  if(game.mode.equals("around"))return game.progress(p)>=22?c.getString(R.string.darts_course_complete):c.getString(R.string.darts_stage,game.progress(p));
  return DartsText.q(c,R.plurals.darts_points,game.score[p]);
 }
 private void addMetric(LinearLayout row,Activity c,String caption,String value){
  LinearLayout card=SportUI.card(c);card.setPadding(SportUI.dp(c,12),SportUI.dp(c,12),SportUI.dp(c,12),SportUI.dp(c,12));
  card.addView(SportUI.scoreText(c,value,29));
  SportUI.below(card,SportUI.text(c,caption,11,c.getColor(fr.sportcore.ui.R.color.sport_muted),false),4);
  LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);if(row.getChildCount()>0)lp.leftMargin=SportUI.dp(c,12);row.addView(card,lp);
 }
}
