package fr.dartsclub.app;
import android.content.*;
import org.json.*;
import fr.sportcore.model.SessionDraft;
import fr.sportdarts.engine.*;
/** Journal des lancers conservé après chaque saisie ; restauration fiable pour 1..8 joueurs. */
public final class ActiveDartsStore {
 private final SharedPreferences pref;
 public ActiveDartsStore(Context c){pref=c.getSharedPreferences("darts_in_progress_v1",Context.MODE_PRIVATE);}
 public static final class Record {
  public SessionDraft draft;public DartSession session;public String id;
  Record(SessionDraft d,DartSession s,String id){draft=d;session=s;this.id=id;}
 }
 public void save(String id,SessionDraft d,DartSession s){
  try{
   JSONObject obj=new JSONObject();obj.put("id",id);obj.put("mode",d.modeId);obj.put("legs",d.legsToWin);
   JSONArray players=new JSONArray();
   for(int i=0;i<d.playerCount();i++){
    JSONObject p=new JSONObject();p.put("name",d.playerName(i));p.put("profileId",d.profileId(i));players.put(p);
   }
   obj.put("players",players);
   JSONArray actions=new JSONArray();for(DartThrow dart:s.history()){
    JSONArray a=new JSONArray();a.put(dart.segment);a.put(dart.multiplier);actions.put(a);
   }
   obj.put("events",actions);
   if(!pref.edit().putString("current",obj.toString()).commit())throw new IllegalStateException("Sauvegarde partie échouée");
  }catch(JSONException ex){throw new IllegalStateException("Partie non sérialisable",ex);}
 }
 public Record load(){
  String raw=pref.getString("current",null);if(raw==null)return null;
  return parse(raw);
 }
 static Record parse(String raw){
  try{
   JSONObject obj=new JSONObject(raw);SessionDraft d=new SessionDraft(obj.getString("mode"));
   JSONArray players=obj.optJSONArray("players");
   if(players!=null){
    d.setPlayerCount(players.length());
    for(int i=0;i<players.length();i++){
     JSONObject p=players.getJSONObject(i);d.setPlayer(i,p.getString("name"),p.optString("profileId",""));
    }
   }else{
    // Compatibilité avec les sauvegardes V0.5 à deux joueurs.
    d.setPlayer(0,obj.getString("p1"),obj.optString("id1",""));
    d.setPlayer(1,obj.getString("p2"),obj.optString("id2",""));
    if(DartSession.isSolo(d.modeId))d.setPlayerCount(1);
   }
   d.setLegsToWin(obj.getInt("legs"));
   if(!LastSetupStore.validMode(d.modeId)||!d.hasValidPlayers())throw new JSONException("Configuration incorrecte");
   for(String name:d.names())if(name.length()>50)throw new JSONException("Nom trop long");
   java.util.List<DartThrow> history=new java.util.ArrayList<>();
   JSONArray arr=obj.getJSONArray("events");for(int i=0;i<arr.length();i++){
    JSONArray hit=arr.getJSONArray(i);if(hit.length()!=2)throw new JSONException("Lancer incorrect");history.add(new DartThrow(hit.getInt(0),hit.getInt(1)));
   }
   DartSession session=DartSession.restore(d.modeId,d.names(),d.legsToWin,history);
   String id=obj.getString("id");if(id.isEmpty()||id.length()>100)throw new JSONException("Identifiant incorrect");
   return new Record(d,session,id);
  }catch(Exception ex){throw new IllegalStateException("Impossible de restaurer la partie. Sauvegarde conservée.",ex);}
 }
 public void clear(){pref.edit().remove("current").apply();}
}
