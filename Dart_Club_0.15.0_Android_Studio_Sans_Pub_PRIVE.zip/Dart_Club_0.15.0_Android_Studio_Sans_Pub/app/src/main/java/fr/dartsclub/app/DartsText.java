package fr.dartsclub.app;
import android.content.Context;
import fr.sportcore.ui.ClubLanguage;
import fr.sportdarts.engine.*;
final class DartsText {
 private DartsText(){}
 static String q(Context c,int key,int count){return ClubLanguage.quantity(c,key,count);}
 static String dart(Context c,DartThrow d){return d.label();} // S/D/T, BULL and OUT are standard score notation in all three languages.
 static String status(Context c,DartSession g,String[] names){
  if(g.finished)return g.winner<0?c.getString(R.string.darts_challenge_complete):c.getString(R.string.darts_win_status,names[g.winner]);
  switch(g.mode){
   case "cricket":return c.getString(R.string.darts_cricket_goal);
   case "around":return c.getString(R.string.darts_goal,g.progress(g.active)>20?"BULL":Integer.toString(g.progress(g.active)));
   case "bobs27":return c.getString(R.string.darts_double_goal,g.round+1);
   case "survivor":return c.getString(R.string.darts_survivor_goal,g.roundTarget(),q(c,R.plurals.darts_lives_count,g.lives[g.active]));
   case "killer":return g.playerCount()==1?c.getString(R.string.darts_killer_solo,g.killerSector(0)):c.getString(R.string.darts_killer_others);
   case "jackpot":return c.getString(R.string.darts_jackpot_goal,g.roundTarget());
   case "king":return c.getString(R.string.darts_king_goal,g.roundTarget());
   case "shanghai":return c.getString(R.string.darts_shanghai_goal,g.round+1,g.roundTarget());
   case "contract":return c.getString(R.string.darts_contract_goal,q(c,R.plurals.darts_points,40+g.round*10));
   case "pro_training":return c.getString(R.string.darts_training_goal,q(c,R.plurals.darts_turns_left,Math.max(0,10-g.round)));
   case "double_nothing":return c.getString(R.string.darts_double_required);
   default:return c.getString(R.string.darts_remaining_score);
  }
 }
 static String notice(Context c,DartSession g){
  switch(g.lastNotice()){
   case BUST:return c.getString(R.string.darts_bust);case LEG_WON:return c.getString(R.string.darts_new_leg);
   case MATCH_COMPLETE:return c.getString(R.string.darts_notice_match);case CHALLENGE_COMPLETE:return c.getString(R.string.darts_challenge_complete);default:return "";
  }
 }
}
