package fr.dartsclub.app.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;
import java.util.Locale;

/**
 * Cible vectorielle Android, réutilisable dans les profils et les futurs écrans.
 * La carte de chaleur utilise 5 CLASSES DISCRÈTES, pas un dégradé continu :
 * une couleur propre aux simples, doubles et triples de chaque numéro.
 * Les deux surfaces simples partagent le compteur simple ; 25 et bull sont séparés.
 */
public final class DartboardView extends View {
 public static final int HEAT_NONE=0xFF383D48;
 public static final int HEAT_RARE=0xFF478FD9;
 public static final int HEAT_MIDDLE=0xFFF1CD59;
 public static final int HEAT_FREQUENT=0xFFFF9140;
 public static final int HEAT_MAX=0xFFFF3559;
 private static final int[] ORDER={20,1,18,4,13,6,10,15,2,17,3,19,7,16,8,11,14,9,12,5};
 private static final float[] RING_RADII={49,57,83,90};
 private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
 private final Path segmentPath=new Path();
 private final RectF outerBounds=new RectF(),innerBounds=new RectF();
 private final int[][] hits=new int[26][4];
 private boolean heatMode=false;
 private int maximum=0;

 public DartboardView(Context c){super(c);setContentDescription(getContext().getString(fr.dartsclub.app.R.string.darts_board));}
 public void setHeat(int[][] counts){
  maximum=0;
  for(int i=0;i<hits.length;i++){
   for(int multiplier=0;multiplier<hits[i].length;multiplier++){
    boolean valid=((i>=1&&i<=20)||i==25)&&multiplier>=1&&multiplier<=(i==25?2:3);
    hits[i][multiplier]=valid&&counts!=null&&i<counts.length&&counts[i]!=null&&multiplier<counts[i].length
        ?Math.max(0,counts[i][multiplier]):0;
    maximum=Math.max(maximum,hits[i][multiplier]);
   }
  }
  heatMode=true;
  if(maximum==0){setContentDescription(getContext().getString(fr.dartsclub.app.R.string.darts_board_empty));}
  else{
   int best=1,bestMultiplier=1;
   for(int i=1;i<hits.length;i++)for(int multiplier=1;multiplier<hits[i].length;multiplier++){
    if(hits[i][multiplier]>hits[best][bestMultiplier]){best=i;bestMultiplier=multiplier;}
   }
   String zone=best==25?getContext().getString(bestMultiplier==2?fr.dartsclub.app.R.string.darts_bull_50:fr.dartsclub.app.R.string.darts_outer_bull)
       :getContext().getString(bestMultiplier==3?fr.dartsclub.app.R.string.darts_zone_treble:bestMultiplier==2?fr.dartsclub.app.R.string.darts_zone_double:fr.dartsclub.app.R.string.darts_zone_single,best);
   setContentDescription(getContext().getString(fr.dartsclub.app.R.string.darts_board_a11y,zone,fr.sportcore.ui.ClubLanguage.quantity(getContext(),fr.dartsclub.app.R.plurals.darts_hits,hits[best][bestMultiplier])));
  }
  invalidate();
 }
 public void plain(){heatMode=false;setContentDescription(getContext().getString(fr.dartsclub.app.R.string.darts_board_plain));invalidate();}
 public static int intensityColor(int count,int max){
  if(count<=0||max<=0)return HEAT_NONE;
  float proportion=count/(float)max;
  if(proportion<.25f)return HEAT_RARE;
  if(proportion<.50f)return HEAT_MIDDLE;
  if(proportion<.75f)return HEAT_FREQUENT;
  return HEAT_MAX;
 }
 @Override protected void onMeasure(int wSpec,int hSpec){
  int desired=MeasureSpec.getSize(wSpec);
  if(MeasureSpec.getMode(wSpec)==MeasureSpec.UNSPECIFIED)desired=260;
  if(MeasureSpec.getMode(hSpec)!=MeasureSpec.UNSPECIFIED)desired=Math.min(desired,MeasureSpec.getSize(hSpec));
  setMeasuredDimension(desired,desired);
 }
 private void circle(Canvas c,float radius,int color){
  p.reset();p.setAntiAlias(true);p.setStyle(Paint.Style.FILL);p.setColor(color);
  c.drawCircle(0,0,radius,p);
 }
 private void outline(Canvas c,float radius,int color,float thickness){
  p.reset();p.setAntiAlias(true);p.setColor(color);p.setStyle(Paint.Style.STROKE);
  p.setStrokeWidth(thickness);c.drawCircle(0,0,radius,p);
 }
 private void segment(Canvas c,float outer,float inner,float angle,int color){
  Path shape=segmentPath;shape.reset();RectF r1=outerBounds;r1.set(-outer,-outer,outer,outer);
  shape.arcTo(r1,angle,18);
  if(inner>0){RectF r2=innerBounds;r2.set(-inner,-inner,inner,inner);
   shape.arcTo(r2,angle+18,-18);}else{shape.lineTo(0,0);}
  shape.close();p.reset();p.setAntiAlias(true);p.setStyle(Paint.Style.FILL);p.setColor(color);
  c.drawPath(shape,p);
 }
 private int colorFor(int sector,int multiplier,int fallback){
  return heatMode?intensityColor(hits[sector][multiplier],maximum):fallback;
 }
 @Override protected void onDraw(Canvas c){
  super.onDraw(c);if(getWidth()==0||getHeight()==0)return;
  c.save();c.translate(getWidth()/2f,getHeight()/2f);
  c.scale(Math.min(getWidth(),getHeight())/244f,Math.min(getWidth(),getHeight())/244f);
  // Anneau extérieur sobre : séparation graphique avec les cartes du profil.
  circle(c,113,0xFF0C0D11);circle(c,109,0xFF343844);circle(c,105,0xFF0D1017);
  circle(c,94,0xFF181A20);circle(c,91,0xFF12141A);
  for(int i=0;i<ORDER.length;i++){
   int seg=ORDER[i];float start=-99+i*18f;
   int single=i%2==0?0xFFEAE7DA:0xFF24252B;
   int band=i%2==0?0xFFC92746:0xFF168C60;
   // Un lancer = un impact, sans pondération par les points du double/triple.
   segment(c,90,0,start,colorFor(seg,1,single));
   segment(c,90,83,start,colorFor(seg,2,band));
   segment(c,57,49,start,colorFor(seg,3,band));
  }
  // Contours homogènes et nets : doubles, triples et séparations des 20 secteurs.
  for(int i=0;i<20;i++){
   double a=Math.toRadians(-99+i*18);
   p.reset();p.setAntiAlias(true);p.setStyle(Paint.Style.STROKE);
   p.setColor(0xFF12151D);p.setStrokeWidth(1.25f);
   c.drawLine(0,0,(float)(90*Math.cos(a)),(float)(90*Math.sin(a)),p);
  }
  for(float r:RING_RADII)outline(c,r,0xFF13151A,1.25f);
  outline(c,91,0xFF686D79,1.2f);
  // Bull et outer bull : double contour pour le distinguer du dernier secteur.
  int outerBull=colorFor(25,1,0xFF168C60);
  circle(c,14,outerBull);outline(c,14,0xFF11151B,1.4f);
  circle(c,6,colorFor(25,2,0xFFCA2946));
  outline(c,6,0xFF11151B,1.2f);
  p.reset();p.setAntiAlias(true);p.setColor(0xFFF9FAFC);
  p.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD));
  p.setTextAlign(Paint.Align.CENTER);p.setTextSize(12.5f);
  for(int i=0;i<ORDER.length;i++){
   double a=Math.toRadians(-90+i*18);
   float x=(float)(101*Math.cos(a)),y=(float)(101*Math.sin(a));
   c.drawText(Integer.toString(ORDER[i]),x,y+4.4f,p);
  }
  c.restore();
 }
}
