package fr.dartsclub.app;
import android.app.*;
import android.view.*;
import android.widget.*;
import fr.sportdarts.engine.*;
import fr.sportcore.ui.*;
/** One shared keypad for all modes. No extra validation: three darts switch automatically. */
public final class MatchScreen {
 static String displayScore(DartSession game,int p){return (game.mode.equals("survivor")||game.mode.equals("killer"))?""+game.lives[p]:(game.mode.equals("around")?(game.progress(p)>20?"BULL":""+game.progress(p)):""+game.score[p]);}
 public interface Listener {void hit(DartThrow hit);void undo();void leave();}
 public void render(LinearLayout box,Activity c,DartSession game,String[] names,String modeLabel,boolean large,Listener actions){
  int white=c.getColor(fr.sportcore.ui.R.color.sport_text),muted=c.getColor(fr.sportcore.ui.R.color.sport_muted);
  LinearLayout head=SportUI.horizontal(c);
  TextView back=SportUI.iconButton(c,fr.sportcore.ui.R.drawable.ic_club_back,c.getString(fr.dartsclub.app.R.string.darts_leave_match));
  back.setOnClickListener(v->actions.leave());head.addView(back,new LinearLayout.LayoutParams(SportUI.dp(c,48),SportUI.dp(c,48)));
  LinearLayout title=SportUI.vertical(c,0);title.setPadding(SportUI.dp(c,12),0,SportUI.dp(c,8),0);
  title.addView(SportUI.eyebrow(c,c.getString(fr.dartsclub.app.R.string.darts_club_match)));
  TextView mode=SportUI.scoreText(c,game.mode.startsWith("x01_")?c.getString(R.string.darts_double_out_title,modeLabel):modeLabel,22);SportUI.below(title,mode,4);
  head.addView(title,new LinearLayout.LayoutParams(0,-2,1));
  TextView undo=SportUI.iconButton(c,fr.sportcore.ui.R.drawable.ic_club_undo,c.getString(fr.dartsclub.app.R.string.darts_undo));
  undo.setContentDescription(c.getString(fr.dartsclub.app.R.string.darts_undo_turn_a11y));
  undo.setOnClickListener(v->actions.undo());head.addView(undo,new LinearLayout.LayoutParams(SportUI.dp(c,48),SportUI.dp(c,48)));
  SportUI.below(box,head,0);
  boolean wide=c.getResources().getConfiguration().screenWidthDp>=700;
  LinearLayout scoreBox=box,entryBox=box;
  if(wide){
   LinearLayout columns=SportUI.horizontal(c);columns.setGravity(Gravity.TOP);
   scoreBox=SportUI.vertical(c,0);entryBox=SportUI.vertical(c,0);
   columns.addView(scoreBox,new LinearLayout.LayoutParams(0,-2,304f));
   LinearLayout.LayoutParams entrySize=new LinearLayout.LayoutParams(0,-2,416f);entrySize.leftMargin=SportUI.dp(c,24);columns.addView(entryBox,entrySize);
   SportUI.below(box,columns,12);
  }
  TextView playerTitle=SportUI.eyebrow(c,c.getString(R.string.darts_player_turn,names[game.active]));
  playerTitle.setSingleLine(true);playerTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
  playerTitle.setTag("active-player");playerTitle.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
  SportUI.below(scoreBox,playerTitle,wide?0:20);
  HorizontalScrollView scroll=new HorizontalScrollView(c);scroll.setHorizontalScrollBarEnabled(false);scroll.setFillViewport(true);
  LinearLayout scores=SportUI.horizontal(c);
  int available=c.getResources().getConfiguration().screenWidthDp-(c.getResources().getConfiguration().screenWidthDp>=600?56:48);
  if(wide)available=Math.round((available-24)*304f/720f);
  int cardWidth=game.playerCount()<=2?Math.min(320,(available-(game.playerCount()-1)*8)/game.playerCount()):148;
  for(int p=0;p<game.playerCount();p++){
   LinearLayout card=SportUI.card(c);
   card.setPadding(SportUI.dp(c,12),SportUI.dp(c,12),SportUI.dp(c,12),SportUI.dp(c,12));
   boolean selected=p==game.active;
   card.setBackground(SportUI.highlightedCard(c,selected));
   TextView name=SportUI.text(c,names[p].toUpperCase(ClubLanguage.locale(c)),12,muted,true);
   name.setSingleLine(true);name.setEllipsize(android.text.TextUtils.TruncateAt.END);card.addView(name);
   String display=displayScore(game,p);
   int scoreSize=selected?(large?80:76):52;
   TextView value=SportUI.scoreText(c,display,scoreSize);value.setTag("score-"+p);value.setGravity(Gravity.CENTER_VERTICAL);
   value.setTextColor(c.getColor(selected?fr.sportcore.ui.R.color.sport_accent:fr.sportcore.ui.R.color.sport_text));
   value.setAutoSizeTextTypeUniformWithConfiguration(28,scoreSize,2,android.util.TypedValue.COMPLEX_UNIT_SP);
   LinearLayout.LayoutParams valueSize=new LinearLayout.LayoutParams(-1,SportUI.dp(c,large?88:80));valueSize.topMargin=SportUI.dp(c,4);card.addView(value,valueSize);
   String label=game.mode.equals("survivor")?c.getString(fr.dartsclub.app.R.string.darts_lives):
     game.mode.equals("around")?c.getString(fr.dartsclub.app.R.string.darts_next_target):
     game.mode.equals("killer")?c.getString(R.string.darts_killer_lives,game.killerSector(p)):
     (DartSession.isX01(game.mode)?c.getString(R.string.darts_legs_score,game.legs[p]):c.getString(fr.dartsclub.app.R.string.darts_points_marks));
   TextView sub=SportUI.text(c,label,11,muted,false);
   SportUI.below(card,sub,2);
   LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(SportUI.dp(c,Math.max(120,cardWidth)),-2);
   if(p>0)cp.leftMargin=SportUI.dp(c,8);scores.addView(card,cp);
  }
  scroll.addView(scores);SportUI.below(scoreBox,scroll,10);
  if(game.playerCount()>2){
   TextView hint=SportUI.text(c,DartsText.q(c,R.plurals.darts_swipe_players,game.playerCount()),12,muted,false);
   SportUI.below(scoreBox,hint,2);
   final int position=game.active,offset=cardWidth+8;
   scroll.post(()->scroll.smoothScrollTo(position*SportUI.dp(c,offset),0));
  }
  if(game.mode.equals("cricket"))cricketMarks(scoreBox,c,game,names);
  TextView status=SportUI.text(c,DartsText.status(c,game,names),12,muted,false);
  status.setTag("match-status");status.setMinHeight(SportUI.dp(c,18));status.setSingleLine(true);status.setEllipsize(android.text.TextUtils.TruncateAt.END);status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);status.setGravity(Gravity.CENTER);SportUI.below(scoreBox,status,9);
  TextView currentTitle=SportUI.eyebrow(c,c.getString(R.string.darts_visit_total,DartsText.q(c,R.plurals.darts_points,game.turnTotal)));
  SportUI.below(scoreBox,currentTitle,16);
  addDartRow(scoreBox,c,game.currentTurn(),false);
  if(game.lastTurnPlayer()>=0){
   StringBuilder lastDarts=new StringBuilder();for(DartThrow dart:game.lastTurn()){
    if(lastDarts.length()>0)lastDarts.append(" · ");lastDarts.append(dart.label());
   }
   TextView last=SportUI.text(c,c.getString(R.string.darts_last_visit,names[game.lastTurnPlayer()],lastDarts.toString()),12,muted,false);
   SportUI.below(scoreBox,last,8);
  }
  if(game.lastNotice()!=DartSession.Notice.NONE){
   TextView info=SportUI.text(c,DartsText.notice(c,game),15,c.getColor(fr.sportcore.ui.R.color.sport_accent),true);
   info.setGravity(Gravity.CENTER);SportUI.below(scoreBox,info,6);
  }
  // Two toggles only. They reset after each dart, avoiding accidental repeated multipliers.
  LinearLayout multipliers=SportUI.horizontal(c);
  TextView dbl=SportUI.button(c,c.getString(fr.dartsclub.app.R.string.darts_double),false,false);
  TextView tri=SportUI.button(c,c.getString(fr.dartsclub.app.R.string.darts_treble),false,false);
  int[] multiplier={1};
  View.OnClickListener update=v->{
   int value=v==dbl?2:3;multiplier[0]=multiplier[0]==value?1:value;
   dbl.setText(multiplier[0]==2?c.getString(fr.dartsclub.app.R.string.darts_double_selected):c.getString(fr.dartsclub.app.R.string.darts_double));
   tri.setText(multiplier[0]==3?c.getString(fr.dartsclub.app.R.string.darts_treble_selected):c.getString(fr.dartsclub.app.R.string.darts_treble));
   SportUI.toggleState(c,dbl,multiplier[0]==2);
   SportUI.toggleState(c,tri,multiplier[0]==3);
  };
  dbl.setOnClickListener(update);tri.setOnClickListener(update);
  LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,SportUI.dp(c,large?60:48),1);
  LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,SportUI.dp(c,large?60:48),1);bp.leftMargin=SportUI.dp(c,12);
  multipliers.addView(dbl,ap);multipliers.addView(tri,bp);SportUI.below(entryBox,multipliers,wide?0:12);
  int[] numbers={20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1};
  for(int row=0;row<5;row++){
   LinearLayout line=SportUI.horizontal(c);
   for(int col=0;col<4;col++){
    int number=numbers[row*4+col];
    TextView button=SportUI.scoreKey(c,""+number);
    button.setOnClickListener(v->actions.hit(new DartThrow(number,multiplier[0])));
    LinearLayout.LayoutParams param=new LinearLayout.LayoutParams(0,SportUI.dp(c,large?60:48),1);
    if(col>0)param.leftMargin=SportUI.dp(c,8);line.addView(button,param);
   }
   SportUI.below(entryBox,line,8);
  }
  LinearLayout last=SportUI.horizontal(c);
  String[] labels={"25","BULL","OUT"};int[][] scoresArr={{25,1},{25,2},{0,1}};
  for(int i=0;i<3;i++){
   final int seg=scoresArr[i][0],mul=scoresArr[i][1];
   TextView button=SportUI.scoreKey(c,labels[i]);
   button.setOnClickListener(v->actions.hit(new DartThrow(seg,mul)));
   LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,SportUI.dp(c,large?60:48),1);
   if(i>0)cp.leftMargin=SportUI.dp(c,8);last.addView(button,cp);
  }
  SportUI.below(entryBox,last,8);
  TextView lowerUndo=SportUI.withIcon(c,SportUI.button(c,c.getString(fr.dartsclub.app.R.string.darts_undo),false,large),fr.sportcore.ui.R.drawable.ic_club_undo);
  lowerUndo.setContentDescription(c.getString(fr.dartsclub.app.R.string.darts_undo_recorded_a11y));
  lowerUndo.setOnClickListener(v->actions.undo());
  SportUI.below(entryBox,lowerUndo,12);
 }
 private void addDartRow(LinearLayout box,Activity c,java.util.List<DartThrow> throwsList,boolean subdued){
  LinearLayout row=SportUI.horizontal(c);
  for(int i=0;i<3;i++){
   String label=i<throwsList.size()?throwsList.get(i).label():"—";
   LinearLayout cell=SportUI.card(c);
   cell.setPadding(SportUI.dp(c,8),SportUI.dp(c,8),SportUI.dp(c,8),SportUI.dp(c,8));
   cell.setMinimumHeight(SportUI.dp(c,56));
   TextView value=SportUI.scoreText(c,label,26);value.setGravity(Gravity.CENTER);
   cell.setContentDescription(c.getString(R.string.darts_dart_a11y,i+1,label));
   if(!subdued&&i==throwsList.size()&&i<3){
    cell.setBackground(SportUI.highlightedCard(c,true));
    value.setTextColor(c.getColor(fr.sportcore.ui.R.color.sport_accent));
   }
   SportUI.below(cell,value,2);
   LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);
   if(i>0)p.leftMargin=SportUI.dp(c,8);row.addView(cell,p);
  }
  SportUI.below(box,row,6);
 }
 private void cricketMarks(LinearLayout box,Activity c,DartSession game,String[] names){
  TextView button=SportUI.withIcon(c,SportUI.button(c,c.getString(fr.dartsclub.app.R.string.darts_view_cricket),false,false),fr.sportcore.ui.R.drawable.ic_club_target);
  button.setOnClickListener(v->{
   StringBuilder table=new StringBuilder();int[] sectors={20,19,18,17,16,15,25};
   for(int p=0;p<game.playerCount();p++){
    if(p>0)table.append("\n\n");table.append(c.getString(R.string.darts_player_points,names[p],DartsText.q(c,R.plurals.darts_points,game.score[p])));
    for(int k=0;k<sectors.length;k++){
     int field=sectors[k]==25?6:sectors[k]-15;
     table.append(sectors[k]==25?"B":""+sectors[k]).append(": ").append(game.mark(p,field)).append("/3  ");
    }
   }
   new AlertDialog.Builder(c).setTitle(c.getString(fr.dartsclub.app.R.string.darts_cricket_marks)).setMessage(table.toString())
    .setPositiveButton(c.getString(fr.dartsclub.app.R.string.darts_close),null).show();
  });
  SportUI.below(box,button,7);
 }
}
