package fr.dartsclub.app;
import android.content.*;
import fr.sportcore.model.*;
import fr.sportdarts.DartsSpec;
import org.json.*;
import java.util.*;
/** Dernière configuration réussie ; les profils supprimés deviennent des invités. */
final class LastSetupStore {
 private final SharedPreferences prefs;
 LastSetupStore(Context c){prefs=c.getSharedPreferences("darts_last_setup_v1",Context.MODE_PRIVATE);}
 static boolean validMode(String id){for(ModeSpec m:new DartsSpec().games())if(m.id.equals(id))return true;return false;}
 static JSONObject encode(SessionDraft d) throws JSONException {
  JSONObject out=new JSONObject().put("mode",d.modeId).put("legs",d.legsToWin);JSONArray players=new JSONArray();
  for(int i=0;i<d.playerCount();i++)players.put(new JSONObject().put("name",d.playerName(i)).put("profileId",d.profileId(i)));
  return out.put("players",players);
 }
 static SessionDraft decode(JSONObject obj) throws JSONException {
  String mode=obj.getString("mode");if(!validMode(mode))throw new JSONException("Jeu inconnu");
  SessionDraft d=new SessionDraft(mode);d.setLegsToWin(obj.getInt("legs"));JSONArray players=obj.getJSONArray("players");d.setPlayerCount(players.length());
  for(int i=0;i<players.length();i++){
   JSONObject p=players.getJSONObject(i);String name=p.getString("name"),id=p.optString("profileId","");
   if(name.trim().isEmpty()||name.length()>50||id.length()>100)throw new JSONException("Joueur incorrect");d.setPlayer(i,name,id);
  }
  if(!d.hasValidPlayers())throw new JSONException("Joueurs répétés");return d;
 }
 void save(SessionDraft d){try{prefs.edit().putString("setup",encode(d).toString()).apply();}catch(JSONException ex){throw new IllegalStateException(ex);}}
 SessionDraft load(ProfileRepository repo){
  String raw=prefs.getString("setup",null);if(raw==null)return null;
  try{
   SessionDraft d=decode(new JSONObject(raw));Map<String,Profile> profiles=new HashMap<>();for(Profile p:repo.all())profiles.put(p.id,p);
   for(int i=0;i<d.playerCount();i++)if(!d.profileId(i).isEmpty()){
    Profile p=profiles.get(d.profileId(i));d.setPlayer(i,p==null?"Invité "+(i+1):p.name,p==null?"":p.id);
   }
   return d;
  }catch(JSONException|IllegalArgumentException ex){return null;}
 }
}
