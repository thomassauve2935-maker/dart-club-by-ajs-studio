package fr.dartsclub.app;
import android.app.Activity;
import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.text.TextUtils;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import fr.sportdarts.engine.DartSession;
import java.io.*;
import java.util.Locale;
/** Carte locale indépendante des statistiques. Le partage est toujours choisi par le joueur. */
final class ResultShare {
 static Bitmap card(Activity c,DartSession game,String mode){return card(c,game,game.names,mode);}
 static Bitmap card(Activity c,DartSession game,String[] names,String mode){
  int width=1080,height=790+game.playerCount()*88;
  Bitmap image=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(image);Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
  int bg=c.getColor(fr.sportcore.ui.R.color.sport_background),ink=c.getColor(fr.sportcore.ui.R.color.sport_text),muted=c.getColor(fr.sportcore.ui.R.color.sport_muted),accent=c.getColor(fr.sportcore.ui.R.color.sport_accent);
  canvas.drawColor(bg);p.setColor(c.getColor(fr.sportcore.ui.R.color.sport_header));canvas.drawRect(0,0,width,190,p);
  Bitmap logo=BitmapFactory.decodeResource(c.getResources(),R.drawable.club_logo);canvas.drawBitmap(logo,null,new Rect(68,44,168,144),p);logo.recycle();
  text(canvas,p,"DART CLUB",198,95,48,Color.WHITE,true,800);text(canvas,p,"By AJS Studio",200,140,29,c.getColor(fr.sportcore.ui.R.color.sport_hero_muted),false,800);
  text(canvas,p,c.getString(R.string.darts_share_match,mode),72,266,28,accent,true,936);
  String title=game.winner>=0?c.getString(R.string.darts_share_winner,names[game.winner]):game.playerCount()>1?c.getString(fr.dartsclub.app.R.string.darts_draw):c.getString(fr.dartsclub.app.R.string.darts_challenge_complete);
  text(canvas,p,title,72,350,52,ink,true,936);
  String metric=DartSession.isX01(game.mode)?DartsText.q(c,R.plurals.darts_first_legs,game.legsToWin):DartsText.q(c,R.plurals.darts_thrown,game.dartsThrown());
  text(canvas,p,metric,72,410,30,muted,false,936);
  p.setColor(c.getColor(fr.sportcore.ui.R.color.sport_card));canvas.drawRoundRect(52,462,1028,540+game.playerCount()*88,32,32,p);
  text(canvas,p,c.getString(fr.dartsclub.app.R.string.darts_share_title),84,514,24,muted,true,900);
  for(int i=0;i<game.playerCount();i++){
   int y=590+i*88;text(canvas,p,(i==game.winner?"★  ":"")+names[i],84,y,34,ink,i==game.winner,560);
   String value=ResultScreen.metric(c,game,i);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(30);float x=994-p.measureText(value);text(canvas,p,value,x,y,30,ink,true,340);
  }
  int y=625+game.playerCount()*88;
  if(DartSession.isX01(game.mode)){
   int player=game.winner>=0?game.winner:game.active,count=0;for(int i=0;i<game.dartsThrown();i++)if(game.eventPlayer(i)==player)count++;
   text(canvas,p,c.getString(R.string.darts_share_averages,String.format(fr.sportcore.ui.ClubLanguage.locale(c),"%.1f",count==0?0:game.validPoints(player)*3.0/count),game.bestCheckout(player)),72,y,29,muted,false,936);
  }
  text(canvas,p,c.getString(fr.dartsclub.app.R.string.darts_share_footer),72,height-72,28,muted,false,936);return image;
 }
 private static void text(Canvas c,Paint p,String text,float x,float y,int size,int color,boolean bold,int max){
  p.setColor(color);p.setTextSize(size);p.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
  android.text.TextPaint tp=new android.text.TextPaint(p);c.drawText(TextUtils.ellipsize(text,tp,max,TextUtils.TruncateAt.END).toString(),x,y,p);
 }
 static Intent intent(Activity c,DartSession game,String mode) throws IOException {return intent(c,game,game.names,mode);}
 static Intent intent(Activity c,DartSession game,String[] names,String mode) throws IOException {
  File dir=new File(c.getCacheDir(),"shared-results");if(!dir.isDirectory()&&!dir.mkdirs())throw new IOException("Dossier indisponible");
  // Each card has a unique URI, so sharing another result cannot overwrite an open one.
  File file=new File(dir,"dart-club-"+System.currentTimeMillis()+".png");Bitmap bitmap=card(c,game,names,mode);
  try(FileOutputStream out=new FileOutputStream(file)){if(!bitmap.compress(Bitmap.CompressFormat.PNG,100,out))throw new IOException("Image non enregistrée");}finally{bitmap.recycle();}
  Uri uri=FileProvider.getUriForFile(c,c.getPackageName()+".share",file);
  Intent send=new Intent(Intent.ACTION_SEND).setType("image/png").putExtra(Intent.EXTRA_STREAM,uri).putExtra(Intent.EXTRA_TEXT,c.getString(R.string.darts_share_message,mode)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
  send.setClipData(ClipData.newRawUri(c.getString(fr.dartsclub.app.R.string.darts_result_clip),uri));return send;
 }
 static void share(Activity c,DartSession game,String[] names,String mode){try{c.startActivity(Intent.createChooser(intent(c,game,names,mode),c.getString(fr.dartsclub.app.R.string.darts_share_result)));}catch(IOException|RuntimeException ex){Toast.makeText(c,c.getString(fr.dartsclub.app.R.string.darts_share_unavailable),Toast.LENGTH_LONG).show();}}
}
