package fr.dartsclub.app;
import android.app.*;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import fr.sportcore.navigation.SportCoreActivity;
import fr.sportcore.ui.*;
import fr.sportcore.ui.screens.ModesScreen;
import fr.sportcore.model.*;
import fr.sportdarts.DartsSpec;
import fr.sportdarts.engine.*;
import fr.sportcore.ads.AdMobController;
import fr.sportcore.ads.AdSettings;
import fr.dartsclub.app.views.DartboardView;
import java.util.*;
public final class MainActivity extends SportCoreActivity {
 private DartSession session;
 private String sessionId;
 private SessionDraft currentDraft;
 private ActiveDartsStore activeStore;
 private LocalDartsStats stats;
 private AdMobController ads;
 private LastSetupStore lastSetup;
 private Dialog profileEditor;
 private EditText profileName;
 private String editingProfileId;
 private String pendingBackup;
 private static final int EXPORT_BACKUP=6301,IMPORT_BACKUP=6302;
 @Override protected SportSpec defineSport(){return new LocalizedDartsSpec(this);}
 @Override protected void prepareBaseContext(android.content.Context base){new DartBackupManager(base).recover();}
 @Override protected int appTheme(boolean dark){return dark?R.style.Theme_DartsClub_Night:R.style.Theme_DartsClub;}
 @Override protected int appBrandDrawable(){return R.drawable.club_logo;}
 @Override public View featuredModeArt(){
  ImageView art=new ImageView(this);art.setImageResource(R.drawable.club_target_art);art.setScaleType(ImageView.ScaleType.FIT_CENTER);
  art.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);return art;
 }
 @Override public String featuredModeCaption(){return getString(fr.dartsclub.app.R.string.darts_feature_caption);}
 @Override protected void onSportReady(Bundle state){
  activeStore=new ActiveDartsStore(this);stats=new LocalDartsStats(this);lastSetup=new LastSetupStore(this);
  // Première publication Play sans publicité ni SDK publicitaire.
  ads=new AdMobController(this,AdSettings.disabled());
  try{
   ActiveDartsStore.Record saved=activeStore.load();
   if(saved!=null){session=saved.session;currentDraft=saved.draft;sessionId=saved.id;if(session.finished)recordFinished();}
  }catch(Exception ex){Toast.makeText(this,getString(fr.dartsclub.app.R.string.darts_unreadable_save),Toast.LENGTH_LONG).show();}
 }
 @Override public void onCreate(Bundle savedInstanceState){
  super.onCreate(savedInstanceState);
  if(ads!=null)ads.start();
  if(savedInstanceState!=null){if(savedInstanceState.getBoolean("darts.pending_backup",false))try(java.io.InputStream in=new java.io.FileInputStream(new java.io.File(getCacheDir(),"pending-backup.json"))){confirmRestore(DartBackupManager.read(in));}catch(Exception ignored){pendingBackup=null;}}
  if(savedInstanceState!=null&&savedInstanceState.getBoolean("darts.profile_editor_open",false)){
   String id=savedInstanceState.getString("darts.editing_profile_id","");Profile editing=null;
   for(Profile p:profiles().all())if(p.id.equals(id))editing=p;
   if(id.isEmpty()||editing!=null){
    editProfile(editing);profileName.setText(savedInstanceState.getString("darts.profile_name",""));profileName.setSelection(profileName.length());
   }
  }
 }
 @Override protected void onSaveInstanceState(Bundle state){
  if(profileEditor!=null&&profileEditor.isShowing()&&profileName!=null){
   state.putBoolean("darts.profile_editor_open",true);state.putString("darts.editing_profile_id",editingProfileId);state.putString("darts.profile_name",profileName.getText().toString());
  }
  if(pendingBackup!=null)state.putBoolean("darts.pending_backup",true);
  super.onSaveInstanceState(state);
 }
 @Override protected View createPersistentFooter(){return ads==null?null:ads.createFooter();}
 @Override protected void renderAdditionalSettings(LinearLayout box){
  LinearLayout backup=SportUI.card(this);backup.addView(SportUI.sectionTitle(this,getString(fr.dartsclub.app.R.string.darts_keep_club)));
  SportUI.below(backup,SportUI.text(this,getString(fr.dartsclub.app.R.string.darts_backup_intro),14,getColor(fr.sportcore.ui.R.color.sport_muted),false),8);
  TextView export=SportUI.button(this,getString(fr.dartsclub.app.R.string.darts_export_backup),false,largeControls());export.setOnClickListener(v->openBackupDocument(true));SportUI.below(backup,export,12);
  TextView restore=SportUI.button(this,getString(fr.dartsclub.app.R.string.darts_import_backup),false,largeControls());restore.setOnClickListener(v->openBackupDocument(false));SportUI.below(backup,restore,8);SportUI.below(box,backup,16);
  LinearLayout privacyCard=SportUI.card(this);privacyCard.addView(SportUI.sectionTitle(this,getString(R.string.darts_privacy_policy)));
  TextView policy=SportUI.button(this,getString(R.string.darts_privacy_policy),false,largeControls());policy.setOnClickListener(v->openExternal("https://thomassauve2935-maker.github.io/blackball-confidentialite/dart-club/privacy-fr.html"));SportUI.below(privacyCard,policy,12);
  TextView support=SportUI.button(this,getString(R.string.darts_contact_support),false,largeControls());support.setOnClickListener(v->openExternal("mailto:contact@ajsstudio.fr"));SportUI.below(privacyCard,support,8);
  if(ads!=null&&ads.enabled())SportUI.below(privacyCard,SportUI.text(this,getString(R.string.darts_family_ads_note),13,getColor(fr.sportcore.ui.R.color.sport_muted),false),10);
  SportUI.below(box,privacyCard,16);
  LinearLayout about=SportUI.card(this);about.addView(SportUI.eyebrow(this,"DART CLUB"));
  SportUI.below(about,SportUI.scoreText(this,"By AJS Studio",24),10);
  String version="0.15.0";
  try{version=getPackageManager().getPackageInfo(getPackageName(),0).versionName;}catch(android.content.pm.PackageManager.NameNotFoundException ignored){}
  if(version!=null)version=version.split("-",2)[0];
  SportUI.below(about,SportUI.text(this,getString(R.string.darts_version,version),13,getColor(fr.sportcore.ui.R.color.sport_muted),false),10);
  SportUI.below(box,about,16);
  if(ads!=null&&ads.enabled()){
   TextView privacy=SportUI.button(this,getString(fr.dartsclub.app.R.string.darts_ad_privacy),false,largeControls());
   privacy.setOnClickListener(v->ads.showPrivacyOptions());
   Runnable updatePrivacy=()->privacy.setVisibility(ads.privacyOptionsRequired()?View.VISIBLE:View.GONE);
   ads.setPrivacyOptionsListener(updatePrivacy);updatePrivacy.run();SportUI.below(box,privacy,16);
  }
 }
 @Override protected void onResume(){super.onResume();if(ads!=null)ads.resume();}
 @Override protected void onPause(){if(ads!=null)ads.pause();super.onPause();}
 @Override protected void onDestroy(){if(profileEditor!=null)profileEditor.dismiss();if(ads!=null)ads.destroy();super.onDestroy();}
 @Override public void openMode(String id){
  if(session!=null&&!session.finished){
   new AlertDialog.Builder(this).setTitle(getString(fr.dartsclub.app.R.string.darts_ongoing_title))
    .setMessage(getString(fr.dartsclub.app.R.string.darts_ongoing_message))
    .setNegativeButton(getString(fr.dartsclub.app.R.string.darts_resume),(dialog,which)->navigate(ScreenRoutes.MATCH))
    .setPositiveButton(getString(fr.dartsclub.app.R.string.darts_new_match),(dialog,which)->super.openMode(id)).show();
  } else {
   if(session!=null&&session.finished){if(!recordFinished())return;activeStore.clear();session=null;currentDraft=null;}
   super.openMode(id);
  }
 }
 @Override protected void onStartSportMatch(SessionDraft d){
  currentDraft=d;sessionId=UUID.randomUUID().toString();session=new DartSession(d.modeId,d.names(),d.legsToWin);
  persist();lastSetup.save(d);navigate(ScreenRoutes.MATCH);
 }
 private void persist(){if(session!=null&&currentDraft!=null)activeStore.save(sessionId,currentDraft,session);}
 @Override protected boolean renderSportPage(String page,LinearLayout box){
  if(page.equals(ScreenRoutes.PLAY)){
   if(session!=null&&session.finished){
    TextView result=SportUI.withIcon(this,SportUI.button(this,getString(fr.dartsclub.app.R.string.darts_previous_result),true,largeControls()),fr.sportcore.ui.R.drawable.ic_club_arrow);
    result.setOnClickListener(v->navigate(ScreenRoutes.RESULT));SportUI.below(box,result,4);
   }
   if(session!=null&&!session.finished){
    LinearLayout resumeCard=SportUI.card(this);resumeCard.addView(SportUI.eyebrow(this,getString(R.string.darts_paused_eyebrow,modeName(session.mode))));
    StringBuilder scores=new StringBuilder();for(int p=0;p<session.playerCount();p++){if(p>0)scores.append("   ·   ");scores.append(playerNames()[p]).append("  ").append(MatchScreen.displayScore(session,p));}
    TextView summary=SportUI.text(this,scores.toString(),16,getColor(fr.sportcore.ui.R.color.sport_text),true);summary.setMaxLines(2);summary.setEllipsize(android.text.TextUtils.TruncateAt.END);SportUI.below(resumeCard,summary,10);
    SportUI.below(resumeCard,SportUI.text(this,getString(R.string.darts_resume_detail,playerNames()[session.active],DartsText.q(this,R.plurals.darts_thrown,session.dartsThrown())),12,getColor(fr.sportcore.ui.R.color.sport_muted),false),6);
    TextView resume=SportUI.withIcon(this,SportUI.button(this,getString(fr.dartsclub.app.R.string.darts_resume_match),true,largeControls()),fr.sportcore.ui.R.drawable.ic_club_play);
    resume.setOnClickListener(v->navigate(ScreenRoutes.MATCH));SportUI.below(resumeCard,resume,14);SportUI.below(box,resumeCard,4);
   }
   if(session==null||session.finished){
    SessionDraft recent=lastSetup.load(profiles());if(recent!=null){
     LinearLayout quick=SportUI.card(this);quick.addView(SportUI.eyebrow(this,getString(fr.dartsclub.app.R.string.darts_last_settings)));
     SportUI.below(quick,SportUI.text(this,summary(recent),14,getColor(fr.sportcore.ui.R.color.sport_text),true),8);
     TextView names=SportUI.text(this,String.join(" · ",ClubLanguage.names(this,recent)),12,getColor(fr.sportcore.ui.R.color.sport_muted),false);names.setMaxLines(1);names.setEllipsize(android.text.TextUtils.TruncateAt.END);SportUI.below(quick,names,4);
     TextView play=SportUI.withIcon(this,SportUI.button(this,getString(fr.dartsclub.app.R.string.darts_quick_launch),false,largeControls()),fr.sportcore.ui.R.drawable.ic_club_play);
     play.setOnClickListener(v->{if(session!=null&&session.finished&&!recordFinished())return;useDraft(recent);startMatch();});SportUI.below(quick,play,12);SportUI.below(box,quick,12);
    }
   }
   new ModesScreen(true).render(box,this);return true;
  }
  if(page.equals(ScreenRoutes.PROFILES)){renderProfiles(box);return true;}
  if(page.equals(ScreenRoutes.MATCH)){
   if(session==null){navigate(ScreenRoutes.PLAY);return true;}
   if(session.finished){navigate(ScreenRoutes.RESULT);return true;}
   new MatchScreen().render(box,this,session,playerNames(),modeName(session.mode),largeControls(),new MatchScreen.Listener(){
    @Override public void hit(DartThrow hit){
     int player=session.active,turnDarts=session.turnDarts;
     if(!session.throwDart(hit))return;
     persist();SportFeedback.Signal signal=MatchFeedback.signal(session,player,turnDarts);
     navigate(session.finished?ScreenRoutes.RESULT:ScreenRoutes.MATCH);
     if(session.finished){
      if(recordFinished()){
       if(MatchFeedback.claimCelebration(MainActivity.this,sessionId)){feedback(signal);SportMotion.pulse(getWindow().getDecorView().findViewWithTag("result-hero"),true);}
       // Une seule occasion après le résultat final sauvegardé, jamais entre les legs.
       if(ads!=null)ads.onMatchCompleted(sessionId);
      }
     }else{
      feedback(signal);View status=getWindow().getDecorView().findViewWithTag("match-status");
      if(status instanceof TextView)((TextView)status).setText(MatchFeedback.message(MainActivity.this,session,playerNames(),signal));
      SportMotion.pulse(getWindow().getDecorView().findViewWithTag("score-"+player),signal==SportFeedback.Signal.MAXIMUM);
      if(session.active!=player)SportMotion.pulse(getWindow().getDecorView().findViewWithTag("active-player"),false);
     }
    }
    @Override public void undo(){MainActivity.this.undo();}
    @Override public void leave(){confirmLeave();}
   });return true;
  }
  if(page.equals(ScreenRoutes.RESULT)){renderResult(box);return true;}
  return false;
 }
 @Override protected String setupSummary(){return draft()==null?"":summary(draft());}
 private String[] playerNames(){return currentDraft==null?session.names:ClubLanguage.names(this,currentDraft);}
 private String summary(SessionDraft d){String players=ClubLanguage.quantity(this,fr.sportcore.ui.R.plurals.club_players,d.playerCount());
  return DartSession.isX01(d.modeId)?getString(R.string.darts_summary_legs,modeName(d.modeId),players,DartsText.q(this,R.plurals.darts_first_legs,d.legsToWin)):getString(R.string.darts_summary,modeName(d.modeId),players);
 }
 private String modeName(String id){
  for(ModeSpec mode:sport().games())if(mode.id.equals(id))return mode.name;
  return id;
 }
 private void undo(){
  if(session!=null&&session.finished){
   try{stats.removeResult(sessionId);}catch(IllegalStateException ex){Toast.makeText(this,getString(fr.dartsclub.app.R.string.darts_result_update_failed),Toast.LENGTH_LONG).show();return;}
  }
  if(session!=null&&session.undo()){persist();navigate(ScreenRoutes.MATCH);}
  else Toast.makeText(this,getString(fr.dartsclub.app.R.string.darts_nothing_to_undo),Toast.LENGTH_SHORT).show();
 }
 private void confirmLeave(){
  new AlertDialog.Builder(this).setTitle(getString(fr.dartsclub.app.R.string.darts_pause_title))
   .setMessage(getString(fr.dartsclub.app.R.string.darts_pause_message))
   .setNegativeButton(getString(fr.dartsclub.app.R.string.darts_stay),null).setPositiveButton(getString(fr.dartsclub.app.R.string.darts_pause),(dlg,which)->navigate(ScreenRoutes.PLAY)).show();
 }
 @Override protected boolean handleSportBack(String page){
  if(page.equals(ScreenRoutes.MATCH)){confirmLeave();return true;}
  if(page.equals(ScreenRoutes.RESULT)){if(!recordFinished())return true;activeStore.clear();session=null;currentDraft=null;navigate(ScreenRoutes.PLAY);return true;}
  return false;
 }
 private boolean hasLinkedProfiles(){
  if(currentDraft==null)return false;
  for(String id:currentDraft.profileIds())if(!id.isEmpty())return true;
  return false;
 }
 private boolean recordFinished(){
  if(session==null||!session.finished||currentDraft==null)return true;
  try{if(hasLinkedProfiles())stats.save(sessionId,session,currentDraft.profileIds());return true;}
  catch(IllegalStateException ex){Toast.makeText(this,getString(fr.dartsclub.app.R.string.darts_result_save_failed),Toast.LENGTH_LONG).show();return false;}
 }
 private void renderResult(LinearLayout box){
  if(session==null){navigate(ScreenRoutes.PLAY);return;}
  if(!session.finished){navigate(ScreenRoutes.MATCH);return;}
  boolean recorded=recordFinished();
  new ResultScreen().render(box,this,session,playerNames(),modeName(session.mode),hasLinkedProfiles(),recorded,new ResultScreen.Listener(){
   @Override public void again(){SessionDraft old=currentDraft;if(old!=null&&recordFinished())onStartSportMatch(old);}
   @Override public void games(){if(!recordFinished())return;activeStore.clear();session=null;currentDraft=null;navigate(ScreenRoutes.PLAY);}
   @Override public void undo(){MainActivity.this.undo();}
   @Override public void retry(){navigate(ScreenRoutes.RESULT);}
   @Override public void share(){ResultShare.share(MainActivity.this,session,playerNames(),modeName(session.mode));}
  });
 }
 private void openExternal(String url){
  try{android.content.Intent intent=new android.content.Intent(url.startsWith("mailto:")?android.content.Intent.ACTION_SENDTO:android.content.Intent.ACTION_VIEW,android.net.Uri.parse(url));startActivity(intent);}
  catch(android.content.ActivityNotFoundException ex){Toast.makeText(this,R.string.darts_external_link_failed,Toast.LENGTH_LONG).show();}
 }
 private void openBackupDocument(boolean export){
  try{
   if(export){new DartBackupManager(this).exportJson();startActivityForResult(new android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT).addCategory(android.content.Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(android.content.Intent.EXTRA_TITLE,getString(fr.dartsclub.app.R.string.darts_backup_filename)),EXPORT_BACKUP);}
   else startActivityForResult(new android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).addCategory(android.content.Intent.CATEGORY_OPENABLE).setType("*/*").putExtra(android.content.Intent.EXTRA_MIME_TYPES,new String[]{"application/json","text/plain","application/octet-stream"}),IMPORT_BACKUP);
  }catch(Exception ex){Toast.makeText(this,getString(fr.dartsclub.app.R.string.darts_file_picker_failed),Toast.LENGTH_LONG).show();}
 }
 @Override protected void onActivityResult(int request,int result,android.content.Intent data){
  super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;
  try{
   if(request==EXPORT_BACKUP){String raw=new DartBackupManager(this).exportJson();try(java.io.OutputStream out=getContentResolver().openOutputStream(data.getData(),"wt")){if(out==null)throw new java.io.IOException();out.write(raw.getBytes(java.nio.charset.StandardCharsets.UTF_8));}Toast.makeText(this,getString(fr.dartsclub.app.R.string.darts_backup_exported),Toast.LENGTH_LONG).show();}
   else if(request==IMPORT_BACKUP){String raw;try(java.io.InputStream in=getContentResolver().openInputStream(data.getData())){raw=DartBackupManager.read(in);}DartBackupManager.validate(raw);confirmRestore(raw);}
  }catch(Exception ex){Toast.makeText(this,request==IMPORT_BACKUP?getString(fr.dartsclub.app.R.string.darts_backup_invalid):getString(fr.dartsclub.app.R.string.darts_export_failed),Toast.LENGTH_LONG).show();}
 }
 private void confirmRestore(String raw){
  try(java.io.OutputStream out=new java.io.FileOutputStream(new java.io.File(getCacheDir(),"pending-backup.json"))){out.write(raw.getBytes(java.nio.charset.StandardCharsets.UTF_8));}
  catch(java.io.IOException ex){Toast.makeText(this,getString(fr.dartsclub.app.R.string.darts_file_prepare_failed),Toast.LENGTH_LONG).show();return;}
  pendingBackup=raw;
  new AlertDialog.Builder(this).setTitle(getString(fr.dartsclub.app.R.string.darts_restore_title)).setMessage(getString(fr.dartsclub.app.R.string.darts_restore_message))
   .setNegativeButton(getString(fr.sportcore.ui.R.string.club_cancel),(d,w)->pendingBackup=null).setOnCancelListener(d->pendingBackup=null)
   .setPositiveButton(getString(fr.dartsclub.app.R.string.darts_restore),(d,w)->{
    try{new DartBackupManager(this).restore(raw);pendingBackup=null;ActiveDartsStore.Record saved=activeStore.load();session=saved==null?null:saved.session;currentDraft=saved==null?null:saved.draft;sessionId=saved==null?null:saved.id;
     useDraft(currentDraft);reloadPresentation();Toast.makeText(this,getString(fr.dartsclub.app.R.string.darts_backup_restored),Toast.LENGTH_LONG).show();}
    catch(Exception ex){pendingBackup=null;Toast.makeText(this,getString(fr.dartsclub.app.R.string.darts_restore_failed),Toast.LENGTH_LONG).show();}
   }).show();
 }
 private void renderProfiles(LinearLayout box){
  List<Profile> list=profiles().all();
  TextView create=SportUI.button(this,getString(fr.dartsclub.app.R.string.darts_add),false,largeControls());create.setContentDescription(getString(fr.dartsclub.app.R.string.darts_add_profile));
  create.setOnClickListener(v->promptProfile());
  if(list.isEmpty())ScreenElements.heading(box,this,getString(fr.dartsclub.app.R.string.darts_profiles_eyebrow),getString(fr.dartsclub.app.R.string.darts_your_players),"");
  else {
   box.addView(SportUI.eyebrow(this,getString(fr.dartsclub.app.R.string.darts_profiles_eyebrow)));LinearLayout heading=SportUI.horizontal(this);
   heading.addView(SportUI.scoreText(this,getString(fr.dartsclub.app.R.string.darts_your_players),32),new LinearLayout.LayoutParams(0,-2,1));
   LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(SportUI.dp(this,108),-2);cp.leftMargin=SportUI.dp(this,8);heading.addView(create,cp);SportUI.below(box,heading,6);
  }
  if(list.isEmpty()){
   LinearLayout welcome=SportUI.card(this);ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.club_logo);logo.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
   logo.setBackground(SportUI.flatChip(this,getColor(fr.sportcore.ui.R.color.sport_header),20));logo.setPadding(SportUI.dp(this,12),SportUI.dp(this,12),SportUI.dp(this,12),SportUI.dp(this,12));
   welcome.addView(logo,new LinearLayout.LayoutParams(SportUI.dp(this,96),SportUI.dp(this,96)));
   SportUI.below(welcome,SportUI.scoreText(this,getString(fr.dartsclub.app.R.string.darts_welcome_profile),27),16);
   SportUI.below(welcome,SportUI.text(this,getString(fr.dartsclub.app.R.string.darts_first_profile_intro),14,getColor(fr.sportcore.ui.R.color.sport_muted),false),12);
   TextView first=SportUI.button(this,getString(fr.dartsclub.app.R.string.darts_first_profile),true,largeControls());first.setOnClickListener(v->promptProfile());SportUI.below(welcome,first,24);
   TextView guests=SportUI.button(this,getString(fr.dartsclub.app.R.string.darts_play_guests),false,largeControls());guests.setOnClickListener(v->navigate(ScreenRoutes.PLAY));SportUI.below(welcome,guests,12);
   SportUI.below(welcome,SportUI.text(this,getString(fr.dartsclub.app.R.string.darts_no_account),12,getColor(fr.sportcore.ui.R.color.sport_muted),false),12);
   SportUI.below(box,welcome,24);return;
  }
  for(Profile profile:list){
   LocalDartsStats.Summary values=stats.forProfile(profile.id);
   LinearLayout card=SportUI.card(this);
   LinearLayout identity=SportUI.horizontal(this);
   card.setPadding(SportUI.dp(this,20),SportUI.dp(this,20),SportUI.dp(this,20),SportUI.dp(this,20));
   TextView avatar=SportUI.scoreText(this,profile.name.substring(0,profile.name.offsetByCodePoints(0,1)).toUpperCase(ClubLanguage.locale(this)),23);
   avatar.setGravity(Gravity.CENTER);avatar.setTextColor(getColor(fr.sportcore.ui.R.color.sport_accent));
   avatar.setBackground(SportUI.flatChip(this,getColor(fr.sportcore.ui.R.color.sport_selected),22));
   avatar.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
   LinearLayout.LayoutParams avatarSize=new LinearLayout.LayoutParams(SportUI.dp(this,44),SportUI.dp(this,44));avatarSize.rightMargin=SportUI.dp(this,12);identity.addView(avatar,avatarSize);
   LinearLayout name=SportUI.vertical(this,0);name.addView(SportUI.scoreText(this,profile.name,24));
   SportUI.below(name,SportUI.text(this,getString(fr.dartsclub.app.R.string.darts_club_player),11,getColor(fr.sportcore.ui.R.color.sport_muted),false),3);
   identity.addView(name,new LinearLayout.LayoutParams(0,-2,1));
   TextView options=SportUI.button(this,"•••",false,false);options.setTextColor(getColor(fr.sportcore.ui.R.color.sport_muted));
   options.setBackground(SportUI.flatChip(this,getColor(fr.sportcore.ui.R.color.sport_card),24));
   options.setPadding(0,0,0,0);options.setContentDescription(getString(R.string.darts_profile_options,profile.name));
   options.setOnClickListener(v->showProfileOptions(profile,options));
   identity.addView(options,new LinearLayout.LayoutParams(SportUI.dp(this,48),SportUI.dp(this,48)));card.addView(identity);
   LinearLayout grid=SportUI.horizontal(this);
   addStat(grid,getString(fr.dartsclub.app.R.string.darts_wins),""+values.wins,fr.sportcore.ui.R.color.sport_blue);
   addStat(grid,getString(fr.dartsclub.app.R.string.darts_matches),""+values.matches,fr.sportcore.ui.R.color.sport_teal);
   SportUI.below(card,grid,16);
   LinearLayout grid2=SportUI.horizontal(this);
   addStat(grid2,getString(fr.dartsclub.app.R.string.darts_average_stat),String.format(ClubLanguage.locale(this),"%.1f",values.average()),fr.sportcore.ui.R.color.sport_purple);
   addStat(grid2,getString(fr.dartsclub.app.R.string.darts_best_checkout),""+values.checkout,fr.sportcore.ui.R.color.sport_amber);
   SportUI.below(card,grid2,14);
   SportUI.divider(card);
   TextView caption=SportUI.sectionTitle(this,getString(fr.dartsclub.app.R.string.darts_precision));
   SportUI.below(card,caption,12);
   DartboardView target=new DartboardView(this);target.setHeat(values.zones);
   LinearLayout center=SportUI.horizontal(this);center.setGravity(Gravity.CENTER);
   int size=Math.min(getResources().getDisplayMetrics().widthPixels-SportUI.dp(this,100),SportUI.dp(this,largeControls()?260:220));
   center.addView(target,new LinearLayout.LayoutParams(size,size));SportUI.below(card,center,10);
   addHeatLegend(card);
   if(values.hitTotal==0){
    TextView empty=SportUI.text(this,getString(fr.dartsclub.app.R.string.darts_empty_hits),
        14,getColor(fr.sportcore.ui.R.color.sport_muted),false);
    empty.setGravity(Gravity.CENTER);SportUI.below(card,empty,8);
   }
   SportUI.below(box,card,14);
  }
 }
 private void showProfileOptions(Profile profile,View anchor){
  PopupMenu menu=new PopupMenu(this,anchor);
  menu.getMenu().add(0,1,0,getString(fr.dartsclub.app.R.string.darts_rename));menu.getMenu().add(0,2,1,getString(fr.sportcore.ui.R.string.club_delete));
  menu.setOnMenuItemClickListener(item->{
   if(item.getItemId()==1)editProfile(profile);
   else if(item.getItemId()==2)new AlertDialog.Builder(this).setTitle(getString(R.string.darts_delete_named,profile.name))
    .setMessage(getString(fr.dartsclub.app.R.string.darts_delete_profile_message)).setNegativeButton(getString(fr.sportcore.ui.R.string.club_cancel),null)
    .setPositiveButton(getString(fr.sportcore.ui.R.string.club_delete),(dialog,which)->{profiles().remove(profile.id);navigate(ScreenRoutes.PROFILES);}).show();
   else return false;
   return true;
  });menu.show();
 }
 /** Échelle discrète identique aux classes de couleur de DartboardView. */
 private void addHeatLegend(LinearLayout parent){
  int[] colors={DartboardView.HEAT_NONE,DartboardView.HEAT_RARE,
   DartboardView.HEAT_MIDDLE,DartboardView.HEAT_FREQUENT,DartboardView.HEAT_MAX};
  LinearLayout bar=SportUI.horizontal(this);
  for(int i=0;i<colors.length;i++){
   TextView stripe=SportUI.text(this,"",12,colors[i],false);
   stripe.setBackground(SportUI.flatChip(this,colors[i],4));
   LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,SportUI.dp(this,8),1);
   if(i>0)cp.leftMargin=SportUI.dp(this,4);
   bar.addView(stripe,cp);
  }
  SportUI.below(parent,bar,4);
  TextView labels=SportUI.text(this,getString(fr.dartsclub.app.R.string.darts_heat_legend),12,
     getColor(fr.sportcore.ui.R.color.sport_muted),false);
  labels.setGravity(Gravity.CENTER);
  SportUI.below(parent,labels,7);
  TextView guide=SportUI.text(this,getString(fr.dartsclub.app.R.string.darts_heat_guide),12,
      getColor(fr.sportcore.ui.R.color.sport_muted),false);
  guide.setGravity(Gravity.CENTER);SportUI.below(parent,guide,4);
 }
 private void addStat(LinearLayout parent,String title,String value,int ink){
  LinearLayout card=SportUI.vertical(this,0);card.setPadding(0,SportUI.dp(this,4),0,SportUI.dp(this,4));
  TextView number=SportUI.scoreText(this,value,32);number.setTextColor(getColor(ink));card.addView(number);
  SportUI.below(card,SportUI.text(this,title,11,getColor(fr.sportcore.ui.R.color.sport_muted),false),4);
  LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);
  if(parent.getChildCount()>0)p.leftMargin=SportUI.dp(this,20);parent.addView(card,p);
 }
 private void promptProfile(){
  editProfile(null);
 }
 private void editProfile(Profile profile){
  if(profileEditor!=null)profileEditor.dismiss();
  Dialog dialog=new Dialog(this);dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
  LinearLayout card=SportUI.card(this);card.addView(SportUI.eyebrow(this,getString(fr.dartsclub.app.R.string.darts_player_profile)));
  SportUI.below(card,SportUI.scoreText(this,profile==null?getString(fr.sportcore.ui.R.string.club_new_player):getString(fr.dartsclub.app.R.string.darts_rename_player),26),10);
  SportUI.below(card,SportUI.text(this,profile==null?getString(fr.dartsclub.app.R.string.darts_profile_followup):getString(fr.dartsclub.app.R.string.darts_profile_identity_note),13,getColor(fr.sportcore.ui.R.color.sport_muted),false),10);
  SportUI.below(card,SportUI.text(this,getString(fr.sportcore.ui.R.string.club_player_name),12,getColor(fr.sportcore.ui.R.color.sport_muted),false),20);
  EditText input=new EditText(this);input.setSingleLine(true);input.setHint(getString(fr.dartsclub.app.R.string.darts_name_hint));input.setTextColor(getColor(fr.sportcore.ui.R.color.sport_text));
  profileEditor=dialog;profileName=input;editingProfileId=profile==null?"":profile.id;
  dialog.setOnDismissListener(d->{if(profileEditor==dialog){profileEditor=null;profileName=null;editingProfileId=null;}});
  input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS);
  input.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(50)});
  input.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_DONE);
  input.setPadding(SportUI.dp(this,12),SportUI.dp(this,12),SportUI.dp(this,12),SportUI.dp(this,12));
  input.setMinHeight(SportUI.dp(this,52));input.setBackground(SportUI.background(getColor(fr.sportcore.ui.R.color.sport_button_bottom),getColor(fr.sportcore.ui.R.color.sport_stroke),12,this));
  input.setContentDescription(getString(fr.sportcore.ui.R.string.club_player_name));if(profile!=null){input.setText(profile.name);input.setSelection(input.length());}
  SportUI.below(card,input,8);
  TextView error=SportUI.text(this,"",12,getColor(fr.sportcore.ui.R.color.sport_accent),false);error.setVisibility(View.GONE);
  error.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);SportUI.below(card,error,8);
  LinearLayout actions=SportUI.horizontal(this);TextView cancel=SportUI.button(this,getString(fr.sportcore.ui.R.string.club_cancel),false,largeControls()),save=SportUI.button(this,profile==null?getString(fr.sportcore.ui.R.string.club_create):getString(fr.sportcore.ui.R.string.club_save),true,largeControls());
  cancel.setOnClickListener(v->dialog.dismiss());
  save.setOnClickListener(v->{
   try{if(profile==null)profiles().add(input.getText().toString());else profiles().rename(profile.id,input.getText().toString());dialog.dismiss();navigate(ScreenRoutes.PROFILES);}
   catch(IllegalArgumentException ex){error.setText(ClubLanguage.profileError(this,ex));error.setVisibility(View.VISIBLE);input.requestFocus();}
   catch(IllegalStateException ex){error.setText(R.string.darts_profile_save_error);error.setVisibility(View.VISIBLE);}
  });
  actions.addView(cancel,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,-2,1);sp.leftMargin=SportUI.dp(this,12);actions.addView(save,sp);SportUI.below(card,actions,16);
  input.setOnEditorActionListener((v,action,event)->{if(action==android.view.inputmethod.EditorInfo.IME_ACTION_DONE){save.performClick();return true;}return false;});
  dialog.setContentView(card);dialog.show();
  dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
  dialog.getWindow().setLayout(Math.min(getResources().getDisplayMetrics().widthPixels-SportUI.dp(this,48),SportUI.dp(this,420)),-2);
  dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE|WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);input.requestFocus();
 }
}
