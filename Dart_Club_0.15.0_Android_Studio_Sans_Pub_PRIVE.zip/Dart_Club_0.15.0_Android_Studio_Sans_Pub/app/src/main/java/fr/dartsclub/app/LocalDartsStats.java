package fr.dartsclub.app;
import android.content.*;
import org.json.*;
import fr.sportdarts.engine.*;
import java.util.*;
/** Statistiques locales liées à l'identifiant du profil, pas au nom affiché. */
public final class LocalDartsStats {
 private final SharedPreferences prefs;
 public LocalDartsStats(Context c){this(c.getSharedPreferences("darts_stats_1",Context.MODE_PRIVATE));}
 LocalDartsStats(SharedPreferences prefs){this.prefs=prefs;}
 public static final class Summary {
  public int matches,wins,darts,points,checkout,hitTotal;
  /** Nombre d'impacts par numéro puis multiplicateur (1=simple, 2=double, 3=triple). */
  public final int[][] zones=new int[26][4];
  public double average(){return darts==0?0:(points*3.0/darts);}
 }
 public Summary forProfile(String id){
  Summary s=new Summary();if(id==null||id.isEmpty())return s;
  try{
   JSONArray all=new JSONArray(prefs.getString("matches","[]"));
   for(int i=0;i<all.length();i++){
    JSONObject m=all.getJSONObject(i);
    JSONArray ids=m.optJSONArray("ids");int index=-1;
    if(ids!=null){for(int p=0;p<ids.length();p++)if(id.equals(ids.optString(p)))index=p;}
    else index=id.equals(m.optString("id0"))?0:id.equals(m.optString("id1"))?1:-1;
    if(index<0)continue;
    int participants=ids==null?(m.optBoolean("solo")?1:2):ids.length();
    if(participants>=2){s.matches++;if(index==m.optInt("winner",-1))s.wins++;}
    boolean x01=m.optBoolean("x01");
    JSONArray actions=m.optJSONArray("events");if(actions==null)continue;
    if(x01){
     JSONArray points=m.optJSONArray("points"),darts=m.optJSONArray("darts");
     s.points+=points==null?m.optInt("points"+index):points.optInt(index);
     s.darts+=darts==null?m.optInt("darts"+index):darts.optInt(index);
    }
    JSONArray checkouts=m.optJSONArray("checkouts");
    s.checkout=Math.max(s.checkout,checkouts==null?m.optInt("checkout"+index):checkouts.optInt(index));
    for(int j=0;j<actions.length();j++){
     JSONObject a=actions.getJSONObject(j);if(a.optInt("player")!=index)continue;
     int seg=a.optInt("segment"),multiplier=a.optInt("multiplier",1);
     // Le journal existant conserve déjà le multiplicateur : aucune migration destructive.
     if(((seg>=1&&seg<=20)||seg==25)&&multiplier>=1&&multiplier<=(seg==25?2:3)){
      s.zones[seg][multiplier]++;s.hitTotal++;
     }
    }
   }
  }catch(JSONException ex){throw new IllegalStateException("Statistiques illisibles",ex);}
  return s;
 }
 public void save(String matchId,DartSession session,String[] profileIds){
  if(profileIds.length!=session.playerCount())throw new IllegalArgumentException("Nombre de profils incorrect");
  try{
   JSONArray arr=new JSONArray(prefs.getString("matches","[]"));
   for(int i=0;i<arr.length();i++)if(matchId.equals(arr.getJSONObject(i).optString("matchId")))return;
   JSONObject m=new JSONObject();m.put("matchId",matchId);m.put("winner",session.winner);
   m.put("mode",session.mode);m.put("x01",DartSession.isX01(session.mode));
   JSONArray ids=new JSONArray(),points=new JSONArray(),darts=new JSONArray(),checkouts=new JSONArray(),actions=new JSONArray();
   int[] count=new int[session.playerCount()];
   for(int p=0;p<session.playerCount();p++){
    ids.put(profileIds[p]);points.put(session.validPoints(p));checkouts.put(session.bestCheckout(p));
   }
   for(int i=0;i<session.history().size();i++){
    DartThrow d=session.history().get(i);int p=session.eventPlayer(i);count[p]++;
    JSONObject a=new JSONObject();a.put("player",p);a.put("segment",d.segment);a.put("multiplier",d.multiplier);actions.put(a);
   }
   for(int value:count)darts.put(value);
   m.put("ids",ids);m.put("points",points);m.put("darts",darts);m.put("checkouts",checkouts);m.put("events",actions);
   arr.put(m);
   if(!prefs.edit().putString("matches",arr.toString()).commit())throw new IllegalStateException("Échec enregistrement");
  }catch(JSONException ex){throw new IllegalStateException("Échec sérialisation",ex);}
 }
 /** Retire uniquement le résultat de la partie rouverte par Annuler. */
 public void removeResult(String matchId){
  if(matchId==null||matchId.isEmpty())return;
  try{
   JSONArray all=new JSONArray(prefs.getString("matches","[]")),kept=new JSONArray();
   boolean removed=false;
   for(int i=0;i<all.length();i++){
    JSONObject match=all.getJSONObject(i);
    if(matchId.equals(match.optString("matchId")))removed=true;else kept.put(match);
   }
   if(removed&&!prefs.edit().putString("matches",kept.toString()).commit())
    throw new IllegalStateException("Impossible de mettre à jour le résultat");
  }catch(JSONException ex){throw new IllegalStateException("Statistiques illisibles",ex);}
 }
}
