package fr.dartsclub.app;
import android.content.Context;
import fr.sportcore.model.*;
import fr.sportdarts.DartsSpec;
import java.util.*;
/** Only presentation is localised; sport IDs and rule execution come from DartsSpec. */
final class LocalizedDartsSpec implements SportSpec {
 private final Context context;private final DartsSpec source=new DartsSpec();
 LocalizedDartsSpec(Context c){context=c;}
 public String appName(){return source.appName();}public String appSignature(){return source.appSignature();}
 public String headline(){return context.getString(fr.sportcore.ui.R.string.club_choose_game);}
 public String welcomeText(){return context.getString(fr.sportcore.ui.R.string.club_catalogue_count,15);}
 public boolean solo(String id){return source.solo(id);}
 public List<ModeSpec> games(){
  List<ModeSpec> out=new ArrayList<>();for(ModeSpec mode:source.games()){
   int name,description,rules;switch(mode.id){
   case "x01_501":name=R.string.darts_mode_x01_501_name;description=R.string.darts_mode_x01_501_description;rules=R.string.darts_mode_x01_501_rules;break;
   case "x01_301":name=R.string.darts_mode_x01_301_name;description=R.string.darts_mode_x01_301_description;rules=R.string.darts_mode_x01_301_rules;break;
   case "x01_701":name=R.string.darts_mode_x01_701_name;description=R.string.darts_mode_x01_701_description;rules=R.string.darts_mode_x01_701_rules;break;
   case "cricket":name=R.string.darts_mode_cricket_name;description=R.string.darts_mode_cricket_description;rules=R.string.darts_mode_cricket_rules;break;
   case "around":name=R.string.darts_mode_around_name;description=R.string.darts_mode_around_description;rules=R.string.darts_mode_around_rules;break;
   case "shanghai":name=R.string.darts_mode_shanghai_name;description=R.string.darts_mode_shanghai_description;rules=R.string.darts_mode_shanghai_rules;break;
   case "killer":name=R.string.darts_mode_killer_name;description=R.string.darts_mode_killer_description;rules=R.string.darts_mode_killer_rules;break;
   case "pro_training":name=R.string.darts_mode_pro_training_name;description=R.string.darts_mode_pro_training_description;rules=R.string.darts_mode_pro_training_rules;break;
   case "checkout":name=R.string.darts_mode_checkout_name;description=R.string.darts_mode_checkout_description;rules=R.string.darts_mode_checkout_rules;break;
   case "bobs27":name=R.string.darts_mode_bobs27_name;description=R.string.darts_mode_bobs27_description;rules=R.string.darts_mode_bobs27_rules;break;
   case "survivor":name=R.string.darts_mode_survivor_name;description=R.string.darts_mode_survivor_description;rules=R.string.darts_mode_survivor_rules;break;
   case "jackpot":name=R.string.darts_mode_jackpot_name;description=R.string.darts_mode_jackpot_description;rules=R.string.darts_mode_jackpot_rules;break;
   case "double_nothing":name=R.string.darts_mode_double_nothing_name;description=R.string.darts_mode_double_nothing_description;rules=R.string.darts_mode_double_nothing_rules;break;
   case "contract":name=R.string.darts_mode_contract_name;description=R.string.darts_mode_contract_description;rules=R.string.darts_mode_contract_rules;break;
   case "king":name=R.string.darts_mode_king_name;description=R.string.darts_mode_king_description;rules=R.string.darts_mode_king_rules;break;
   default:throw new IllegalStateException("Unknown mode: "+mode.id);
   }out.add(new ModeSpec(mode.id,context.getString(name),context.getString(description),context.getString(rules)));
  }return Collections.unmodifiableList(out);
 }
}
