# Étape 2 — catalogue des règles et modes de compétition de fléchettes

Statut : **cadrage documenté, non implémenté**. Date de référence : 2026-11-02.

## Objectif

Couvrir les règles de compétition avec une **source, une version et un profil par organisme**, sans présenter comme « officiel universel » un usage propre à une ligue. L'app devra afficher le profil de règles sélectionné à l'ouverture du match.

## Familles de règles à gérer

### A. Fléchettes traditionnelles / steel-tip

Priorité haute (FFD, WDF et DRA/PDC, selon les éditions applicables) :

- **501**, départ direct (`straight in`), arrivée sur double (`double out`) et bull intérieur comme double de 25. 
- **301**, **701**, éventuellement autres X01 : modes optionnels; ne pas les qualifier de formats officiels WDF/FFD sans source de compétition explicite.
- Décompte **fléchette par fléchette** (utile pour valider un finish ou un bust à la 1re ou 2e fléchette), regroupement en volées de trois maximum.
- BUST : total dépassé, 1 restant, zéro sans double quand double-out activé; remise au score au début de la volée.
- Ordre de départ, `bull-off/diddle` lorsque le règlement le prévoit, alternance au changement de leg, gestion de la dernière manche décisive.
- Legs, sets, `best-of`, `first-to`, arrêt anticipé, abandon/forfait, résultat officiel.
- Formats individuels et doubles avec alternance des partenaires. Équipe et feuille de match à composer selon la fédération.
- Stats vérifiables : moyenne sur 3 fléchettes, first 9, 100+/140+/180, tentative et réussite aux doubles, meilleures volées, checkout maximum, nombre réel de fléchettes lancées (ne pas compter des fléchettes jamais lancées).

### B. Fléchettes électroniques / soft-tip

**Profils de règles distincts** (France Darts, FEF, NDA) :

- X01 301 / 501 / 701 selon organisme, `open/straight in`, `double in`, `open out`, `double out`, `master out` **uniquement si prévu par le profil**.
- Bull entier à 50 ou bull partagé 25/50 : choix défini par le règlement, pas par une règle globale.
- Cricket avec secteurs 15 à 20 + bull, 3 marques pour fermer, règles de scoring et de victoire propres au profil.
- Variantes de Cricket : uniquement si documentées par le règlement d'une compétition, sinon marquées « loisir/entraînement ».
- Particularités en équipe : joueurs sur un score commun ou sur plusieurs tableaux, `freeze rule` lorsque prévue, nombre maximal de tours et règle de fin au temps/tours.
- Rebond, touches non enregistrées, responsabilité de l'arbitre / de la machine, événements à signaler sans forcer une modification automatique du score.

### C. Formats de compétition (séparés des règles de scoring)

- `1v1`, doubles, équipes; alignement / ordre des joueurs / remplaçants selon profil.
- Rencontres avec plusieurs parties, chaque partie avec son mode et son nombre de manches; exemple d'un programme combinant X01 et Cricket **uniquement dans les organisations qui le pratiquent**.
- Phase de poules round-robin, élimination directe, tirage et têtes de série, `bye`, classements, départages, forfaits, résultats, confrontation directe et différence de legs selon règlement du tournoi.
- Paramètres de phases qualif./finales distincts, versionnés pour la compétition concernée.

## Ce qui n'est PAS automatiquement un « mode officiel de compétition »

- Around the Clock, Shanghai, Killer, Bob's 27, jeux festifs, routines de doubles. Ces modes sont intéressants, mais relèvent par défaut de `entraînement / loisir` sauf attestation d'une compétition ayant un règlement propre.

## Format des règlements dans le code (cible)

Chaque profil de règles devra fournir au minimum :

```text
rulesetId           ex: ffd-steel-501-2026
organisme           ex: FFD
discipline          steel / soft
versionSource       date de publication ou numéro d'édition
sourceUrl           adresse officielle stable
sourceVerifieeLe    dernière date de vérification
mode                x01 / cricket / autre
initialScore        ex: 501 (si X01)
entryMode           straight / double / master
checkoutMode        straight / double / master
bullMode            full50 / split25_50
bustRule            type, séquence, restauration
dartsPerTurn        3
maxRounds           si imposé
winnerRule          atteinte zéro / fermeture + points / autres
matchFormat         legs, sets, ordre départ, phase
exceptions          règles spécifiques à l'organisme
```

Les options non pertinentes pour un type de jeu doivent être **absentes ou explicites**, jamais devinées. Les profils devront rester immuables pendant une partie; les futures modifications du règlement créent une nouvelle version. Sauvegarder l'ID et la version dans chaque match.

## Bibliothèque de tests obligatoire avant publication

- 501: sortie D20 depuis 40 ; bust si dépassement, 1 restant ou zéro par un simple ; conservation score début de volée.
- 501 : fin sur bull 50, arrêt dès la fléchette gagnante, pas de troisième fléchette fictive.
- 501 : 180, scores de 0, manches, sets, alternance départ, undo/rejouer sans double comptage.
- X01 électronique : `open out` valide zéro sans double, `master out` accepte les tirs autorisés par ce règlement.
- Cricket : simple/double/triple marques, bull partagé, marques excédentaires, objectif fermé et points requis pour gagner.
- Doublette/équipe : rotation des joueurs, `freeze`, ordre des parties selon configuration.
- Poules/tournois : nombres impairs (byes), ex aequo, victoire par forfait, passage de phase.
- Import/export / historique : un match conserve son règlement même après mise à jour de l'application.

## Sources de référence à vérifier et suivre

- Fédération Française de Darts — règlement intérieur (édition publiée le 5 juillet 2026) : https://www.ffdarts.fr/ffd-reglement-interieur-2/
- World Darts Federation — règlements de jeu et de tournois : https://dartswdf.com/rules/
- Darts Regulation Authority — rulebook professionnel : https://www.thedra.co.uk/dra-rulebook
- France Darts — fléchettes électroniques : https://www.france-darts.com/francedarts-reglement.aspx
- National Dart Association — règles du jeu électronique : https://ndadarts.com/nda-rules/
- Flèches électroniques de France — règlement fédératif : https://www.fef-darts.fr/_downloads/fef_reglement_des_joueurs_1.pdf

À vérifier avant implémentation : les *documents exacts* de l'édition en vigueur, les règles spécifiques de chaque compétition et les éventuels règlements de ligue. Cet inventaire n'est **pas** encore une certification de conformité.

## Ordre de réalisation de l'étape 2

1. Recenser et versionner chaque source officielle dans un registre.
2. Construire le moteur X01 pur Java + tests de bust/checkout/leg/set.
3. Construire le moteur Cricket indépendant + tests de marques/points et variantes.
4. Construire le modèle de match/rencontre multi-leg/multi-set et profils de compétitions.
5. Construire le mode arbitre et la saisie (manuelle, bouton par fléchette ou total de volée selon règles).
6. Vérifier les profils par des scénarios réels de compétition; faire relire par un joueur/arbitre expérimenté.
7. Seulement ensuite, ouvrir les modes dans l'interface commune et annoncer leur conformité.
