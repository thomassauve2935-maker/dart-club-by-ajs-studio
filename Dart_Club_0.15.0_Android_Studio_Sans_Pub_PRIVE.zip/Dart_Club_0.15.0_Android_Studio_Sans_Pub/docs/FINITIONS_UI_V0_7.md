# Darts Club — SportCore V0.7 : finition graphique premium

## Références et direction

- **Source d'inspiration** : Blackball BSM V11 Beta10.6.12 transmis par l'utilisateur.
- **Éléments étudiés** : `CHARTE_ARTISTIQUE_BSM_V11.md`, `ScoreboardStyle.java`, `BsmV11Ui.java` et les notes de finition Scoreboard.
- **Ce qui est repris** : hiérarchie simple, relief discret, bordures fines, coins réguliers, états pressés visibles, cohérence entre les écrans.
- **Ce qui n'est pas repris** : identité bleue/or, logos BSM, billard, mécanique sportive, assets graphiques du club.
- **Identité Darts Club préservée** : fond `#0A0A0C`, surface `#16161A`, accent `#FF2A4B`, succès `#00E676`, texte secondaire `#8F92A1`.

## Corrections codées

1. **SportUI** : couleurs de finition centralisées en ressources XML, boutons à double teinte légère et retour tactile natif, bords 14 dp, cartes à 16 dp, contrastes et hiérarchie des textes.
2. **Jeux** : grille unique des 15 modes, cartes plus équilibrées, titres lisibles sur plusieurs lignes, chevrons de navigation, mêmes espacements.
3. **Navigation** : onglet actif signalé par une surface rouge discrète et un libellé teinté. Toujours uniquement Jeux / Profils, sans accueil séparé.
4. **Match** : carte du joueur actif bordée de rouge, grand score accentué, pavé de score plus contrasté, touches Double/Triple avec état actif vert, trois fléchettes avec cellule de saisie active.
5. **Profils** : 4 statistiques essentielles, typographie plus lisible, cible au centre, légende de chaleur visuelle.
6. **Cible statistique** : remplacement des couleurs mêlées par **5 classes discrètes** (0 = gris, rare = bleu, moyen = jaune, fréquent = orange, maximum = rouge), pas de dégradé sur les secteurs, anneaux nets et numéros extérieurs blancs. Les intensités sont relatives au maximum enregistré et chaque numéro reçoit une seule couleur, car le moteur stocke le numéro touché, pas l'emplacement exact dans le secteur.
7. **Cible réutilisable** : `DartboardView` reste un composant Android vectoriel pouvant être affiché dans les profils et d'autres écrans. Son rendu n'est **pas** le SVG FreeSVG original ; l'intégration de celui-ci demeure un travail distinct.

## Invariants protégés

- Aucun changement dans `sport-darts` ni dans `sportcore-ads`.
- Catalogue plat de 15 jeux, aucune séparation jeu / entraînement / jeux maison.
- 1 à 8 joueurs, invités ou profils.
- Passage automatique après trois fléchettes et annulation après changement de joueur.
- Bannière AdMob et cadence interstitielle inchangées, uniquement annonces de test.
- Identifiant d'application existant `fr.dartsclub.app` conservé ; choix Google Play à vérifier avant publication.

## Vérifications réalisées ici

- Compilation et exécution des tests Java `SmokeTest`, `DartsEngineTest`, `MultiplayerStressTest`, `JourneySmokeTest` : OK.
- Analyse syntaxique de tous les fichiers Java : 0 erreur.
- Contrôle statique des dépendances Gradle : OK.
- Comparaison des sources `sport-darts` et `sportcore-ads` avec V0.6 : identiques.
- **Non réalisé** : assemblage Android/Gradle et vérification de captures réelles, SDK Android indisponible dans cet environnement.

## Recette sur téléphone demandée

1. Dans le catalogue unique, vérifier les 15 cartes avec texte grand et téléphone en portrait.
2. Lancer un 501 avec quatre joueurs, contrôler la carte active et les trois fléchettes.
3. Activer Double/Triple, contrôler l'état vert, saisir la troisième fléchette et annuler après changement de joueur.
4. Afficher un profil sans partie : cible neutre et message d'état vide.
5. Afficher un profil avec parties : cible avec cinq couleurs franches et numéros lisibles, même sur petit écran.
6. Tester le zoom du texte Android, un téléphone paysage et une tablette.
7. Vérifier que le bandeau AdMob n'empiète jamais sur les touches et que le plein écran publicitaire fonctionne comme en V0.6.

## Limites

La V0.7 est une **passe de finition graphique**, pas une validation de publication. Toute finition doit être jugée sur de vraies captures Android après compilation et interaction.
