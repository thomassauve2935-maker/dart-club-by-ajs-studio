# Validation V0.12 — nouveau logo

Le nouveau logo représente une cible traditionnelle et une fléchette dans son centre. Il est généré et composé dans Figma, puis exporté directement en PNG/SVG. Le nom, la palette claire, les règles, les profils, les sauvegardes et la désactivation des annonces sont conservés.

- `testDebugUnitTest`, `assembleDebug` et `lintDebug` : **BUILD SUCCESSFUL**.
- **22 tests réussis**, aucun échec ni erreur. **Rapport Lint : 0 erreur, 0 avertissement.**
- Vérifications d’architecture et de composants UI réussies.
- Symbole et version monochrome : exports 512 × 512, alpha transparent, copies Android identiques octet par octet.
- Logos complets clair/sombre : exports 1280 × 420, typographie vectorisée dans les SVG.
- Icônes Android : marge adaptative de 20 %, rayon maximal mesuré à 32,04 dp dans le repère 108 dp, inférieur à la zone sûre de 33 dp.
- Deux rendus supplémentaires du framework Android contrôlent l’icône adaptative et sa variante monochrome. Le symbole est également examiné dans l’en-tête et l’état vide des profils.
- Le test API 26 charge l’icône et termine toujours une partie. Les parcours et les tests publicitaires de la V0.11 restent validés.
- Manifeste sans initialisation automatique AdMob ni App ID de démonstration. Publicités toujours désactivées.
- Signature APK v2 valide et certificat comparé à la V0.11 publiée : identique. Package `fr.dartsclub.app`, versionCode 13, Android API 26 minimum, cible API 35.

Treize rendus des vues Android sont fournis dans `design/rendus-android/`. Ils proviennent de Robolectric ; aucun essai de la V0.12 sur téléphone physique n’a été effectué. Les maquettes Figma restent des références éditables distinctes des captures Android. L’essai de publicités réelles reste hors de cette version désactivée.

Les diagnostics préexistants de lecture des métadonnées Kotlin d’AdMob peuvent apparaître dans le journal de l’outillage ; le rapport final Lint et les tâches Gradle terminent sans anomalie de l’application.

La clé de signature et les sources Android restent hors du dépôt public de distribution. Les archives de sources excluent les caches, sorties de compilation, paramètres locaux et magasins de clés.
