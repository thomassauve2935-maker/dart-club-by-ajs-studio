# SportCore — architecture V0.2

**Priorité 1 : isolation de l'architecture, avant les moteurs de jeu.**

## Graphe des dépendances

```text
sportcore-model  (Java pur, aucune dépendance Android)
      ^                 ^                ^
      |                 |                |
sportcore-data   sportcore-ui       sport-darts
 (Android)        (Android)          (Java pur)
      ^                 ^
      |                 |
      +---- sportcore-navigation ----+
                       ^
                       |
                    app (Darts Club)
```

- `sportcore-model` : contrats indépendants (`SportSpec`, `ModeSpec`, `Profile`, `ProfileRepository`).
- `sportcore-data` : persistance locale et préférences Android (`LocalProfileRepository`, `LocalSettingsRepository`).
- `sportcore-ui` : composants et écrans de présentation, contrats de rendu (`ScreenHost`), routes logiques et sélection d'écran. **Aucun accès direct à SharedPreferences.**
- `sportcore-navigation` : Activity-coquille commune, navigation adaptative, création de l'UI et injection du stockage.
- `sport-darts` : catalogue d'intention des jeux et contenus de fléchettes. **Aucune dépendance Android.**
- `app` : assemble les modules et définit l'identité de l'application.

Note : le répertoire Gradle de l'application est `app` (plutôt que `app-darts`), afin de conserver la convention et d'éviter une migration inutile.

## Dépendances interdites

- `sportcore-model` -> `android.*` ou `fr.sportdarts.*`.
- `sportcore-ui` -> `fr.sportcore.data.*` ou `fr.sportdarts.*`.
- `sportcore-data` -> `fr.sportcore.ui.*` ou `fr.sportdarts.*`.
- `sport-darts` -> `android.*`, `fr.sportcore.ui.*` ou `fr.sportcore.data.*`.
- Les moteurs sportifs ne doivent ni stocker des préférences ni dessiner de boutons.

## Contrats et responsabilité

- Un écran expose `ScreenRenderer`, reçoit son contexte via `ScreenHost`.
- La source de données profils est l'interface `ProfileRepository` déclarée dans le modèle; `LocalProfileRepository` est une implémentation de cette interface.
- La navigation utilise `ScreenRoutes` et `DefaultScreenRouter`; les routes inconnues reviennent à Accueil.
- Le `sport-darts` indique les modes disponibles mais **ne calcule encore aucun score**.
- Pour un nouveau sport : module `sport-xxx` + application `app-xxx` indépendante, SportCore restant identique.

## Continuité et sécurité

- `Blackball Timer BSM` reste autonome. Ce ZIP ne modifie ni son code ni son GitHub.
- ID application de Darts Club : `fr.dartsclub.app` (provisoire pour tests; choisir un ID définitif AVANT publication).
- Pas de connexion à Google, pas de collecte de données ni de synchronisation dans ce socle.
- Sauvegarde actuelle des profils : JSON SharedPreferences, locale. Pour une application commerciale, considérer Room/SQLite et les migrations; ne pas faire croire que le cloud est déjà actif.

## Critère de sortie de l'étape 1

1. Compilation Android Studio de `app` et tests sur appareil réel (non réalisés dans cet environnement).
2. Tests portrait/paysage/téléphone/tablette et grand texte.
3. Sauvegarde persistante des profils; test de corruption et suppression.
4. Mise à jour d'un composant partagé visible sur toutes les pages sans retouche individuelle.
5. Aucune dépendance interdite (analyse statique dans `scripts/check_architecture.py`).
6. Tests Java purs verts et zéro régression sur la navigation.

**On ne commence les règles et moteurs compétitifs qu'une fois l'étape 1 validée sur Android.**
