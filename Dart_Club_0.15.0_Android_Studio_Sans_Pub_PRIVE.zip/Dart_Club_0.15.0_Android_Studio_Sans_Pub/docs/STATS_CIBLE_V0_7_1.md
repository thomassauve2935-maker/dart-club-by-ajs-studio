# Darts Club V0.7.1 — Doubles et triples dans les statistiques

## Comportement

- Un simple 20 colore les deux surfaces simples du 20.
- Un double 20 colore uniquement l'anneau extérieur du 20.
- Un triple 20 colore uniquement l'anneau intermédiaire du 20.
- Le 25 extérieur et le bull à 50 ont des compteurs et des couleurs indépendants.
- Un lancer compte pour un impact, quel que soit son score. Un triple ne compte pas pour trois impacts.
- Les cinq classes de couleur existantes restent relatives à la zone la plus touchée, avec une échelle commune aux 62 zones. Une zone sans impact reste grise.
- Les lancers OUT ne colorent aucune zone. Les deux surfaces simples d'un numéro partagent le même compteur : le journal ne permet pas de les distinguer.

## Données et compatibilité

`LocalDartsStats` agrège désormais le journal par numéro **et multiplicateur**. Le fichier de préférences `darts_stats_1`, sa clé `matches`, les identifiants de profils et le format des événements sont conservés. Les historiques existants contiennent déjà `segment` et `multiplier`, y compris pour les doubles et triples : ils sont recalculés à la lecture sans migration ni suppression.

L'ancien format à deux joueurs `id0` / `id1` reste lisible. Si un événement n'a pas de multiplicateur, il est traité comme un simple. Les zones invalides sont ignorées. Les victoires, matchs, moyennes et checkouts gardent leur calcul existant.

`DartboardView` copie les compteurs, calcule le maximum sur les zones valides et peint les anneaux avec leur propre fréquence. La légende et la description accessible indiquent désormais les zones distinctes. Le mode de cible traditionnelle garde ses couleurs habituelles.

Version Android : `versionCode 8`, `versionName 0.7.1-heatmap-test`. Le package reste `fr.dartsclub.app`.

## Vérifications effectuées

- `AdsFrequencyTest`, `DartsEngineTest`, `SmokeTest`, `JourneySmokeTest` : OK.
- `MultiplayerStressTest` : OK, 12 582 lancers sur 15 modes et 1 à 8 joueurs.
- `LocalDartsStatsTest` : OK. Lecture des historiques existants et anciens, 62 zones, séparation du 25/bull, exclusion des OUT et zones invalides, attribution par profil malgré un changement de position, cumul sur plusieurs matchs, sauvegarde/relecture, dédoublonnage et annulation du checkout.
- Compilation Java 17 avec Eclipse ECJ 3.40.0. Le calcul des statistiques et `DartboardView` ont également été compilés avec le JAR d'API Android 4.1.1.4 ; les tests JSON utilisent `org.json:json:20240303` sur JVM. Cette vérification ciblée des API ne remplace pas l'assemblage Gradle avec le SDK 35 configuré dans le projet.
- `scripts/check_architecture.py` et `scripts/check_ui_v07.py` : OK.
- **Non effectué :** assemblage de l'APK, exécution Android et contrôle visuel sur appareil.

## Vérification sur téléphone

1. Ouvrir un profil qui a déjà joué : ses doubles et triples doivent apparaître dans les anneaux correspondants sans réinitialiser les données.
2. Créer un profil et jouer un entraînement Pro Training avec, par exemple, un S20, un D20, trois T20, un 25 et un bull. Terminer l'entraînement avec des OUT, puis quitter le résultat pour enregistrer les statistiques.
3. Vérifier que le simple et le double 20 ne reçoivent pas la couleur des trois T20 et que les autres zones restent grises. Le 25 et le bull ont chacun un impact.
4. Annuler un lancer avant de terminer une nouvelle partie ; après sauvegarde, il ne doit pas figurer dans les statistiques.
5. Vérifier deux profils ayant touché des zones différentes, un profil vide, la lisibilité sur petit écran et la description TalkBack.
