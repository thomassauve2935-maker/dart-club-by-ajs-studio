# Validation Google Play 0.15.0 — sans publicité

Bundle release réel généré et signé par Gradle : Dart_Club_By_AJS_Studio_0.15.0_Google_Play_Sans_Pub.aab. SHA-256 : `d2f28c65d92110f6c1e42371954311c388469ffce50ecc252f2570d8fabcb76f` ; 1807489 octets.

## Valeurs lues dans le bundle

Identifiant **fr.dartsclub.app**, versionName **0.15.0**, versionCode **16**, minSdk **26**, targetSdk **36**, non débogable. La signature est celle de la clé d’envoi prévue dart-club-play-upload ; SHA-256 du certificat `C7:6A:98:B5:B7:53:1A:2E:30:48:1A:83:F6:1A:E2:C3:BA:72:BA:A3:47:73:87:09:DD:4F:E7:5B:B8:BE:3A:43`. Le certificat a été comparé à la clé privée prévue et à son empreinte connue. Play App Signing n’est pas encore vérifié dans la Console.

## Contrôles effectués

- Compilation de production, tests release et lint release : réussis. 54 tests, aucun échec/erreur/ignoré. L’avertissement lint restant signale une nouvelle version de Gradle disponible ; aucune erreur lint.
- Une seule modification de lien de confidentialité après ces tests : recompilation et lint du bundle final réussis, URL vérifiée sur le serveur et présence du lien vérifiée dans le DEX final.
- 282 entrées de traduction complètes en français, anglais et espagnol ; architecture et contrat UI statiques vérifiés.
- jarsigner -verify -strict avec le magasin de la clé prévue, bundletool validate, génération d’une APK universelle, vérification apksigner et alignement ZIP 16 Ko : réussis.
- 3394 définitions de classes DEX inspectées : aucun SDK Google Mobile Ads, UMP, Google Play Services ou Firebase. Permissions INTERNET, ACCESS_NETWORK_STATE, AD_ID et ACCESS_ADSERVICES_* absentes. Aucun App ID publicitaire ni fournisseur Google d’initialisation automatique. Aucun code natif embarqué.
- Notice de confidentialité publiée en FR/EN/ES et réponses HTTP 200 identiques aux fichiers préparés. L’application ouvre https://thomassauve2935-maker.github.io/blackball-confidentialite/dart-club/privacy-fr.html.

## État de la publication

Le propriétaire a demandé une première version gratuite sans publicité et a indiqué être sur la page Créer une application dans Play Console. Cette session n’a pas de navigateur Google authentifié pilotable ni de compte de service Play. Aucun envoi ni soumission Google Play n’a été effectué par l’assistant ; la disponibilité publique dépend de la Console et de Google.

Le dépôt Android source et les secrets restent hors des dépôts publics. Seules les notices HTML ont été publiées. L’espace de confidentialité GitHub Pages déjà actif a été utilisé, car l’intégration ne permet pas d’activer Pages sur le dépôt Dart (403). Les pages Dart dédiées sont ajoutées sous dart-club/ ; la page d’accueil existante n’est pas modifiée.

La clé d’envoi, conservée séparément, n’est pas incluse dans les archives de distribution. Le projet AdMob préparé précédemment reste distinct ; aucune unité AdMob n’est nécessaire à cette version. Après l’envoi du code 16, une mise à jour publicitaire devra utiliser un code supérieur.
