# Publicités — politique V0.11

## Version livrée

`MainActivity` fournit toujours `AdSettings.disabled()`, y compris en debug. Il n’existe plus de méthode `debugDemo()`. Aucun bloc de démonstration n’est configuré ; le validateur de production refuse le compte de démonstration Google.

Le module `sportcore-ads` retire `MobileAdsInitProvider` via le manifeste de bibliothèque, au niveau où le SDK est déclaré. L’application n’inclut aucun App ID de test. Le manifeste fusionné de l’APK est vérifié. `start()` et `createFooter()` ne lancent aucun SDK et ne créent aucun bandeau lorsque les annonces sont désactivées. Le lien de confidentialité publicitaire n’est pas affiché dans les réglages.

## Future activation

Après demande d’activation par le propriétaire : configurer les vrais blocs et le vrai App ID AdMob, ainsi que les réglages UMP et les informations de publication nécessaires. Passer explicitement `AdSettings.production(...)` depuis l’application. L’initialisation reste explicite et attend la décision UMP ; elle ne dépend pas d’un numéro DUNS saisi dans l’application.

- Le bandeau adaptatif garde son emplacement sous le contenu et la navigation, sans superposition aux touches.
- `onMatchCompleted(matchId)` est appelé après le résultat final sauvegardé. Il n’existe plus de callback basé sur le nombre de legs.
- Chaque nouveau match donne une occasion d’afficher un interstitiel si une annonce est prête. Aucun compteur de deux legs ou délai de cinq minutes.
- L’identifiant du match est enregistré avant l’affichage. Un échec de persistance empêche l’affichage. La reprise ou l’annulation/revalidation du même match n’ouvre pas une seconde occasion.
- Sans annonce prête à cette transition, il n’y a ni attente bloquante ni rattrapage ultérieur pendant la partie.

La diffusion réelle reste désactivée et ne peut pas être testée avec cette APK. Les tests couvrent le déclenchement métier, l’absence d’annonces dans la version courante et l’idempotence.
