# Validation — Dart Club By AJS Studio V0.9

Vérifications effectuées le **14 novembre 2026**.

## Compilation et paquet livré

La commande suivante termine avec **BUILD SUCCESSFUL** :

```bash
./gradlew :app:testDebugUnitTest :app:assembleDebug :app:lintDebug
```

JDK 17.0.21, Gradle 8.9, Android Gradle Plugin 8.7.3, SDK 35 et Build Tools 35.0.0. Le wrapper complet est livré, avec l’empreinte officielle de la distribution Gradle. Les fichiers de configuration de cet environnement, les caches et les clés de signature ne font pas partie du projet fourni.

L’APK de test est assemblée par Gradle, avec D8 et les ressources/dépendances de l’application. `apksigner verify --verbose` confirme une signature v2 valide. Le manifeste compilé indique `fr.dartsclub.app`, version `0.9.0-club-test`, code 10, minimum API 26 et cible API 35.

## Résultats automatisés

- **18 tests JUnit : 18 réussis, 0 échec.**
- **Lint Android : 0 erreur, 0 avertissement.**
- 120 parties menées à leur terme : les 15 modes avec chacun de 1 à 8 joueurs. Chaque lancer décisif est annulé puis rejoué ; le résultat, les scores et les legs doivent être identiques.
- Test de robustesse historique : 12 582 lancers sur les 15 modes et 1 à 8 joueurs.
- `LocalDartsStatsTest` exécuté séparément : historique ancien, 62 zones, bull, profils, annulation et retrait du seul résultat courant, puis réenregistrement.
- Contrôles statiques `check_architecture.py` et `check_ui_v07.py` conservés.

Les tests de parcours Android vérifient la création et le renommage des profils, les noms vides/dupliqués, la conservation des identifiants et statistiques, la conservation d’un nom en cours après recréation de l’activité, les grandes commandes, l’enregistrement immédiat du résultat, l’annulation d’une victoire, la revanche et la reprise après interruption.

Une vérification API 26 démarre l’application, charge son icône adaptative et termine une partie. Une vérification API 35 exerce les parcours principaux. Sur 360 × 640 dp, le bouton Commencer est entièrement visible. Sur 800 × 600 dp, toutes les touches de score et l’annulation sont visibles avec le tableau de score.

## Rendu et design

Onze rendus issus des vues Android et des ressources réelles de l’application sont conservés dans `design/rendus-android/` : catalogue, profils vides, réglages, profil, éditeur, préparation, match, résultat, match tablette, préparation compacte et précision avec doubles/triples.

Les rendus sont produits avec Robolectric 4.17 et son moteur graphique natif, puis examinés visuellement. Ils ne sont pas des captures d’un téléphone physique. Le test API 26 utilise le moteur de simulation classique pour le contrôle de compatibilité.

Les maquettes Figma complémentaires restent éditables : [résultats, profils, réglages et formulaire](https://www.figma.com/design/ABbnlIjTPVe8WtIVZ6GCZ4?node-id=13-119) et [match tablette](https://www.figma.com/design/ABbnlIjTPVe8WtIVZ6GCZ4?node-id=15-167).

## Corrections livrées

- Résultat enregistré à la fin du match et récupéré lors de la restauration d’une partie terminée. Annuler retire uniquement le résultat de ce match, puis permet de le terminer à nouveau sans doublon.
- Profil renommable sans changer son identifiant ; message d’erreur dans le formulaire, sans fermeture ni perte du texte. Le texte en cours est restauré après recréation de l’activité.
- Bouton Commencer fixé en bas de la préparation ; validation des joueurs centralisée dans le shell.
- Menus déroulants identifiables, réglages finalisés, écran de profil vide et actions de résultat assortis à la charte.
- Affichage du match en deux colonnes à partir de 700 dp de large.
- Attribut de navigation réservé aux API 27+ placé dans la bonne variante de thème. Icône adaptative avec couche monochrome. Objets de dessin de la cible réutilisés, sans changement de ses compteurs par zone.

## Portée

L’APK est une **version de test signée pour le développement**. L’essai sur téléphone physique reste à faire, notamment avec clavier système, TalkBack, rotation, publicités de démonstration et interruption du processus. Les appels réseau de consentement publicitaire sont isolés dans les tests d’interface ; la fréquence des annonces est testée séparément.

Publication Google Play, signature de production et identifiants publicitaires commerciaux constituent une étape distincte. Les 15 variantes du catalogue actuel sont conservées ; les règles détaillées sont consultables avant chaque partie.

## Références techniques

- [Robolectric — configuration Gradle et Java 17](https://robolectric.org/getting-started/).
- [Android — icônes adaptatives et couche monochrome](https://developer.android.com/develop/ui/compose/system/icon_design_adaptive).

Les résultats structurés et l’empreinte de l’APK se trouvent dans `validation-v09.json`.
