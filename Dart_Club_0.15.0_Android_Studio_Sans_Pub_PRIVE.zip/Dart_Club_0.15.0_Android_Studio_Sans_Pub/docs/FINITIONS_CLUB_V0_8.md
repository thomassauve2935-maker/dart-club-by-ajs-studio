# Dart Club By AJS Studio — Finition Club V0.8

## Identité

Nom demandé : **Dart Club By AJS Studio**. Dans l'en-tête, « Dart Club » et « By AJS Studio » sont disposés sur deux lignes. Le libellé Android complet reprend les deux parties du nom.

Un symbole original associe une cible ouverte et une fléchette rouge. Il a été généré en vecteurs dans Figma, avec utilisation de crédits IA Figma. Ses exports sont conservés dans `design/`. Le PNG transparent du symbole est intégré dans `drawable-nodpi/club_logo.png`, sans recadrage ni modification graphique. L'icône adaptative conserve une marge de sécurité.

Références : [écrans Figma](https://www.figma.com/design/ABbnlIjTPVe8WtIVZ6GCZ4?node-id=5-22), [logo](https://www.figma.com/design/ABbnlIjTPVe8WtIVZ6GCZ4?node-id=10-112). Les identifiants sont également enregistrés dans `design/figma.json`.

## Finitions intégrées au code

- Surfaces mates, bordures fines, rayon de carte de 16 dp et boutons de 12 dp. Accents `#FF2A4B`, fond `#0A0A0C`, surfaces `#16161A`, texte `#F7F7FA` et texte secondaire `#A4A6B3`.
- Typographie Android système : sans-serif pour les libellés, sans-serif-condensed en gras pour les titres et scores. Les maquettes utilisent les familles correspondantes Roboto et Roboto Condensed.
- Icônes vectorielles locales pour les réglages, le retour, la reprise et l'annulation. Aucun téléchargement d'images à l'exécution.
- Catalogue unique : cartes mieux espacées, grands nombres pour 301/501/701, noms longs autorisés à revenir à la ligne et hauteur minimale commune.
- Préparation : mêmes surfaces pour les sélections, commandes explicites et navigation Jeux/Profils conservée.
- Match : titre de mode lisible plutôt qu'identifiant interne, joueur actif signalé par une bordure rouge et un libellé, scores plus grands avec taille adaptée à la place disponible. La dernière volée est condensée en une ligne ; la volée actuelle conserve ses trois cases. Le réglage de grandes commandes agrandit les touches à 60 dp.
- Profils : identité du joueur, quatre statistiques essentielles et cible à 62 zones avec sa légende. Les actions de création et de suppression restent disponibles.
- Le socle SportCore reçoit la signature et le logo via des points d'extension génériques.

Les écrans Figma sont composés de calques texte, composants et vecteurs éditables. Ils ne contiennent aucune image aplatie de l'interface. Les valeurs « Thomas », scores et statistiques de la maquette sont des exemples fictifs. Le contenu des écrans défile sur Android lorsque la hauteur disponible ou le zoom de texte le nécessite.

## Compatibilité

Le moteur `sport-darts/engine`, `LocalDartsStats`, `ActiveDartsStore`, `DartboardView` et le module publicitaire sont identiques à la V0.7.1. Le nom et les textes de marque de `DartsSpec` changent ; les règles de calcul ne changent pas. Les clés de préférences, identifiants de profils et formats d'historique sont préservés.

Une incompatibilité de visibilité préexistante a été corrigée : `MainActivity.onCreate` est public, comme la méthode qu'il redéfinit dans `SportCoreActivity`.

## Validation effectuée le 14 novembre 2026

- Revue des quatre écrans Figma : correction des marges de navigation, des noms de jeux sur deux lignes et du cadrage de la légende statistique. Polices contrôlées : Roboto / Roboto Condensed.
- Compilation et liaison des ressources internes avec **AAPT2 8.7.3-12006047**, API 35 ; PNG, vecteurs, thèmes, icône adaptative et références de ressources acceptés.
- Compilation Java 17 des **sept modules**, avec Eclipse ECJ 3.40.0, les R générés par AAPT2, les API Android 35 et les classes des SDK Google Ads API 25.5.0 / UMP 4.0.0. Pour la vérification sur JVM, les stubs de bibliothèque standard contenus dans `android.jar` sont exclus au profit de la bibliothèque standard du JRE.
- `AdsFrequencyTest`, `DartsEngineTest`, `SmokeTest`, `JourneySmokeTest`, `MultiplayerStressTest` et `LocalDartsStatsTest` : OK. Le test multijoueur couvre 12 582 lancers, 15 modes et 1 à 8 joueurs. Le test de statistiques couvre les 62 zones, les anciens historiques et l'annulation.
- `scripts/check_architecture.py` et `scripts/check_ui_v07.py` : OK. Le dernier contrôle est statique et ne constitue pas une validation de rendu.
- XML bien formés ; comparaison binaire des fichiers de moteur, de sauvegarde, de statistiques, de cible et de publicité avec V0.7.1 : identiques.

Ces vérifications ne constituent **pas** un assemblage APK complet. Il reste à effectuer la compilation Gradle avec D8, l'installation sur un appareil ou émulateur, et la comparaison des captures Android avec Figma. Les ressources temporaires de vérification ne sont pas livrées comme APK.

## Recette Android

1. Ouvrir le projet dans Android Studio avec Java 17, SDK Platform 35 et Gradle 8.9, puis lancer `:app:assembleDebug`.
2. Vérifier le libellé de l'application, l'icône sur des lanceurs ronds/carrés et la signature dans l'en-tête.
3. Parcourir les 15 modes, puis configurer 1, 2, 4 et 8 joueurs. Contrôler les noms longs et le zoom de texte.
4. Jouer un 501, saisir simples/doubles/triples, annuler après la permutation et reprendre une partie interrompue.
5. Contrôler les profils existants et nouveaux, une cible vide, le 25/bull, les doubles et les triples.
6. Vérifier les grandes commandes, un téléphone 360 dp, le paysage, une tablette et TalkBack.
7. Vérifier que les publicités de test restent séparées des touches et n'interrompent pas un leg.
