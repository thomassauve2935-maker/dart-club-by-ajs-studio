# Étape 3 — Audit des ressources réutilisables pour Darts Club / SportCore

**Date de vérification : 2 novembre 2026**  
**Statut : recherche et sélection documentaire terminées, intégration différée.**  
**Objectif :** éviter de redévelopper inutilement des éléments existants, tout en préservant la possibilité de publier une application Android commerciale et de mutualiser les ressources dans SportCore.

> « Gratuit » ≠ domaine public ≠ libre de droits sans condition. Chaque ressource doit avoir une licence explicite et vérifiable, associée à un fichier et une version. Une licence du *code* ne confère pas forcément des droits sur le nom, le logo, les images marketing ou les ressources de tiers.

## A. Ressources retenues comme candidates

| Catégorie | Ressource / source | Licence observée | Cible d'utilisation | Décision | Conditions principales |
|---|---|---|---|---|---|
| Icônes interface | [Google Material Symbols](https://developers.google.com/fonts/docs/material_symbols) | Apache-2.0 | Boutons, navigation, réglages, scores | **Priorité 1** | Conserver les notices de licence pertinentes ; ne pas reproduire la marque Google. |
| Icônes alternatives | [Lucide Icons](https://github.com/lucide-icons/lucide/blob/main/LICENSE) | ISC et MIT pour icônes provenant de Feather | Pictogrammes communs à tous les sports | **Alternative** | Inclure copyright et notices des icônes réutilisées. |
| Schéma des dimensions de cible | [Wikimedia — Dartboard dimensions.svg](https://commons.wikimedia.org/wiki/File:Dartboard_dimensions.svg) | CC0 1.0 | Référence documentaire pour créer notre rendu vectoriel | **Priorité 1 (référence)** | Contrôler mesures et règles officielles en vigueur ; aucun import de marque. |
| Icône de cible simplifiée | [SVG Repo — Dartboard](https://www.svgrepo.com/svg/23874/dartboard) | CC0 affiché sur la page de l'élément | Icône d'accueil ou symbole décoratif | **Optionnel** | Ne pas confondre illustration générique et cible géométriquement exacte. |
| Pack sonore d'interface | [Kenney — Interface Sounds](https://kenney.nl/assets/interface-sounds) | CC0 indiqué sur la page (100 fichiers) | Validations, navigation, compte à rebours | **Priorité 1** | Vérifier le fichier de licence inclus dans le téléchargement ; sélection et réglage du volume. |
| Pack sonore d'impacts | [Kenney — Impact Sounds](https://kenney.nl/assets/impact-sounds) | CC0 indiqué sur la page (130 fichiers) | Effets de lancer / impact | **À auditionner** | Aucun son n'est validé comme son réaliste de fléchette sans écoute comparative. |
| Typographie | [Roboto / Google Fonts](https://github.com/google/fonts/blob/main/ofl/roboto/METADATA.pb) | SIL OFL 1.1 | Scores et interface | **Priorité 1** | Préférer la police système Android si adaptée ; si police embarquée, joindre les mentions OFL. |
| Application de référence | [DartLodge](https://github.com/mathrb/dartlodge) | MIT pour le code | Étudier événements, stats, modes, tests | **À étudier** | Flutter/Dart, non directement interchangeable avec Java Android ; marques, logo et assets marketing exclus de la licence selon [TRADEMARK.md](https://github.com/mathrb/dartlodge/blob/main/TRADEMARK.md). Notices si réutilisation de code. |
| Exemple X01 | [darts-x01-scoreboard](https://github.com/vassdoki/darts-x01-scoreboard) | MIT déclaré pour le *scoreboard source*, pas tout le projet | Inspiration score et configuration | **À étudier sous réserve** | Délimiter les fichiers effectivement sous MIT avant toute reprise. |

## B. Projets à garder pour étude comparative, sans copier leur code dans notre application propriétaire

| Projet | Licence | Intérêt | Risque |
|---|---|---|---|
| [Dart Checker, F-Droid](https://f-droid.org/fr/packages/com.DartChecker/) | GPL-3.0-only | X01, Cricket, sets/legs, checkouts, undo, offline | Reprise de code soumise aux obligations GPL et distribution du code source correspondant. |
| [Bullseye, F-Droid](https://fdroid.gitlab.io/jekyll-fdroid/en/packages/x653.bullseye/) | GPL-3.0-only | X01, Cricket, statistiques | Obligations GPL en cas de copie/adaptation du code. |
| [InstaDarts](https://github.com/Instadarts/instadarts) | AGPL-3.0 | Détection caméra, scoring, synchronisation | Obligations de copyleft renforcées, notamment en cas d'utilisation réseau. |
| [Maurits Silvis — darts](https://github.com/mauritssilvis/darts) | GPL-3.0-or-later | Calcul de checkouts en Java (projet archivé en avril 2026) | On privilégie une implémentation de l'algorithme créée indépendamment et testée. |
| [oddbits-darts](https://github.com/oddbits-de/oddbits-darts) | Aucune licence open source annoncée | Exemples d'ergonomie, entraînements, doublettes | **Ne pas reprendre le code** sans autorisation explicite. |

Les licences GPL/AGPL autorisent aussi des usages commerciaux, **mais** imposent des obligations incompatibles avec notre option de distribuer simplement une application propriétaire sans publier le code dérivé. Cela ne veut pas dire que les interfaces ou les règles du jeu ne peuvent pas être étudiées ; les règles de score seront spécifiées indépendamment à partir de sources officielles.

## C. Choix techniques recommandés

1. **Ne pas utiliser une image raster comme vraie cible tactile.** Construire un composant `DartboardView` vectoriel avec `Canvas`, géométrie et hitboxes communes, indépendant de l'écran et du ratio d'affichage. Conserver le SVG CC0 de Wikimedia seulement comme référence de dimensions, et confirmer les dimensions dans les règlements.
2. **UI commune :** un seul pack d'icônes principal, Material Symbols ; éviter de mélanger trois styles. SportCore gère taille, contraste et équivalents accessibles.
3. **Sons :** sélectionner quelques effets CC0 courts dans Kenney ; sons désactivables et volume réglable ; pas de publicité ou son intrusif pendant le score.
4. **Police :** utiliser Roboto système par défaut ; intégrer une police OFL spécifique seulement si un besoin visuel réel apparaît.
5. **Score et statistiques :** programmer la logique Java dans `sport-darts`, à partir de profils de règles versionnés (étape 2), puis tests automatisés. DartLodge peut inspirer la structure *event log / replay* mais ne remplace pas la validation.
6. **Ne pas importer d'assets de marque ni d'illustrations de fédérations sans autorisation.** Logo, nom d'application, icône Play Store et captures doivent être originaux.

## D. Registre de licence obligatoire (pour chaque fichier tiers importé)

Enregistrer dans `third_party/ASSETS_REGISTRY.json` à chaque import :

- identifiant interne ; nom du fichier / chemin ; auteur ou détenteur annoncé ; URL source exacte ; URL licence exacte ; licence et version ; date de vérification ; version ou hash SHA-256 ; type (graphique/son/code/police) ; modifications réalisées ; obligations de crédits ; preuve locale de la licence ; application / module qui l'utilise ; statut (candidat, approuvé, intégré, retiré).
- Joindre le texte de licence et notices applicables dans `third_party/licenses/` et afficher une section « Licences tierces » dans les réglages de l'application.
- Contrôler aussi les licences transitives et les marques, indépendamment de la licence générale du dépôt.

## E. Checklist d'entrée en production

- [x] Sources potentielles recherchées et licences affichées contrôlées.
- [x] Compatibilité commerciale identifiée pour les principales familles CC0 / MIT / ISC / Apache-2.0 / OFL.
- [x] Projets à copyleft GPL/AGPL identifiés et isolés des candidats à intégration directe.
- [ ] Télécharger les fichiers retenus et vérifier leurs licences incluses, leur provenance et leurs hashes.
- [ ] Vérifier graphismes à l'écran, sons à l'écoute, accessibilité et pertinence fonctionnelle.
- [ ] Ajouter les notices obligatoires et un inventaire des composants effectivement intégrés.
- [ ] Contrôle final juridique et sécurité des dépendances avant commercialisation.

## F. Limites de cet audit

Cet inventaire vérifie les **licences annoncées sur les pages sources** ; il n'établit pas une chaîne de droits indépendante pour chaque auteur, fichier ou dépendance. **Aucune ressource externe n'a été incorporée dans le projet à cette étape.** Aucun score moteur externe n'a été compilé ou testé. La recherche de ressources et la validation des règles de compétition sont deux travaux distincts.
