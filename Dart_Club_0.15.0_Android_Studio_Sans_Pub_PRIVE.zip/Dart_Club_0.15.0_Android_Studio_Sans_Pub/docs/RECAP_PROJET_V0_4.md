# Récapitulatif — Darts Club V0.4 (2 novembre 2026)

## 1. Socle prioritaire : SportCore
6 modules, séparation des responsabilités, composants Android réutilisables, thème et navigation centralisés. Darts Club est indépendant de Blackball Timer.

## 2. Parcours utilisateur validé
Au lancement : tous les modes sur la même grille. Uniquement Jeux et Profils en navigation. Cliquer un jeu => préparer (invités disponibles) => jouer => résultat => revanche/choisir un jeu.

En partie : pavé 1–20, Bull, OUT, Double, Triple ; saisie par fléchette ; passage automatique ; Annuler reste disponible y compris après changement de joueur. La partie reste localement en mémoire. Pas d'inscription obligatoire.

## 3. Jeux retenus
**7 modes compétitifs/conviviaux** : 301, 501, 701, Cricket, Around the World, Shanghai, Killer.
**3 modes d'entraînement** : Pro Training, Training Checkout, Bob's 27.
**5 jeux maison** : Survivant, Jackpot, Double ou Rien, Le Contrat, Roi de la cible.
Ces catégories sont une nomenclature de cahier des charges : elles **ne sont pas visibles comme catégories dans l'application**.

## 4. Profils et statistiques minimales
Un nom / identifiant permanent local et quatre chiffres : matchs joués, victoires, moyenne sur 3 fléchettes (parties X01), meilleur checkout. Cible heatmap des numéros touchés. Pas de suivi des zones *visées* ou manquées ; OUT ne fabrique pas de position.

## 5. Charte graphique
Fond #0A0A0C ; surface #16161A ; rouge CTA #FF2A4B ; vert valide #00E676 ; texte secondaire #8F92A1 ; grands nombres condensés ; commandes arrondies 12dp ; icône bull/fléchette sans texte. L'alpha utilise des polices système de substitution, pas encore Teko / Montserrat / Inter, et un rendu plat au lieu d'effets néon appuyés.

## 6. Ressources tierces
Cible SVG OpenClipart/FreeSVG *candidate*, annoncée public domain/CC0, non intégrée à cette version faute d'obtenir son fichier binaire. La cible d'affichage alpha est réalisée dans `DartboardView` et ne doit pas être confondue avec la ressource tierce. Voir `docs/ETAPE_3_RESSOURCES_LIBRES.md`.

## 7. Ce qui est codé et ce qui ne l'est pas
Codé : sélection, préparation, moteur des 15 variantes de base, prise en compte de chaque fléchette, undo par relecture, auto-changement, sessions sauvegardées, profils, score et heatmap. Vérifié sans Android SDK : tests Java et architecture.
Non validé : **APK Android** et ergonomie réelle sur appareil ; règles compétitives fédérales complètes, sets, correspondance exacte SVG, polices externes et animations avancées. **Ne pas déclarer l'application finalisée.**
