# Darts Club V0.6 — Joueurs 1 à 8 et détail des fléchettes

## Demandes appliquées

1. Avant **chacun des 15 modes**, un choix direct « 1 joueur » à « 8 joueurs » dans un menu déroulant.
2. Le nombre de sélecteurs de participants suit immédiatement le choix. Chaque participant peut être un invité, sans inscription, ou un profil enregistré. Un même profil ne peut pas occuper deux places dans une partie.
3. Le moteur de jeu ne suppose plus deux joueurs : tableaux de scores, vies, manches, marques Cricket, progression Around, objectifs, gagnant, tour actif et rotation dimensionnés selon le nombre choisi.
4. Dans l'écran de partie, les **trois fléchettes du joueur actif** sont toujours affichées séparément : cases vides avant saisie, puis `20`, `T20`, `D16`, `OUT`, `25`, `BULL`, etc.
5. Dès la troisième fléchette, le jeu change automatiquement de joueur. La **dernière volée terminée** demeure visible et attribuée à son joueur, même après ce changement.
6. Le bouton **Annuler** se trouve dans l'en-tête de match et après le pavé, pour rester accessible si l'écran est défilé. Il retire un seul lancer et reconstitue l'état du match, même après un changement de tour, bust ou checkout.
7. Les cartes de scores des 1 à 8 joueurs sont disposées sur une **ligne défilante horizontalement**, plutôt qu'une grille de huit colonnes illisibles. Le joueur actif est souligné par un contour rouge et annoncé en toutes lettres.
8. Une sauvegarde en cours conserve la liste complète des participants et les lancers ; le chargement garde un chemin de compatibilité pour les anciens fichiers V0.5 à deux personnes.
9. L'historique et les statistiques enregistrent les **identifiants des profils par joueur**, sans limite de deux. Les profils anciens restent lisibles.
10. Le module publicitaire AdMob reste inchangé : bannière et interstitiel de test, pas de diffusion commerciale en release.

## Parcours simplifié

**Jeux** → choisir un mode → **Nombre de joueurs (1 à 8)** → choisir invités/profils → **Commencer** → saisir 3 lancers → changement automatique → résultat.

Pour les jeux traditionnellement solo (Bob's 27, checkout, etc.), **1 joueur reste la sélection initiale**, mais le choix de 2 à 8 est possible pour des défis à plusieurs.

## Vérifications effectuées sans SDK Android

- Compilation JDK 17 des modules `sportcore-model`, `sport-darts`, des politiques AdMob et des tests : **OK**.
- `SmokeTest`, `JourneySmokeTest`, `DartsEngineTest`, `AdsFrequencyTest` : **OK**.
- `MultiplayerStressTest` : **12 582 lancers déterministes**, 15 jeux × 1 à 8 joueurs, annulation/redépôt : **OK**.
- Analyse syntaxique Java : **34 fichiers, 0 erreur**.
- Contrôle statique d'architecture : **7 modules séparés, OK**.

Le **build Android complet n'a pas été exécuté** dans cet environnement (SDK non disponible). Le dernier build Android validé par l'utilisateur concernait la V0.5, pas cette V0.6. Tester cette nouvelle version dans Android Studio et sur l'appareil avant publication.

## Scénarios à tester dans Android Studio

1. Ouvrir 501, changer le nombre de 2 à 1, puis 3, 5 et 8 : vérifier les champs joueurs affichés.
2. Ajouter deux profils, sélectionner l'un d'eux à deux emplacements : vérifier que le démarrage est refusé ; vérifier que plusieurs invités sont acceptés.
3. En 501 à 4 joueurs, entrer `T20`, `20`, `D16` pour le joueur 1 : les trois libellés doivent apparaître ; après troisième lancer, c'est au joueur 2 et la dernière volée reste affichée.
4. Annuler la troisième fléchette : le joueur 1 redevient actif, ses deux premières fléchettes restent affichées, le score est correct.
5. À 8 joueurs, effectuer un tour complet, revenir au premier joueur ; tester une rotation de l'écran, la mise en pause et la reprise après fermeture.
6. Tester en 301 un bust dès la deuxième fléchette, puis Annuler.
7. Tester Cricket à 8 joueurs via le bouton de détail des marques, Around et Killer à plusieurs.
8. Terminer une partie avec un profil enregistré au troisième emplacement : vérifier les victoires et la moyenne uniquement pour le profil correct.
9. Vérifier la lisibilité des scores et du pavé sur téléphone portrait et tablette paysage.
10. Vérifier que les annonces de test ne bloquent jamais l'usage d'Annuler ou la saisie.

## Limites indépendantes de cette évolution

La V0.6 reste une **alpha**. Les variantes fédérales complètes, équipes, sets, accessibilité et certains détails de règles des jeux maison nécessitent encore validation. Aucune modification n'a été faite au projet Blackball Timer BSM.
