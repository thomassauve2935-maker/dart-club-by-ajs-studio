# SportCore — Publicités AdMob V0.5

## Périmètre validé

Bannière persistante : affichée en bas, hors zone de jeu, sous la barre Jeux/Profils en portrait, et sous la disposition entière en paysage/tablette. Conteneur invisible si aucune annonce.

Interstitiel : demandé toutes les deux manches (legs) **gagnées**, et pas plus d'une fois toutes les 5 minutes ; à la transition de leg seulement. Il est possible que l'annonce affichée soit une image et non une vidéo. Absence d'annonce = aucune attente ni blocage.

Le résultat d'un leg est enregistré **avant** tout affichage. Le nombre de legs publicitaires est conservé sur l'appareil et les legs revalidés après Undo ne sont pas comptés une seconde fois.

## Architecture

- `sportcore-ads/AdSettings.java` — configuration par application, `debugDemo()` ou `disabled()` ; pas de vraies clés dans le socle.
- `sportcore-ads/AdFrequencyCap.java` — politique pure Java, testable, indépendante de Google.
- `sportcore-ads/AdMobController.java` — chargement SDK, UMP, bannière, interstitiel, cycle de vie.
- `sportcore-navigation/SportCoreActivity.java` — emplacement d'extension du bandeau + réglages, sans import AdMob.
- `app/MainActivity.java` — integration : chaque changement de leg réussi notifie le composant après `persist()`.

## Développement et recette

| Test | Attendu |
|---|---|
| Debug : catalogue | Une bannière Google de test peut apparaître après consentement |
| Debug : partie | La bannière ne recouvre pas Annuler ni les scores |
| Leg 1 gagné | Pas d'interstitiel |
| Leg 2 gagné | Interstitiel si préchargé et délai respecté |
| Legs suivants avant 5 minutes | Aucune annonce |
| Annuler après leg, puis le refaire | Aucune deuxième incrémentation |
| SDK hors-ligne, consentement non obtenu, pub non chargée | Jeu continue sans attendre |
| Écran de résultats | Même emplacement de bandeau ; sauvegarde des scores |
| Rotation / pause / reprise | Pas de réinitialisation imprévue du compteur |
| Build release V0.5 | Aucune demande d'annonce |

**Prépublication obligatoire** : remplacer l'App ID du manifeste et les unités via `AdSettings.production(...)`, configurer la CMP UMP certifiée dans AdMob, les déclarations Play Console et la politique de confidentialité ; vérifier l'ensemble sur Android.

## Sources Google

- https://developers.google.com/admob/android/quick-start
- https://developers.google.com/admob/android/privacy
- https://developers.google.com/admob/android/interstitial
- https://developers.google.com/admob/android/test-ads
- https://support.google.com/admob/answer/6066980?hl=fr-FR
