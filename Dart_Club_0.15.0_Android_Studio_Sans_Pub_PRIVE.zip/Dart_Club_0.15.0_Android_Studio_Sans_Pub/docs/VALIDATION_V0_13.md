# Validation V0.13 — 16 novembre 2026

Version `0.13.0-club-test`, code 14, package `fr.dartsclub.app`, minSdk 26 / targetSdk 35.

## Vérifications

- 39 tests JUnit/Robolectric : 24 parcours d’application, 9 tests d’expérience/sauvegarde et 6 suites de régression du moteur, des profils, statistiques et publicités.
- Suites historiques : 120 parties terminées couvrant 15 jeux et 1 à 8 joueurs ; journal de 12 582 lancers.
- Android 35 : rendu natif des écrans, téléphone 390×844, petit écran 360×640 et tablette 800×600. Android 26 : création et fin de partie, mode graphique Legacy.
- Thèmes : passage entre quatre palettes, retour nuit → clair, persistance après recréation, journal des lancers inchangé.
- Grandes commandes et texte à 130 % : Commencer entièrement visible avec 8 joueurs et 15 legs sur 360×640.
- Toucher réel : aucun lancer à l’appui ; un seul enregistrement au relâchement. Action immédiate lorsque les animations sont désactivées.
- Résultat : annulation et revalidation, statistiques sans doublon, partage PNG via URI content avec droit de lecture. Carte à huit noms longs rendue sans chevauchement.
- Sauvegardes : aller-retour complet, fichier corrompu/incompatible rejeté avant écriture, échec au milieu de la restauration avec retour aux données précédentes, récupération du journal et conservation de l’ancien format statistique. Lecture limitée à 4 Mio.
- Audio : garde de lecture testée en modes normal, silencieux et vibreur, volume nul, son coupé, pause et fermeture. Aucune règle de jeu ne dépend du son ou d’une animation.
- Contrastes : 60 associations de texte dans les quatre palettes à au moins 4,5:1 ; détail dans `design/contrastes-v013.json`. Ce contrôle de couleurs ne constitue pas un audit d’accessibilité complet.
- APK compilée, Android Lint sans erreur ni avertissement ; contrôles statiques d’architecture et de composants conservés.
- Manifeste sans initialisation automatique AdMob ni App ID de démonstration. Annonces désactivées en debug et release.

## Limites

Aucun essai de cette version sur téléphone physique ni écoute des haut-parleurs n’a été effectué ici. Les rendus sont produits avec Robolectric et les vraies ressources Android. Vérifier sur le Pixel 8 Pro la mise à jour, les sons/vibrations et l’ouverture du sélecteur de partage/fichiers.

## Mise à jour

Certificat de test conservé : SHA-256 `f722b4ae71683723196f87ccda992e577f64904c616b9f4c7b960d5eb252bd06`. La V0.13 s’installe par-dessus les V0.9–V0.12 distribuées avec cette signature, sans désinstallation. Les préférences et statistiques existantes sont conservées ; le thème initial est Club clair.

Les sources et les clés ne sont pas publiées dans le dépôt d’APK.
