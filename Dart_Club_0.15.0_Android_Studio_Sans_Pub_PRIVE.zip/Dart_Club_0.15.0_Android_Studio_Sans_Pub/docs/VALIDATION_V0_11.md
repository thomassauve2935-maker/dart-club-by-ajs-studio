# Validation V0.11 — 14 novembre 2026

Compilation `testDebugUnitTest`, `assembleDebug`, `lintDebug` : **BUILD SUCCESSFUL**. JDK 17, Gradle 8.9, AGP 8.7.3, SDK 35 et Build Tools 35.0.0.

- **22 tests réussis** : 16 parcours Android et 6 suites du moteur/socle. Aucun échec ni erreur.
- **Rapport Android Lint : 0 erreur, 0 avertissement.**
- Tests existants conservés : 120 parties terminées, annulées et rejouées sur les 15 modes et 1 à 8 joueurs, robustesse de 12 582 lancers, profils, persistance, résultat, reprise, grandes commandes, API 26 et formats compact/tablette.
- Nouveau test publicitaire : un match en deux legs termine le premier sans émettre l’événement publicitaire ; un seul événement est émis après la fin du second et la sauvegarde finale. Réafficher le résultat ne crée pas d’événement.
- Nouveau test de désactivation : aucun App ID AdMob dans les métadonnées, aucun fournisseur d’initialisation automatique, aucun bandeau et aucun lien publicitaire dans les réglages. Le double de test UMP provoque une erreur si le code essaie de demander un consentement ; aucun parcours ne le déclenche.
- La suite publicitaire vérifie chaque nouveau match, les doublons après annulation/reprise, les identifiants absents et le refus des blocs de démonstration.
- Les contrôles statiques de l’architecture et des composants passent.

Le manifeste fusionné de l’APK ne contient ni `MobileAdsInitProvider` ni l’App ID Google de démonstration. Le contrôleur est configuré désactivé dans toutes les variantes de l’application. Le module conserve le SDK et les emplacements nécessaires à une activation explicite future ; aucune diffusion réelle n’est activée ou testée.

La signature APK v2 est valide. Le certificat est comparé à celui de l’APK V0.10 publiée et est identique. Même package `fr.dartsclub.app`, versionCode 12 ; min API 26 et cible API 35.

Onze rendus natifs Android sont livrés dans `design/rendus-android/`. Catalogue, match, profils, réglages, état vide et tablette ont été examinés. Les rendus sont issus de Robolectric, pas d’un téléphone physique. Les couples texte/fond principaux et ceux des cartes colorées sont mesurés à au moins 4,5:1. Le thème clair exclut le foncement automatique sur API 29+.

Les quatre maquettes de cette palette dans Figma sont éditables, avec textes Roboto/Roboto Condensed, instances de composants et vecteurs. Le logo est conservé. La cible décorative a les mêmes tracés SVG et Android ; les fréquences de doubles et triples de la cible statistique restent distinctes.

Le journal de l’outillage peut émettre des diagnostics préexistants de lecture des métadonnées Kotlin d’AdMob ; le rapport final Lint et les tâches Gradle terminent sans anomalie de l’application. L’essai de cette nouvelle version sur téléphone physique reste à faire, ainsi que celui de publicités réelles lors d’une future activation.

Les sources, caches et clés ne sont pas publiés dans le dépôt public. Les archives de sources excluent `build`, `.gradle`, `.idea`, `.git`, `local.properties` et les magasins de clés.
