# Darts Club — Parcours utilisateur V0.3

## Objectif

Application utile sans lecture de notice. Priorité : une entrée immédiate, une configuration brève, zéro création de compte obligatoire, une interface stable pendant le jeu. Ce document décrit le parcours cible ET ce que la version V0.3 réalise réellement.

## Audit du socle V0.2

| Problème observé | Décision UX | Statut V0.3 |
|---|---|---|
| 5 onglets dont Réglages | 4 onglets principaux; Réglages dans l'en-tête | Implémenté |
| Accueil composé de cartes équivalentes | Priorité visuelle à Partie rapide | Implémenté |
| Aucun flux de préparation de partie | Nouveau brouillon de séance générique | Implémenté |
| Choix des modes uniquement en fiche de règles | CTA « Préparer ce mode » + consultation secondaire des règles | Implémenté |
| Profils isolés et perçus comme prérequis | Deux invités par défaut, profils locaux facultatifs | Implémenté |
| Réglages sensibles à la rotation | Sauvegarde des paramètres du brouillon dans Bundle | Implémenté |
| Réglages potentiellement pénibles à manipuler | Stepper +/− grandes zones au lieu d'un curseur précis | Implémenté |
| Barres système risquant de recouvrir des commandes | Protection des insets système dans le conteneur racine | Implémenté, à tester sur appareils |
| Démarrage sans moteur X01 | Ne jamais afficher un faux bouton « Démarrer » | Intentionnellement non implémenté |

## Arbre de navigation cible

```text
Démarrage
└── Accueil
    ├── Partie rapide [mode recommandé du sport]
    │   └── Préparer une partie [2 invités, 1 manche gagnante]
    │       ├── sélectionner joueurs enregistrés (facultatif)
    │       ├── ajuster nombre de manches gagnantes
    │       ├── choisir un autre mode → catalogue
    │       └── Démarrer [futur moteur sportif]
    ├── Choisir un mode
    │   ├── Préparer ce mode → Préparer une partie
    │   └── Consulter les règles → dialogue
    ├── S'entraîner → catalogue des entraînements
    └── Profils → gérer les joueurs locaux

Navigation persistante : Accueil / Jouer / Entraîner / Profils
Réglages : action de l'en-tête (retour à la section précédente)
Retour Android : configuration → choix du mode → accueil.
```

## Moments critiques et règles d'interaction

1. **Premier lancement** : aucune connexion ni création de profil obligatoire. Une action principale explicite et prioritaire.
2. **Partie rapide** : le mode par défaut vient du `SportSpec`, non d'une constante fléchettes cachée dans SportCore; aucun prérequis technique imposé.
3. **Mode personnalisé** : une action pour choisir le mode, une autre pour le configurer. Les règles sont disponibles sans faire obstacle au flux.
4. **Participants** : deux invités proposés. Les profils existants peuvent être sélectionnés, mais ne sont jamais requis.
5. **Paramétrage** : des contrôles +/− de 56 dp minimum plutôt qu'un curseur difficile à utiliser. Chaque contrôle a un libellé accessible.
6. **Partie en cours (étape 2)** : scores très grands, saisie en bas du téléphone, annulation visible, sauvegarde des lancers, confirmation avant abandon. Aucune publicité intrusive pendant un match.
7. **Interruption (étape 2)** : reprise automatique du match local, même après une fermeture ou un changement d'orientation. Gestion d'une migration des données.
8. **Fin de match (étape 2)** : victoire, moyennes, relancer, revanche, accueil. Aucune suppression automatique de l'historique.
9. **Entraînement (étape ultérieure)** : un exercice > consigne > saisie > résultat > recommencer, sans détour par un tableau de bord.
10. **Accessibilité** : tailles de cibles tactiles ≥48dp, contrastes, focus TalkBack, grandes commandes; vérifier effectivement sur Android.

## Ergonomie responsive

- Fenêtre **< 600dp de large** : 4 onglets dans une barre en bas; contenu en colonne; header global.
- Fenêtre **≥ 600dp de large** : navigation latérale; contenu plus large et défilant; header global.
- En paysage bas, vérifier la place pour le contenu avec clavier ouvert et bordures système.
- Cette V0.3 adapte la navigation et la taille des contenus, pas encore le plateau de score (non développé).

## Liste des fonctionnalités du parcours déjà fonctionnelles

- La navigation entre les rubriques, la première action « Partie rapide », le choix du mode et l'affichage du brouillon sont connectés au vrai code.
- Le nombre de manches gagnantes et le choix des participants modifient un objet de brouillon `SessionDraft` conservé en mémoire et restauré à la rotation.
- Les profils locaux sont facultatifs, persistés dans SharedPreferences et ne peuvent plus partager exactement le même nom (insensible à la casse).
- Les fiches de règles restent des descriptions initiales, non encore un moteur certifié.

## Ce qui n'est PAS développé et ne doit pas être présenté comme tel

- Match 501/301/Cricket jouable, score, bust, checkout, suivi des stats, historique des parties, reprise après fermeture complète.
- Sélection de plus de deux participants et tournoi; synchronisation; facturation; audio.
- Capture d'écran réelle, compilation APK Android, test manuel sur appareil.

## Critères d'acceptation de l'expérience finale

- Un nouvel utilisateur peut démarrer une partie 501 en deux actions depuis l'accueil, une fois le moteur intégré.
- Aucune création de compte, aucune publicité ou paramètre obligatoire pour jouer.
- Les fonctions de match restent utilisables à une main sur téléphone compact; le clavier ne masque jamais l'action principale.
- Orientation/rotation/fond/retour ne font perdre ni score ni configuration.
- Accessibilité sur les tailles de texte 1× et 1,3×, TalkBack, téléphone compact et tablette.
- Les mêmes composants et libellés restent cohérents dans toutes les applications basées sur SportCore.
