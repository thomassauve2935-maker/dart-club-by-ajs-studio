# Scénarios à faire sur un vrai appareil

Ces scénarios sont une checklist de validation UX **à exécuter dans Android Studio ou sur téléphone/tablette**. Ils ne sont pas annoncés comme passés.

| ID | Action | Résultat attendu |
|---|---|---|
| UX-01 | Premier lancement sans profil | Accueil visible et bouton « Préparer une partie » accessible |
| UX-02 | Partie rapide | Préparation du mode par défaut `x01_501`, invités 1 et 2, une manche gagnante |
| UX-03 | Choisir Cricket depuis Jouer | Préparation affiche le mode Cricket |
| UX-04 | Dans la préparation, changer le nombre de manches | Les touches +/− règlent la valeur de 1 à 15 sans dépassement |
| UX-05 | Créer un profil puis revenir en préparation | Le profil figure dans les listes de participants |
| UX-06 | Créer deux profils de même nom (casse différente) | Deuxième création refusée avec message lisible |
| UX-07 | Changer orientation dans la préparation | Mode, invités, profils sélectionnés et nombre de manches conservés |
| UX-08 | Ouvrir puis quitter Réglages | Retour sur la page antérieure |
| UX-09 | Appuyer Retour depuis la préparation | Retour au catalogue des modes |
| UX-10 | Téléphone compact 360dp et grand texte | Pas de commande hors écran, page défilable |
| UX-11 | Tablette 800dp | Navigation à gauche, contenu à droite |
| UX-12 | Android gestes/barre 3 boutons | Contrôles non recouverts par les barres système |
| UX-13 | TalkBack | Tous les contrôles sont nommés et activables |
| UX-14 | Tout lancer depuis l'accueil | Le produit n'annonce pas qu'un moteur de score non livré fonctionne |

**Critère de sortie :** compilation réelle `assembleDebug`, zéro crash sur ces scénarios, puis tests d'accessibilité Android. Les moteurs de jeu restent hors de la V0.3.
