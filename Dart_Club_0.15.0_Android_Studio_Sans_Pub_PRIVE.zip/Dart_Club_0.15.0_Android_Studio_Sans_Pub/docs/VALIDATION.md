# Validation technique Darts Club V0.4 Alpha

Date : 2 novembre 2026.

## Vérifications exécutées

- 15 modes répertoriés **sans catégories de navigation**, identifiants uniques.
- Parsing syntaxique des 29 fichiers `.java` avec l'API `JavacTask.parse()` : **OK**.
- Compilation Java pure de `sportcore-model` et `sport-darts` au JDK disponible : **OK**.
- `DartsEngineTest` : X01 180, switch automatique, undo de troisième fléchette après switch, double-out, checkout, bust, Cricket, progression individuelle Around, Bob's 27, Survivant, et smoke trois lancers / undo pour chacun des 15 modes : **OK**.
- `SmokeTest` / `JourneySmokeTest` : modèles, catalogue, valeurs par défaut et contraintes du brouillon : **OK**.
- `scripts/check_architecture.py` : six modules, dépendances fonctionnelles et restrictions d'import : **OK**.
- XML parsés (manifest, styles, couleurs, icône) : **OK**.

## Ce que ces vérifications ne prouvent pas

Aucun Android SDK, plugin Gradle ou émulateur exécutable n'était disponible dans l'environnement. Il n'y a donc **aucune APK compilée**, aucun résultat d'installation, aucun test tactile ni capture réelle. Les fichiers Android peuvent encore contenir des problèmes de liaison de ressources, de compatibilité ou d'ergonomie que seul un build + essai sur appareil permet d'identifier.

## Tests nécessaires avec Android Studio

1. Sur Windows, ouvrir PowerShell et lancer `setup-wrapper.ps1` dans le projet ; ouvrir dans Android Studio avec JDK17 et SDK35 ; synchroniser Gradle 8.9, AGP 8.7.3.
2. Compiler `:app:assembleDebug` et installer l'APK sur un appareil Android 8+.
3. Au lancement, vérifier l'affichage direct des 15 modes sur **une seule grille**, puis l'onglet Profils. Aucun accueil distinct.
4. Lancer 501 avec les deux invités ; saisir T20/T20/T20 ; vérifier 321 points, passage automatique à l'adversaire et touche Annuler.
5. Saisir une finition sur double et un bust. Faire Annuler depuis l'écran de résultat.
6. Mettre en pause / fermer l'application / la relancer et reprendre la partie.
7. Créer un profil, l'utiliser, finir une partie, consulter la moyenne, les victoires et la carte de chaleur.
8. Tester le Cricket (affichage des marques 15 à bull), les 15 variantes, le mode solo et la progression individuelle Around.
9. Vérifier police Android grande taille, TalkBack, zone tactile, clavier, tablette paysage, contraste et batteries OLED.
10. Vérifier licences et remplacement de la cible provisoire par le SVG tiers.

**Interdiction de déclarer la version « terminée » ou « conforme aux compétitions » avant ces contrôles.**
