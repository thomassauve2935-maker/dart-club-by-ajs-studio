# Validation V0.14 — 16 novembre 2026

Version `0.14.0-languages-test`, code 15, package `fr.dartsclub.app`, minSdk 26 / targetSdk 35.

## Vérifications

- 49 tests JUnit/Robolectric : 24 parcours existants, 10 tests de localisation, 9 tests d’expérience/sauvegarde et 6 suites de régression.
- Suites historiques conservées : 120 parties terminées pour 15 jeux et 1 à 8 joueurs ; 12 582 lancers de stress.
- Contrôle de 278 entrées dans les trois langues, mêmes clés, variantes singulier/pluriel et paramètres de formatage.
- Sélecteur de langue réellement utilisé : français → anglais → espagnol → langue du téléphone, avec persistance après recréation.
- Variantes régionales et langues secondaires prises en charge ; repli en français lorsque le téléphone ne propose aucune des trois langues.
- Journaux de lancers identiques avant et après un changement de langue. Nom de profil volontairement identique à « Invité 1 » conservé ; seuls les vrais invités automatiques changent de libellé à l’affichage.
- Parcours complets en anglais et espagnol : catalogue, préparation, règles, lancer, résultat sauvegardé, partage PNG, statistiques et erreur de nom invalide.
- Moyennes et pluriels vérifiés. Descriptions d’accessibilité de la cible incluant double/triple traduites.
- États des quinze jeux localisés et codes de message pour bust et nouveau leg.
- Choix de langue et match complet sous Android 8.0 ; rendu natif sous Android 35.
- Écran 360×640, texte à 130 %, grandes commandes, 8 joueurs et 15 legs : bouton de départ entièrement visible en espagnol.
- Sauvegarde incluant la langue, restauration et acceptation des fichiers V0.13 dépourvus de ce champ.
- Android Lint sans erreur ni avertissement ; architecture et composants vérifiés.
- APK signée avec le certificat des V0.9–V0.13 : SHA-256 du certificat `f722b4ae71683723196f87ccda992e577f64904c616b9f4c7b960d5eb252bd06`.
- Publicités désactivées ; aucun identifiant AdMob de démonstration ni initialisation automatique dans le manifeste fusionné.

## Limites

Les captures utilisent Robolectric et les vraies ressources Android. Aucun essai de cette version sur téléphone physique n’a été effectué ici. Installer la V0.14 par-dessus la V0.13, sans désinstallation, puis vérifier le sélecteur de langue sur le Pixel 8 Pro.

Les règles exécutées, identifiants de modes, profils et statistiques n’ont pas été traduits ou migrés ; seuls les textes affichés changent. Les annotations françaises internes du moteur ne sont pas exposées dans l’interface traduite.

Les sources et les clés restent privées.
