# Validation V0.10 — 14 novembre 2026

`testDebugUnitTest`, `assembleDebug` et `lintDebug` terminent avec **BUILD SUCCESSFUL**. JDK 17, Gradle 8.9, AGP 8.7.3, SDK 35.

- 20 tests JUnit réussis, sans échec : 14 parcours Android et 6 suites du moteur et du socle.
- Rapport Android Lint : 0 erreur et 0 avertissement.
- 120 parties terminées, annulées et rejouées, couvrant les 15 modes avec 1 à 8 joueurs ; test de robustesse de 12 582 lancers.
- `LocalDartsStatsTest` réussit séparément : historique ancien, 62 zones, doubles et triples indépendants, profils et sauvegarde/annulation.
- Contrôles statiques de l'architecture et des composants UI réussis.
- Signature APK v2 vérifiée ; certificat identique à celui de la V0.9 publiée, package inchangé et versionCode augmenté à 11.

Les nouveaux tests vérifient que la carte vedette ouvre bien le 501, que les quinze jeux sont présents et que la suppression d'un profil peut être annulée puis confirmée. Le renommage et les captures passent désormais par le menu du profil. Les autres parcours existants sont conservés : résultat et annulation, reprise, formulaire, rotation, grandes commandes, tablette, préparation compacte et compatibilité API 26.

Onze captures des vues Android réelles sont fournies dans `design/rendus-android/`. Elles ont été examinées avec le rendu graphique natif de Robolectric : catalogue, profils vides, réglages, profil, éditeur, préparation, match, résultat, tablette, préparation compacte et cible avec fréquences distinctes de doubles/triples. À 390 × 844, le match et sa dernière action sont visibles ; le profil avec impacts affiche sa légende complète. À 800 × 600, toutes les touches de score et l'annulation sont visibles. À 360 × 640, Commencer reste accessible.

Le décor du catalogue utilise les mêmes tracés SVG et Android. Le symbole d'origine est conservé. Les quatre maquettes V0.10 dans Figma contiennent du texte éditable, des instances et des vecteurs, sans image aplatie de l'interface. Les maquettes et les captures sont identifiées séparément.

L'APK est une version de test signée pour le développement. Aucun essai sur téléphone physique n'a été effectué. Le réseau publicitaire est isolé dans les tests Android ; la fréquence est testée dans le socle. Le journal de Lint émet des diagnostics de lecture des métadonnées Kotlin de la dépendance AdMob par AGP 8.7.3 ; le rapport final et les tâches Gradle terminent sans anomalie du code de l'application.

Les sources, caches, paramètres locaux et clés ne sont pas publiés dans le dépôt public. Cette archive des sources exclut les caches, sorties de compilation, clés et `local.properties`.
