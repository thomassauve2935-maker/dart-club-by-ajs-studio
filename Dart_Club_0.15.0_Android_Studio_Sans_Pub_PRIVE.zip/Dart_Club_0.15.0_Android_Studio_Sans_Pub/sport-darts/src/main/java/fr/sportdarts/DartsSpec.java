package fr.sportdarts;
import fr.sportcore.model.*;
import java.util.*;
import fr.sportdarts.engine.DartSession;
/** One flat catalogue: games, practice and custom creations have identical navigation. */
public final class DartsSpec implements SportSpec {
 @Override public String appName(){return "Dart Club";}
 @Override public String appSignature(){return "By AJS Studio";}
 @Override public String headline(){return "Choisis ton jeu";}
 @Override public String welcomeText(){return "15 modes · sans compte obligatoire";}
 @Override public List<ModeSpec> games(){return Collections.unmodifiableList(Arrays.asList(
  new ModeSpec("x01_501","501","Le classique","501 points. Départ libre, sortie double, trois fléchettes maximum par volée. Bust : la volée entière est annulée."),
  new ModeSpec("x01_301","301","Rapide et précis","301 points. Finir sur un double, mêmes règles de bust que le 501."),
  new ModeSpec("x01_701","701","Le défi longue durée","701 points. Départ libre et sortie double."),
  new ModeSpec("cricket","Cricket","Fermer les secteurs","Fermer 15 à 20 et bull en trois marques. Marquer sur un secteur fermé tant que l'adversaire ne l'a pas fermé."),
  new ModeSpec("around","Around the World","Le tour de cible","Toucher 1 à 20 dans l'ordre, puis le bull. Chaque fléchette juste fait avancer d'un objectif."),
  new ModeSpec("shanghai","Shanghai","Précision par manche","7 manches, cibles 1 à 7. Points uniquement sur le numéro imposé. Simple + double + triple dans une même volée gagnent immédiatement."),
  new ModeSpec("killer","Killer","Élimination","Variante Dart Club : 1 à 8 joueurs, 3 vies chacun. Chaque adversaire possède un numéro à attaquer en double."),
  new ModeSpec("pro_training","Pro Training","Régularité sur le 20","10 volées pour cumuler des marques sur le secteur 20 : simple 1, double 2, triple 3."),
  new ModeSpec("checkout","Training Checkout","Finitions","Départ à 40, finir exactement à zéro sur un double. Une version de travail simple du checkout."),
  new ModeSpec("bobs27","Bob's 27","Maîtriser les doubles","Départ à 27, tenter D1 à D20. Chaque double réussi ajoute 2× sa valeur ; aucun double pendant la volée retire 2× sa valeur."),
  new ModeSpec("survivor","Survivant","Trois vies","Variante Dart Club : toucher le secteur indiqué dans ses trois fléchettes, sinon perdre une vie."),
  new ModeSpec("jackpot","Jackpot","Gagner le bonus","Variante Dart Club : pendant 10 tours, le secteur affiché rapporte deux fois sa valeur."),
  new ModeSpec("double_nothing","Double ou Rien","Tout sur un double","Variante Dart Club : les points de la volée ne comptent que si elle contient au moins un double. Premier à 301."),
  new ModeSpec("contract","Le Contrat","Défis progressifs","Variante Dart Club : contrats de 40, 50, 60... points par volée, 3 échecs maximum. Solo ou plusieurs joueurs."),
  new ModeSpec("king","Roi de la cible","Secteur imposé","Variante Dart Club : chaque tour impose un secteur. Simple 1, double 2, triple 3. Meilleur total après 10 tours.")
  ));}
 @Override public boolean solo(String modeId){return DartSession.isSolo(modeId);}
}
