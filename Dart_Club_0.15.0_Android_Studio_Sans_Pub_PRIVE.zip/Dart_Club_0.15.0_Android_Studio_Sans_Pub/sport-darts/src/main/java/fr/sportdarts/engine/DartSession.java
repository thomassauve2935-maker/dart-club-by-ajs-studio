package fr.sportdarts.engine;
import java.util.*;
/** Moteur événementiel 1..8 joueurs : un lancer = un événement ; Annuler reconstruit l'état exact. */
public final class DartSession {
 public enum Notice { NONE,MATCH_COMPLETE,CHALLENGE_COMPLETE,LEG_WON,BUST }
 private Notice notice=Notice.NONE;
 public Notice lastNotice(){return notice;}
 public final String mode;
 public final String[] names;
 public final int legsToWin;
 private final List<DartThrow> events=new ArrayList<>();
 private final List<Integer> eventPlayers=new ArrayList<>();
 private final List<DartThrow> currentTurn=new ArrayList<>();
 private final List<DartThrow> lastTurn=new ArrayList<>();
 private int lastTurnPlayer=-1;
 private final int[] validPoints,checkouts,aroundProgress,fails;
 private final boolean[] targetHit,shanghai;
 public final int[] score,legs,lives;
 private final int[][] marks;
 public int active=0,turnDarts=0,turnTotal=0,turnStart=0,round=0;
 public boolean finished=false,bust=false;
 public int winner=-1;
 private int startPlayer=0;
 private final List<String> notes=new ArrayList<>();
 private final int[] killerSectors={15,16,17,18,19,20,14,13};
 public DartSession(String mode,String p1,String p2,int legsToWin){this(mode,new String[]{p1,p2},legsToWin);}
 public DartSession(String mode,String[] players,int legsToWin){
  if(players==null||players.length<1||players.length>8)throw new IllegalArgumentException("De 1 à 8 joueurs requis");
  for(String p:players)if(p==null||p.trim().isEmpty())throw new IllegalArgumentException("Nom de joueur manquant");
  this.mode=Objects.requireNonNull(mode);this.names=Arrays.copyOf(players,players.length);
  this.legsToWin=Math.max(1,Math.min(15,legsToWin));
  int n=names.length;score=new int[n];legs=new int[n];lives=new int[n];
  validPoints=new int[n];checkouts=new int[n];aroundProgress=new int[n];
  fails=new int[n];targetHit=new boolean[n];shanghai=new boolean[3];marks=new int[n][7];
  reset();
 }
 public static boolean isX01(String mode){return mode.equals("x01_301")||mode.equals("x01_501")||mode.equals("x01_701")||mode.equals("checkout");}
 /** Utilisé uniquement pour suggérer 1 joueur par défaut, sans interdire le multijoueur. */
 public static boolean isSolo(String mode){return mode.equals("pro_training")||mode.equals("checkout")||mode.equals("bobs27")||mode.equals("contract");}
 public int playerCount(){return names.length;}
 public int dartsThrown(){return events.size();}
 public int eventPlayer(int i){return eventPlayers.get(i);}
 public int validPoints(int p){return validPoints[p];}
 public int bestCheckout(int p){return checkouts[p];}
 public List<DartThrow> history(){return Collections.unmodifiableList(events);}
 public List<String> notes(){return Collections.unmodifiableList(notes);}
 public List<DartThrow> currentTurn(){return Collections.unmodifiableList(currentTurn);}
 public List<DartThrow> lastTurn(){return Collections.unmodifiableList(lastTurn);}
 public int lastTurnPlayer(){return lastTurnPlayer;}
 public int mark(int player,int field){return marks[player][field];}
 public int failures(int player){return fails[player];}
 public int progress(int p){return aroundProgress[p];}
 public int stage(){return mode.equals("around")?aroundProgress[active]:round+1;}
 public int killerSector(int p){return killerSectors[p];}
 public int roundTarget(){
  if(mode.equals("survivor")||mode.equals("jackpot")||mode.equals("king"))return 1+(round*7+16)%20;
  if(mode.equals("shanghai"))return 1+round;
  return round+1;
 }
 public String status(){
  if(finished)return winner<0?"Défi terminé ou égalité":"Victoire : "+names[winner];
  if(mode.equals("cricket"))return "Fermer 15–20 et le bull";
  if(mode.equals("around"))return "Objectif : "+(aroundProgress[active]>20?"BULL":aroundProgress[active]);
  if(mode.equals("bobs27"))return "Double "+(round+1);
  if(mode.equals("survivor"))return "Toucher "+roundTarget()+" · "+lives[active]+" vies";
  if(mode.equals("killer"))return playerCount()==1?"Viser D"+killerSector(0):"Viser les doubles adverses";
  if(mode.equals("jackpot"))return "Jackpot : "+roundTarget();
  if(mode.equals("king"))return "Roi : "+roundTarget();
  if(mode.equals("shanghai"))return "Manche "+(round+1)+" : secteur "+roundTarget();
  if(mode.equals("contract"))return "Contrat : "+(40+round*10)+" points";
  if(mode.equals("pro_training"))return "Cible : 20 · "+Math.max(0,10-round)+" tours restants";
  if(mode.equals("double_nothing"))return "Un double obligatoire par volée";
  return "Score restant";
 }
 private int initial(){switch(mode){case "x01_301":return 301;case "x01_701":return 701;case "checkout":return 40;default:return 501;}}
 private void reset(){
  eventPlayers.clear();currentTurn.clear();lastTurn.clear();lastTurnPlayer=-1;
  Arrays.fill(validPoints,0);Arrays.fill(checkouts,0);Arrays.fill(score,0);Arrays.fill(legs,0);
  Arrays.fill(lives,3);Arrays.fill(aroundProgress,1);Arrays.fill(fails,0);Arrays.fill(targetHit,false);
  Arrays.fill(shanghai,false);for(int[] row:marks)Arrays.fill(row,0);
  if(isX01(mode))Arrays.fill(score,initial());
  if(mode.equals("bobs27"))Arrays.fill(score,27);
  active=0;turnDarts=0;turnTotal=0;turnStart=score[0];round=0;startPlayer=0;
  finished=false;bust=false;winner=-1;notes.clear();notice=Notice.NONE;
 }
 /** Restauration linéaire du journal ; aucun lancer après la fin du match. */
 public static DartSession restore(String mode,String[] names,int legs,List<DartThrow> history){
  DartSession s=new DartSession(mode,names,legs);
  for(DartThrow dart:history){
   if(s.finished)throw new IllegalArgumentException("Lancer après la fin du match");
   s.events.add(dart);s.eventPlayers.add(s.active);s.apply(dart);
  }
  return s;
 }
 public boolean throwDart(DartThrow dart){if(finished)return false;events.add(dart);replay();return true;}
 public boolean undo(){if(events.isEmpty())return false;events.remove(events.size()-1);replay();return true;}
 private void replay(){List<DartThrow> copy=new ArrayList<>(events);reset();for(DartThrow d:copy){eventPlayers.add(active);apply(d);}}
 private void finish(int p){finished=true;winner=p;notice=p>=0?Notice.MATCH_COMPLETE:Notice.CHALLENGE_COMPLETE;notes.add(p>=0?"Partie terminée":"Défi terminé");}
 private int highestScore(){
  int best=Integer.MIN_VALUE,leader=-1;boolean tied=false;
  for(int i=0;i<playerCount();i++){
   if(score[i]>best){best=score[i];leader=i;tied=false;}
   else if(score[i]==best)tied=true;
  }
  return tied?-1:leader;
 }
 private int lastStanding(){
  int survivor=-1;
  for(int i=0;i<playerCount();i++)if(isAlive(i)){
   if(survivor>=0)return -2;
   survivor=i;
  }
  return playerCount()==1&&survivor==0?-2:survivor;
 }
 private void saveCompletedTurn(){lastTurn.clear();lastTurn.addAll(currentTurn);lastTurnPlayer=active;currentTurn.clear();}
 private void legWon(){
  saveCompletedTurn();legs[active]++;
  if(legs[active]>=legsToWin){finish(active);return;}
  startPlayer=(startPlayer+1)%playerCount();
  Arrays.fill(score,initial());active=startPlayer;turnStart=score[active];turnDarts=0;turnTotal=0;round=0;
  notice=Notice.LEG_WON;notes.add("Leg gagné · nouveau leg");
 }
 private void next(){
  saveCompletedTurn();int previous=active;
  int candidate=active;
  for(int i=0;i<playerCount();i++){
   candidate=(candidate+1)%playerCount();
   if(!isEliminationMode()||isAlive(candidate))break;
  }
  if(candidate<=previous)round++;
  active=candidate;turnDarts=0;turnTotal=0;bust=false;turnStart=score[active];
  Arrays.fill(targetHit,false);Arrays.fill(shanghai,false);
 }
 private boolean isEliminationMode(){return mode.equals("survivor")||mode.equals("killer")||mode.equals("bobs27")||mode.equals("contract");}
 private boolean isAlive(int p){
  if(mode.equals("bobs27"))return score[p]>0;
  if(mode.equals("contract"))return fails[p]<3;
  return lives[p]>0;
 }
 private void concludeRounds(int total){if(round>=total)finish(highestScore());}
 private boolean allCricketClosed(int p){for(int x:marks[p])if(x<3)return false;return true;}
 private boolean cricketLeader(int p){for(int i=0;i<playerCount();i++)if(i!=p&&score[i]>score[p])return false;return true;}
 private void apply(DartThrow d){
  if(finished)return;
  notes.clear();notice=Notice.NONE;bust=false;currentTurn.add(d);turnDarts++;turnTotal+=d.points();
  if(isX01(mode)){
   int remainder=score[active]-d.points();
   if(remainder<0||remainder==1||(remainder==0&&!d.doubleOut())){
    score[active]=turnStart;notice=Notice.BUST;notes.add("BUST · volée annulée");bust=true;next();return;
   }
   score[active]=remainder;
   if(remainder==0){validPoints[active]+=turnTotal;checkouts[active]=Math.max(checkouts[active],turnStart);legWon();return;}
   if(turnDarts==3){validPoints[active]+=turnTotal;next();}
   return;
  }
  if(mode.equals("cricket")){
   int idx=d.segment==25?6:d.segment-15;
   if(idx>=0&&idx<=6){
    int old=marks[active][idx],added=d.multiplier;
    marks[active][idx]=Math.min(3,old+added);
    int extra=Math.max(0,old+added-3);
    boolean opponentOpen=false;
    for(int p=0;p<playerCount();p++)if(p!=active&&marks[p][idx]<3)opponentOpen=true;
    if(opponentOpen)score[active]+=extra*d.segment;
   }
   if(allCricketClosed(active)&&cricketLeader(active)){saveCompletedTurn();finish(active);return;}
  } else if(mode.equals("around")){
   if((aroundProgress[active]<=20&&d.segment==aroundProgress[active])
      ||(aroundProgress[active]==21&&d.segment==25))aroundProgress[active]++;
   if(aroundProgress[active]>=22){saveCompletedTurn();finish(active);return;}
  } else if(mode.equals("bobs27")){
   if(d.segment==round+1&&d.multiplier==2){score[active]+=2*(round+1);targetHit[active]=true;}
  } else if(mode.equals("shanghai")){
   if(d.segment==roundTarget()){
    score[active]+=d.points();shanghai[d.multiplier-1]=true;
    if(shanghai[0]&&shanghai[1]&&shanghai[2]){saveCompletedTurn();finish(active);return;}
   }
  } else if(mode.equals("pro_training")){
   if(d.segment==20)score[active]+=d.multiplier;
  } else if(mode.equals("survivor")){
   if(d.segment==roundTarget())targetHit[active]=true;
  } else if(mode.equals("jackpot")){
   score[active]+=d.points()*(d.segment==roundTarget()?2:1);
  } else if(mode.equals("double_nothing")){
   if(d.multiplier==2&&d.segment!=0)targetHit[active]=true;
  } else if(mode.equals("king")){
   if(d.segment==roundTarget())score[active]+=d.multiplier;
  } else if(mode.equals("killer")){
   if(d.multiplier==2&&playerCount()==1&&d.segment==killerSector(0))score[0]++;
   else if(d.multiplier==2){
    for(int i=0;i<playerCount();i++)if(i!=active&&lives[i]>0&&d.segment==killerSector(i)){
     lives[i]--;int survivor=lastStanding();
     if(survivor>=0){saveCompletedTurn();finish(survivor);return;}
    }
   }
  }
  if(turnDarts<3)return;
  if(mode.equals("bobs27")&&!targetHit[active]){
   score[active]-=2*(round+1);
   if(score[active]<=0){int survivor=lastStanding();if(survivor!=-2){saveCompletedTurn();finish(survivor);return;}}
  }
  if(mode.equals("double_nothing")&&targetHit[active]){
   score[active]+=turnTotal;if(score[active]>=301){saveCompletedTurn();finish(active);return;}
  }
  if(mode.equals("contract")){
   if(turnTotal>=40+round*10)score[active]++;else{
    fails[active]++;
    if(fails[active]>=3){int survivor=lastStanding();if(survivor!=-2){saveCompletedTurn();finish(survivor);return;}}
   }
  }
  if(mode.equals("survivor")&&!targetHit[active]){
   lives[active]--;
   int survivor=lastStanding();
   if(survivor!=-2){saveCompletedTurn();finish(survivor);return;}
  }
  next();
  if(mode.equals("bobs27")&&round>=20)finish(highestScore());
  if(mode.equals("shanghai"))concludeRounds(7);
  if(mode.equals("pro_training")||mode.equals("jackpot")||mode.equals("king")||mode.equals("contract"))concludeRounds(10);
  if(mode.equals("killer")&&playerCount()==1)concludeRounds(10);
  if(mode.equals("survivor")&&round>=20){
   int best=-1,leader=-1;boolean tie=false;
   for(int i=0;i<playerCount();i++){
    if(lives[i]>best){best=lives[i];leader=i;tie=false;}else if(lives[i]==best)tie=true;
   }
   finish(tie?-1:leader);
  }
 }
}
