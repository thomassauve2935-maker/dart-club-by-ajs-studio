package fr.sportdarts.engine;
/** One actual dart hit. 0=miss; 1..20 singles/doubles/triples; 25 outer bull/bull. */
public final class DartThrow {
 public final int segment,multiplier;
 public DartThrow(int segment,int multiplier){
  if(segment==0){if(multiplier!=1)throw new IllegalArgumentException("Miss must have multiplier 1");}
  else if(segment==25){if(multiplier!=1&&multiplier!=2)throw new IllegalArgumentException("Bull multiplier is 1 or 2");}
  else if(segment<1||segment>20||multiplier<1||multiplier>3)throw new IllegalArgumentException("Invalid dart");
  this.segment=segment;this.multiplier=multiplier;
 }
 public int points(){return segment*multiplier;}
 public boolean doubleOut(){return multiplier==2 && segment!=0;}
 public String label(){return segment==0?"OUT":segment==25?(multiplier==2?"BULL":"25"):(multiplier==3?"T":multiplier==2?"D":"")+segment;}
}
