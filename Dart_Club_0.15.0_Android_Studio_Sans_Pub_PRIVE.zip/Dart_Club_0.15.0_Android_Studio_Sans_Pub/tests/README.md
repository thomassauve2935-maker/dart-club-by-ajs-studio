Tests indépendants du SDK Android (JDK 17+) :

```bash
mkdir -p /tmp/sportcore-classes
javac -encoding UTF-8 -d /tmp/sportcore-classes $(find sportcore-model/src/main/java sport-darts/src/main/java -name '*.java') tests/SmokeTest.java
java -cp /tmp/sportcore-classes SmokeTest
```

Ces tests **ne garantissent pas** une compilation Android. Voir `docs/VALIDATION.md` pour le plan de tests instrumentés.
