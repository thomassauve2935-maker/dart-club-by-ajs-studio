import fr.sportdarts.DartsSpec;
import fr.sportdarts.engine.*;
import java.util.*;
/** Scénarios déterministes de robustesse : tous les modes, toutes les tailles d'équipe. */
public final class MultiplayerStressTest {
 private static void check(boolean x,String what){if(!x)throw new AssertionError(what);}
 public static void main(String[] args){
  Random random=new Random(20261103L);int turns=0;
  for(var m:new DartsSpec().games())for(int n=1;n<=8;n++){
   String[] names=new String[n];for(int p=0;p<n;p++)names[p]="J"+(p+1);
   DartSession s=new DartSession(m.id,names,1);
   for(int j=0;j<150&&!s.finished;j++){
    int seg=random.nextInt(23);if(seg==21||seg==22)seg=25;
    int mult=seg==0?1:seg==25?1+random.nextInt(2):1+random.nextInt(3);
    DartThrow d=new DartThrow(seg,mult);
    s.throwDart(d);turns++;
    check(s.active>=0&&s.active<n,"active "+m.id+" "+n);
    check(s.currentTurn().size()<=3&&s.lastTurn().size()<=3,"turns "+m.id);
    check(s.eventPlayer(s.dartsThrown()-1)>=0&&s.eventPlayer(s.dartsThrown()-1)<n,"events");
    if(j%17==0){
     int before=s.dartsThrown();check(s.undo(),"Undo");check(s.dartsThrown()==before-1,"undo len");
     check(s.throwDart(d)&&s.dartsThrown()==before,"redo same dart");
    }
   }
  }
  System.out.println("MultiplayerStressTest OK : "+turns+" lancers sur 15 modes × 1 à 8 joueurs");
 }
}
