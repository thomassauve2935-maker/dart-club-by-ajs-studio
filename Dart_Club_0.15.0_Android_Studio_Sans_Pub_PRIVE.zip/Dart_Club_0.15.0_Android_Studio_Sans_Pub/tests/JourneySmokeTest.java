import fr.sportdarts.DartsSpec;
import fr.sportcore.model.*;
public class JourneySmokeTest {
 public static void main(String[] args){
  SportSpec spec=new DartsSpec();SessionDraft d=new SessionDraft(spec.games().get(0).id);
  if(!d.modeId.equals("x01_501"))throw new AssertionError("mode par défaut");
  if(d.playerCount()!=2||!d.hasValidPlayers())throw new AssertionError("deux invités par défaut");
  for(int n=1;n<=8;n++){
   d.setPlayerCount(n);
   if(!d.hasValidPlayers()||d.names().length!=n)throw new AssertionError("Invités "+n);
  }
  try{d.setPlayerCount(0);throw new AssertionError("0 joueurs accepté");}
  catch(IllegalArgumentException expected){}
  try{d.setPlayerCount(9);throw new AssertionError("9 joueurs accepté");}
  catch(IllegalArgumentException expected){}
  d.setPlayerCount(3);d.setPlayer(0,"Alice","id-alice");d.setPlayer(1,"Bob","id-bob");
  d.setPlayer(2,"Alice","id-alice");if(d.hasValidPlayers())throw new AssertionError("Profil en double accepté");
  d.setPlayer(2,"Invité 3","");if(!d.hasValidPlayers())throw new AssertionError("invité mélangé aux profils");
  d.setLegsToWin(15);
  try{d.setLegsToWin(16);throw new AssertionError("Limite haute absente");}
  catch(IllegalArgumentException expected){}
  try{d.setLegsToWin(0);throw new AssertionError("Limite basse absente");}
  catch(IllegalArgumentException expected){}
  d.setPlayer(0,"","id-alice");if(d.hasValidPlayers())throw new AssertionError("Nom vide accepté");
  System.out.println("JourneySmokeTest OK : choix 1..8, invités, profils uniques, legs");
 }
}
