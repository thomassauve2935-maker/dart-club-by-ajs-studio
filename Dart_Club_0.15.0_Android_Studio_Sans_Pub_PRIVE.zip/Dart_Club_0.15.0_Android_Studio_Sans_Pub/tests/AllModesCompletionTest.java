import fr.sportdarts.DartsSpec;
import fr.sportdarts.engine.*;
import java.util.Arrays;

/** Termine réellement les quinze jeux, puis annule et rejoue le lancer décisif. */
public final class AllModesCompletionTest {
 private static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
 private static DartThrow next(DartSession g){
  int p=g.active;
  if(DartSession.isX01(g.mode)){
   int remaining=g.score[p];
   if(remaining==50)return new DartThrow(25,2);
   if(remaining<=40)return remaining%2==0?new DartThrow(remaining/2,2):new DartThrow(1,1);
   return remaining>=62?new DartThrow(20,3):new DartThrow(20,1);
  }
  switch(g.mode){
   case "cricket":
    for(int sector=15;sector<=20;sector++)if(g.mark(p,sector-15)<3)return new DartThrow(sector,3);
    return new DartThrow(25,g.mark(p,6)==0?2:1);
   case "around":return new DartThrow(g.progress(p)<=20?g.progress(p):25,1);
   case "shanghai":return new DartThrow(g.roundTarget(),g.turnDarts+1);
   case "bobs27":return new DartThrow(g.stage(),2);
   case "pro_training":return new DartThrow(20,3);
   case "killer":
    if(g.playerCount()==1)return new DartThrow(g.killerSector(0),2);
    for(int i=0;i<g.playerCount();i++)if(i!=p&&g.lives[i]>0)return new DartThrow(g.killerSector(i),2);
    throw new AssertionError("Aucun adversaire vivant");
   case "jackpot":case "king":return new DartThrow(g.roundTarget(),3);
   case "double_nothing":return new DartThrow(20,2);
   default:return new DartThrow(0,1);
  }
 }
 public static void main(String[] args){
  int checks=0;
  for(var mode:new DartsSpec().games())for(int players=1;players<=8;players++){
   String[] names=new String[players];for(int i=0;i<players;i++)names[i]="Joueur "+(i+1);
   DartSession game=new DartSession(mode.id,names,1);
   int attempts=0;while(!game.finished&&attempts++<1500)check(game.throwDart(next(game)),"Lancer accepté");
   String context=mode.id+" / "+players+" joueur(s)";
   check(game.finished,"Le jeu doit pouvoir se terminer : "+context);
   int darts=game.dartsThrown(),winner=game.winner;int[] score=game.score.clone(),legs=game.legs.clone();
   DartThrow decisive=game.history().get(darts-1);
   check(game.undo()&&!game.finished&&game.dartsThrown()==darts-1,"Annuler rouvre le résultat : "+context);
   check(game.throwDart(decisive)&&game.finished&&game.winner==winner,"Le résultat se reconstruit : "+context);
   check(Arrays.equals(score,game.score)&&Arrays.equals(legs,game.legs),"Scores et legs identiques : "+context);
   checks++;
  }
  System.out.println("AllModesCompletionTest OK : "+checks+" parties terminées et rejouées (15 modes × 1..8 joueurs)");
 }
}
