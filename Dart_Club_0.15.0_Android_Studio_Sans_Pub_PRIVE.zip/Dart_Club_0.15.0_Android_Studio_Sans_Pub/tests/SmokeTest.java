import fr.sportdarts.DartsSpec;
import fr.sportcore.model.*;
import java.util.List;
public class SmokeTest {
 public static void main(String[] args){
  SportSpec s=new DartsSpec();
  if(!s.appName().equals("Dart Club")||!s.appSignature().equals("By AJS Studio"))throw new AssertionError("Nom sport");
  if(s.games().size()!=15)throw new AssertionError("Catalogue unique 15 modes");
  if(!s.games().get(0).id.equals("x01_501"))throw new AssertionError("Mode 501");
  if(!new Profile("id"," Jules ").name.equals("Jules"))throw new AssertionError("Normalisation profil");
  if(new Profile("id"," Alice ").id.isBlank())throw new AssertionError("Identifiant");
  try {new Profile(" ","Bob");throw new AssertionError("Identifiant vide accepté");}
  catch(IllegalArgumentException expected){}
  System.out.println("SmokeTest OK : modèles et catalogue (Java sans Android)");
 }
}
