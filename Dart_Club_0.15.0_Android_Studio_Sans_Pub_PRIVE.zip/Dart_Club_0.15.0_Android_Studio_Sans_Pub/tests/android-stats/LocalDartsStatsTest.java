package fr.dartsclub.app;

import android.content.SharedPreferences;
import fr.sportdarts.engine.DartSession;
import fr.sportdarts.engine.DartThrow;
import java.lang.reflect.Proxy;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

/** Tests du vrai lecteur/écrivain JSON avec des préférences en mémoire, sans appareil Android. */
public final class LocalDartsStatsTest {
 private static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
 private static JSONObject event(int player,int segment,int multiplier){
  return new JSONObject().put("player",player).put("segment",segment).put("multiplier",multiplier);
 }
 private static JSONObject match(String... ids){
  return new JSONObject().put("ids",new JSONArray(ids)).put("events",new JSONArray());
 }
 private static final class MemoryPrefs {
  final Map<String,String> values=new HashMap<>();
  int commits;
  final SharedPreferences prefs=(SharedPreferences)Proxy.newProxyInstance(
      SharedPreferences.class.getClassLoader(),new Class<?>[]{SharedPreferences.class},
      (proxy,method,args)->{
       if(method.getName().equals("getString"))return values.getOrDefault((String)args[0],(String)args[1]);
       if(method.getName().equals("edit"))return editor();
       throw new UnsupportedOperationException(method.getName());
      });
  private SharedPreferences.Editor editor(){
   Map<String,String> pending=new HashMap<>();
   return (SharedPreferences.Editor)Proxy.newProxyInstance(
       SharedPreferences.Editor.class.getClassLoader(),new Class<?>[]{SharedPreferences.Editor.class},
       (proxy,method,args)->{
        if(method.getName().equals("putString")){pending.put((String)args[0],(String)args[1]);return proxy;}
        if(method.getName().equals("commit")){values.putAll(pending);commits++;return true;}
        throw new UnsupportedOperationException(method.getName());
       });
  }
  void seed(JSONObject... matches){values.put("matches",new JSONArray(matches).toString());}
 }
 private static void existingHistoryDistinguishesRings(){
  MemoryPrefs memory=new MemoryPrefs();
  JSONObject game=match("alice","bob").put("x01",true).put("winner",0)
      .put("points",new JSONArray(new int[]{355,60})).put("darts",new JSONArray(new int[]{9,1}))
      .put("checkouts",new JSONArray(new int[]{40,0}));
  JSONArray actions=game.getJSONArray("events");
  actions.put(event(0,20,1));
  for(int i=0;i<2;i++)actions.put(event(0,20,2));
  for(int i=0;i<3;i++)actions.put(event(0,20,3));
  actions.put(event(0,25,1)).put(event(0,25,2)).put(event(0,0,1)).put(event(1,20,3));
  memory.seed(game);
  String original=memory.values.get("matches");
  LocalDartsStats stats=new LocalDartsStats(memory.prefs);
  LocalDartsStats.Summary alice=stats.forProfile("alice"),bob=stats.forProfile("bob");
  check(alice.zones[20][1]==1&&alice.zones[20][2]==2&&alice.zones[20][3]==3,"S20, D20, T20 indépendants");
  check(alice.zones[25][1]==1&&alice.zones[25][2]==1,"25 et bull distincts");
  check(alice.hitTotal==8,"Une fléchette = un impact ; OUT exclu");
  check(alice.matches==1&&alice.wins==1&&alice.checkout==40,"Statistiques de match conservées");
  check(alice.darts==9&&alice.points==355&&Math.abs(alice.average()-355.0/3)<.00001,"Moyenne X01 inchangée");
  check(bob.hitTotal==1&&bob.zones[20][3]==1&&bob.zones[20][2]==0,"Pas d'impacts attribués à l'adversaire");
  check(stats.forProfile("inconnu").hitTotal==0&&stats.forProfile(null).hitTotal==0,"Profil vide");
  check(original.equals(memory.values.get("matches"))&&memory.commits==0,"Historique relu sans migration ni écriture");
 }
 private static void legacyHistoryStillWorks(){
  MemoryPrefs memory=new MemoryPrefs();
  JSONArray actions=new JSONArray().put(event(0,16,2)).put(event(0,19,3))
      .put(new JSONObject().put("player",0).put("segment",5)).put(event(1,20,3));
  memory.seed(new JSONObject().put("id0","ancien").put("id1","autre").put("winner",0)
      .put("x01",true).put("points0",115).put("darts0",3).put("checkout0",32).put("events",actions));
  LocalDartsStats.Summary legacy=new LocalDartsStats(memory.prefs).forProfile("ancien");
  check(legacy.zones[16][2]==1&&legacy.zones[19][3]==1&&legacy.zones[5][1]==1,"Ancien format et multiplicateur absent");
  check(legacy.hitTotal==3&&legacy.points==115&&legacy.darts==3&&legacy.checkout==32,"Statistiques historiques conservées");
 }
 private static void invalidZonesAreExcluded(){
  MemoryPrefs memory=new MemoryPrefs();JSONObject game=match("p");
  JSONArray events=game.getJSONArray("events");
  for(int[] pair:new int[][]{{0,1},{-1,1},{21,1},{24,1},{26,1},{20,0},{20,4},{25,3}})
   events.put(event(0,pair[0],pair[1]));
  events.put(event(0,18,3));memory.seed(game);
  LocalDartsStats.Summary stats=new LocalDartsStats(memory.prefs).forProfile("p");
  check(stats.hitTotal==1&&stats.zones[18][3]==1,"Seules les zones réelles de la cible sont comptées");
 }
 private static void allScoringZonesAndPlayerPositions(){
  MemoryPrefs memory=new MemoryPrefs();JSONObject first=match("p","guest"),second=match("guest","p");
  for(int segment=1;segment<=20;segment++)for(int multiplier=1;multiplier<=3;multiplier++)
   first.getJSONArray("events").put(event(0,segment,multiplier));
  first.getJSONArray("events").put(event(0,25,1)).put(event(0,25,2));
  second.getJSONArray("events").put(event(1,20,2)).put(event(0,20,3));memory.seed(first,second);
  LocalDartsStats.Summary stats=new LocalDartsStats(memory.prefs).forProfile("p");
  for(int segment=1;segment<=20;segment++)for(int multiplier=1;multiplier<=3;multiplier++)
   check(stats.zones[segment][multiplier]==(segment==20&&multiplier==2?2:1),"Zone "+segment+" x "+multiplier);
  check(stats.hitTotal==63&&stats.zones[25][1]==1&&stats.zones[25][2]==1,"62 zones et cumul multi-matchs par identifiant");
 }
 private static void savedGamesReloadAndUndo(){
  MemoryPrefs memory=new MemoryPrefs();
  DartSession session=new DartSession("x01_301",new String[]{"Alice","Bob"},1);
  for(int i=0;i<3;i++)session.throwDart(new DartThrow(20,3));
  for(int multiplier=1;multiplier<=3;multiplier++)session.throwDart(new DartThrow(1,multiplier));
  session.throwDart(new DartThrow(19,3));session.throwDart(new DartThrow(20,2));session.throwDart(new DartThrow(12,2));
  check(session.finished&&session.winner==0,"Partie réelle terminée");
  check(session.undo()&&!session.finished,"Annulation du checkout");session.throwDart(new DartThrow(12,2));
  LocalDartsStats writer=new LocalDartsStats(memory.prefs);
  writer.save("match-1",session,new String[]{"alice","bob"});
  writer.save("match-1",session,new String[]{"alice","bob"});
  LocalDartsStats reader=new LocalDartsStats(memory.prefs);
  LocalDartsStats.Summary alice=reader.forProfile("alice"),bob=reader.forProfile("bob");
  check(memory.commits==1,"Un match enregistré une seule fois");
  check(alice.zones[20][3]==3&&alice.zones[19][3]==1&&alice.zones[20][2]==1,"Multiplicateurs préservés à l'écriture/relecture");
  check(alice.zones[12][2]==1&&alice.hitTotal==6,"Annuler puis revalider ne double pas l'impact");
  check(alice.matches==1&&alice.wins==1&&alice.checkout==121&&alice.points==301&&alice.darts==6,"Résultat et moyenne conservés");
  check(bob.hitTotal==3&&bob.zones[1][1]==1&&bob.zones[1][2]==1&&bob.zones[1][3]==1,"Impacts de l'autre joueur conservés");
 }
 public static void main(String[] args){
  existingHistoryDistinguishesRings();legacyHistoryStillWorks();invalidZonesAreExcluded();
  allScoringZonesAndPlayerPositions();savedGamesReloadAndUndo();finishedResultCanBeReopened();
  System.out.println("LocalDartsStatsTest OK : 62 zones, bull, historique, profils, sauvegarde et annulation");
 }
 private static void finishedResultCanBeReopened(){
  MemoryPrefs memory=new MemoryPrefs();JSONObject old=match("alice","bob").put("matchId","older");
  old.getJSONArray("events").put(event(0,16,2));memory.seed(old);
  LocalDartsStats stats=new LocalDartsStats(memory.prefs);
  DartSession session=new DartSession("checkout",new String[]{"Alice"},1);session.throwDart(new DartThrow(20,2));
  stats.save("current",session,new String[]{"alice"});check(stats.forProfile("alice").hitTotal==2,"Résultat ajouté à l'historique existant");
  stats.removeResult("current");check(stats.forProfile("alice").hitTotal==1&&stats.forProfile("alice").zones[16][2]==1,"Annuler retire seulement le résultat courant");
  int writes=memory.commits;stats.removeResult("current");stats.removeResult(null);check(memory.commits==writes,"Suppression idempotente");
  stats.save("current",session,new String[]{"alice"});check(stats.forProfile("alice").hitTotal==2,"Une partie terminée à nouveau peut être enregistrée");
 }
}
