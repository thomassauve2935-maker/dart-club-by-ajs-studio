# Tests de persistance des statistiques

`LocalDartsStatsTest` exécute le vrai lecteur/écrivain JSON de l'application avec des préférences en mémoire. Il ne requiert ni émulateur ni appareil. Il couvre notamment les anciennes parties, les multiplicateurs, les 62 zones, les profils, la sauvegarde et l'annulation.

Après compilation des modèles et du moteur suivant le README principal, utiliser un JDK 17+, le JAR Android du SDK et un JAR JVM `org.json:json:20240303` :

```bash
export DARTS_ANDROID_JAR="/chemin/vers/Android/Sdk/platforms/android-35/android.jar"
export DARTS_JSON_JAR="/chemin/vers/json-20240303.jar"
javac -encoding UTF-8 -cp "$DARTS_JSON_JAR:$DARTS_ANDROID_JAR:/tmp/darts-classes" -d /tmp/darts-classes app/src/main/java/fr/dartsclub/app/LocalDartsStats.java app/src/main/java/fr/dartsclub/app/views/DartboardView.java tests/android-stats/LocalDartsStatsTest.java
java -cp "/tmp/darts-classes:$DARTS_JSON_JAR:$DARTS_ANDROID_JAR" fr.dartsclub.app.LocalDartsStatsTest
```

Placer le JAR JSON JVM avant le JAR Android pour utiliser le parseur JSON réel plutôt que les stubs du SDK. Ces tests ne valident pas le rendu Android.
