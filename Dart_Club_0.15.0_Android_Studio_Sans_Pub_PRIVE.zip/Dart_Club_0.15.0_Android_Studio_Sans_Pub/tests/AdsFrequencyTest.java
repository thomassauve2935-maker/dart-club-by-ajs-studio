import fr.sportcore.ads.AdFrequencyCap;
import fr.sportcore.ads.AdSettings;
import java.util.Collections;
public final class AdsFrequencyTest {
 private static void ok(boolean c,String msg){if(!c)throw new AssertionError(msg);}
 public static void main(String[] args){
  AdFrequencyCap gate=new AdFrequencyCap(Collections.emptySet());
  ok(gate.recordMatch("partie1"),"premier match admissible");
  ok(!gate.recordMatch("partie1"),"annuler et terminer à nouveau ne double pas la publicité");
  ok(gate.recordMatch("partie2"),"chaque nouveau match est admissible, sans compteur de legs ni délai");
  ok(!gate.recordMatch("partie1"),"ancien match déjà traité");
  AdFrequencyCap restored=new AdFrequencyCap(gate.completedMatches());
  ok(!restored.recordMatch("partie2"),"reprise sans doublon");
  ok(restored.recordMatch("partie3"),"nouveau match après reprise");
  ok(!restored.recordMatch(null)&&!restored.recordMatch("")&&!restored.recordMatch(" "),"identifiants absents refusés");
  ok(!AdSettings.disabled().enabled&&AdSettings.disabled().bannerUnitId.isEmpty()&&AdSettings.disabled().interstitialUnitId.isEmpty(),"configuration sans publicité");
  boolean rejected=false;
  try{AdSettings.production("ca-app-pub-3940256099942544~3347511713","ca-app-pub-3940256099942544/9214589741","ca-app-pub-1111111111111111/2222222222");}catch(IllegalArgumentException e){rejected=true;}
  ok(rejected,"bloc de démonstration refusé");
  System.out.println("OK : chaque match, aucun doublon après annulation/reprise, publicités désactivées et démo refusée");
 }
}
