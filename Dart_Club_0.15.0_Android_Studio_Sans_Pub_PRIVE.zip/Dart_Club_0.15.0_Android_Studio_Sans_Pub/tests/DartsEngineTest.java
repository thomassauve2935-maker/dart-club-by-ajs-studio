import fr.sportdarts.DartsSpec;
import fr.sportdarts.engine.*;
import java.util.*;
/** Tests réels de la rotation 1 à 8, de l'historique visible et d'Annuler après permutation. */
public final class DartsEngineTest {
 private static void check(boolean ok,String msg){if(!ok)throw new AssertionError(msg);}
 private static void t(DartSession s,int seg,int mul){check(s.throwDart(new DartThrow(seg,mul)),"dart rejected "+seg+"x"+mul);}
 private static String[] names(int n){String[] names=new String[n];for(int i=0;i<n;i++)names[i]="Joueur "+(i+1);return names;}
 public static void main(String[] args){
  DartsSpec spec=new DartsSpec();check(spec.games().size()==15,"15 jeux");
  check(new HashSet<>(Arrays.asList(spec.games().stream().map(x->x.id).toArray(String[]::new))).size()==15,"IDs uniques");
  for(int n=1;n<=8;n++){
   DartSession s=new DartSession("x01_501",names(n),1);
   check(s.playerCount()==n,"Nombre de joueurs : "+n);
   for(int p=0;p<n;p++){
    for(int j=0;j<3;j++)t(s,20,1);
    check(s.active==(p+1)%n,"Passage automatique à "+n+" joueurs après "+p);
    check(s.lastTurnPlayer()==p&&s.lastTurn().size()==3,"Dernière volée accessible");
    check(s.lastTurn().get(0).label().equals("20"),"Libellé fléchette");
   }
   check(s.undo(),"Annuler après tour complet");
   check(s.active==n-1&&s.turnDarts==2,"Retour au joueur précédent : "+n);
   check(s.currentTurn().size()==2&&s.lastTurnPlayer()==(n>1?n-2:-1),"Fléchettes rétablies : "+n);
   check(s.score[n-1]==461,"Score restauré : "+n);
  }
  DartSession s=new DartSession("x01_501",names(3),1);
  t(s,20,3);t(s,20,3);t(s,20,3);check(s.score[0]==321&&s.active==1,"180 et changement");
  t(s,5,1);check(s.currentTurn().size()==1&&s.currentTurn().get(0).label().equals("5"),"Affichage fléchette 1");
  t(s,18,2);check(s.currentTurn().get(1).label().equals("D18"),"Affichage fléchette 2");
  t(s,20,3);check(s.lastTurnPlayer()==1&&s.lastTurn().get(2).label().equals("T20"),"Dernière volée avec 3 fléchettes");
  check(s.undo()&&s.active==1&&s.currentTurn().size()==2,"Annuler au joueur précédent");
  DartSession checkout=new DartSession("checkout",names(1),1);
  t(checkout,8,1);t(checkout,16,2);check(checkout.finished&&checkout.winner==0,"checkout D16 solo");
  checkout.undo();check(!checkout.finished&&checkout.active==0&&checkout.score[0]==32,"Annuler checkout");
  DartSession bust=new DartSession("checkout",names(4),1);
  t(bust,20,1);t(bust,19,1);check(bust.score[0]==40&&bust.active==1,"bust rejoue score et passe suivant");
  check(bust.undo()&&bust.active==0&&bust.score[0]==20,"Annuler bust au joueur 1");
  DartSession cricket=new DartSession("cricket",names(8),1);
  t(cricket,20,3);check(cricket.mark(0,5)==3,"cricket ferme 20");
  t(cricket,20,3);check(cricket.score[0]==60,"cricket point si autre ouvert");
  DartSession around=new DartSession("around",names(4),1);
  t(around,1,1);check(around.progress(0)==2,"around progresse joueur 1");
  t(around,0,1);t(around,0,1);t(around,1,1);
  check(around.progress(0)==2&&around.progress(1)==2,"around indépendance joueurs");
  DartSession bob=new DartSession("bobs27",names(1),1);
  t(bob,1,1);t(bob,1,1);t(bob,1,1);check(bob.score[0]==25&&bob.stage()==2,"bob après trois échecs");
  DartSession survivor=new DartSession("survivor",names(3),1);
  t(survivor,0,1);t(survivor,0,1);t(survivor,0,1);
  check(survivor.lives[0]==2&&survivor.active==1,"survivant 3 joueurs");
  DartSession survivorSolo=new DartSession("survivor",names(1),1);
  for(int j=0;j<3;j++)t(survivorSolo,0,1);
  check(!survivorSolo.finished&&survivorSolo.lives[0]==2,"survivant solo doit continuer avec 2 vies");
  for(var m:spec.games())for(int n:new int[]{1,2,4,8}){
   DartSession demo=new DartSession(m.id,names(n),1);
   for(int j=0;j<3;j++)t(demo,0,1);
   check(demo.dartsThrown()==3,"3 fléchettes : "+m.id+" / "+n);
   check(demo.undo()&&demo.dartsThrown()==2,"Undo : "+m.id+" / "+n);
  }
  System.out.println("DartsEngineTest OK : 15 modes x 1..8, rotation, détail, undo, X01, Cricket, Around");
 }
}
