#!/usr/bin/env python3
"""Vérifie les ressources réellement compilées : couverture, pluriels et paramètres."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
count=0
for module in ('sportcore-ui','app'):
    sets=[]
    for folder in ('values','values-en','values-es'):
        path=root/module/'src/main/res'/folder/'strings.xml'
        entries={element.attrib['name']:element for element in ET.parse(path).getroot()}
        sets.append(entries)
    assert sets[0].keys()==sets[1].keys()==sets[2].keys(),f'{module}: clés manquantes'
    for key,source in sets[0].items():
        for translated,language in zip(sets[1:],('en','es')):
            target=translated[key]
            assert target.tag==source.tag,(module,key,'type différent')
            if source.tag=='plurals':
                assert {x.attrib['quantity'] for x in target}==({'one','other'} if language=='en' else {'one','many','other'}),(module,key,'accord manquant')
                sources={x.attrib['quantity']:x for x in source}
                targets={x.attrib['quantity']:x for x in target}
            else:
                sources={'text':source};targets={'text':target}
            for form,translation in targets.items():
                original=sources.get(form,sources.get('other'));value=translation.text
                assert value and value.strip(),(module,key,'texte vide')
                assert sorted(re.findall(r'%(\d+\$[dsf])',original.text))==sorted(re.findall(r'%(\d+\$[dsf])',value)),(module,key,'paramètres différents')
        count+=1
print(f'Traductions OK : {count} entrées complètes en français, anglais et espagnol')
