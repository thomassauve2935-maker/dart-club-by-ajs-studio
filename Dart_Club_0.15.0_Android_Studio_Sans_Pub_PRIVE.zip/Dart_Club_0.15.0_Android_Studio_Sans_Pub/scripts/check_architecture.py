#!/usr/bin/env python3
"""Vérifications statiques des dépendances. Ne remplace pas Gradle ou les tests Android."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
modules=['sportcore-model','sportcore-data','sportcore-ui','sportcore-navigation','sport-darts','sportcore-ads','app']
issues=[]
for name in modules:
 if not (root/name/'build.gradle').is_file():issues.append(f'module absent: {name}')
settings=(root/'settings.gradle').read_text(encoding='utf-8')
for name in modules:
 if f"':{name}'" not in settings: issues.append(f'module absent settings.gradle: {name}')
for name,denied in {
 'sportcore-model':['import android.','import fr.sportdarts.'],
 'sportcore-data':['import fr.sportcore.ui.','import fr.sportdarts.'],
 'sportcore-ui':['import fr.sportcore.data.','import fr.sportdarts.','android.content.SharedPreferences'],
 'sport-darts':['import android.','import fr.sportcore.ui.','import fr.sportcore.data.','import fr.sportcore.ads.'],
 'sportcore-ads':['import fr.sportdarts.','import fr.dartsclub.','import fr.sportcore.navigation.'],
}.items():
 for f in (root/name/'src/main/java').rglob('*.java'):
  text=f.read_text(encoding='utf-8')
  for phrase in denied:
   if phrase in text:issues.append(f'{f.relative_to(root)} : dépendance interdite {phrase}')
for unwanted in ['ProfileStore.java','SportCoreActivity.java']:
 if list((root/'sportcore-ui').rglob(unwanted)):issues.append(f'ancien fichier dans sportcore-ui: {unwanted}')
for name in ['sportcore-model','sport-darts']:
 for f in (root/name/'src/main/java').rglob('*.java'):
  if '.isBlank()' in f.read_text(encoding='utf-8'):issues.append('API Java non supportée sans desugaring: '+str(f))
if issues:
 print('ERREUR ARCHITECTURE:')
 for issue in issues:print(' -',issue)
 raise SystemExit(1)
print('Architecture statique OK : 7 modules, dépendances principales séparées')
