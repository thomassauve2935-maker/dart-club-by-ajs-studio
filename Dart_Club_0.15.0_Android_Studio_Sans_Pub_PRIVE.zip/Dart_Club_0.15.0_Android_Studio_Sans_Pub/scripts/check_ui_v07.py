#!/usr/bin/env python3
"""Garde-fous statiques V0.7, ne remplace pas les captures sur Android."""
from pathlib import Path
root=Path(__file__).resolve().parent.parent
ui=(root/'sportcore-ui/src/main/java/fr/sportcore/ui/SportUI.java').read_text()
nav=(root/'sportcore-navigation/src/main/java/fr/sportcore/navigation/SportCoreActivity.java').read_text()
board=(root/'app/src/main/java/fr/dartsclub/app/views/DartboardView.java').read_text()
match=(root/'app/src/main/java/fr/dartsclub/app/MatchScreen.java').read_text()
main=(root/'app/src/main/java/fr/dartsclub/app/MainActivity.java').read_text()
xml=(root/'sportcore-ui/src/main/res/values/palettes.xml').read_text()
assert 'ClubPalette.Club' in xml and 'ClubPalette.Night' in xml
assert 'cardBackground' in ui and 'scoreKey' in ui and 'toggleState' in ui
assert 'GradientDrawable.Orientation.TOP_BOTTOM' in ui
assert 'RippleDrawable' in ui
assert 'navigationBackground' in nav
assert 'HEAT_NONE' in board and 'HEAT_RARE' in board and 'HEAT_MIDDLE' in board
assert 'HEAT_FREQUENT' in board and 'HEAT_MAX' in board
assert 'intensityColor' in board and 'maximum' in board
assert 'SportUI.highlightedCard' in match and 'SportUI.scoreKey' in match
assert 'addHeatLegend' in main and 'darts_empty_hits' in main
print('Contrats statiques UI V0.7–V0.8 OK : composants partagés, catalogue unique, cible statistique')
